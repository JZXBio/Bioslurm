<?php
    $squeue  = shell_exec("squeue -o '%20i    %60j     %20u    %.2t     %.6D    %.4C  %M  %.11R ' ");
    // 成功响应
    echo json_encode([
        'success' => true,
        'result' => $squeue
    ]);
   


?>