<?php  

    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    //链接数据库
    include 'database_connect.php';

    $userid = $input['userid'];
    $file_path = $_SERVER['DOCUMENT_ROOT'] . '/user/' . $userid . '/.job_ids.txt';
    

    //计算使用时间
    /*/ 测试用例
    $timeA = "2026-02-05_15:41:49";
    $timeB = "2026-02-06_18:30:15";
    echo formatTimeDifference($timeA, $timeB); // 输出："1天"
    */
    function formatTimeDifference($startTimeStr, $endTimeStr) {
        // 解析时间字符串（格式：YYYY-MM-DD_HH:MM:SS）
        $parseTime = function ($timeStr) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}_\d{2}:\d{2}:\d{2}$/', $timeStr)) {
                throw new InvalidArgumentException("时间格式必须为 YYYY-MM-DD_HH:MM:SS");
            }
            list($date, $time) = explode('_', $timeStr);
            list($year, $month, $day) = explode('-', $date);
            list($hours, $minutes, $seconds) = explode(':', $time);
            return new DateTime("$year-$month-$day $hours:$minutes:$seconds");
        };
    
        $start = $parseTime($startTimeStr);
        $end = $parseTime($endTimeStr);
    
        // 确保 $end 是较晚的时间（避免负数）
        if ($end < $start) {
            [$start, $end] = [$end, $start];
        }
    
        $diff = $end->getTimestamp() - $start->getTimestamp(); // 秒级差值
    
        // 计算各单位
        $diffSeconds = $diff;
        $diffMinutes = floor($diffSeconds / 60);
        $diffHours = floor($diffMinutes / 60);
        $diffDays = floor($diffHours / 24);
    
        // 根据差值选择组合格式
        if ($diffDays >= 1) {
            $remainingHours = $diffHours % 24;
            return $diffDays . '天' . ($remainingHours > 0 ? " {$remainingHours}小时" : '');
        } elseif ($diffHours >= 1) {
            $remainingMinutes = $diffMinutes % 60;
            return $diffHours . '小时' . ($remainingMinutes > 0 ? " {$remainingMinutes}分钟" : '');
        } elseif($diffMinutes>=1) {
            $remainingSeconds = $diffSeconds % 60;
            return $diffMinutes . '分钟' . ($remainingSeconds > 0 ? " {$remainingSeconds}秒" : '');
        } else{
            $remainingSeconds = $diffSeconds % 60;
            return $remainingSeconds.'秒';
        }
    }
    
    // 检查文件是否存在或可读
    if (!file_exists($file_path) || !is_readable($file_path)) {
        http_response_code(400);
        echo json_encode(['error' => '无Job被记录，请在项目执行页面提交任务']);
        die();
    }

    
    // 读取文件所有行（跳过空行）
    $lines = file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    if ($lines === false) {
        http_response_code(400);
        echo json_encode(['error' => '读取文件失败']);
        die();
    }

    //原逻辑是存入数据库后删除文件，但是存入数据库消耗时间，如果有新内容存入可能被错误清空
    //建议逻辑，每次读取后加入EOF标记，然后每次只读取最后一个EOF字符标记之后的内容
    //我使用的逻辑，不那么麻烦，读取后即清空文件

    // 清空文件
    if (file_put_contents($file_path, '') === false) {
        http_response_code(500);
        echo json_encode(['error' => '清空文件失败']);
        die();
    }

    foreach ($lines as $line) {
        // 按 \t 分割行
        $columns = explode("\t", trim($line));
        $columns_num=count($columns);
        if($columns_num<6){continue;}
        list($record_time, $layer, $job_id, $job_id_slurm, $state,$task_id) = array_slice($columns, 0, 6);
        
        if($state=='create'){
            if($layer=='L1'){
                
                list($project_dir,$project_id,$task_module_id)=array_slice($columns, 6, 3);
                //
                $task_module_infos=fetch_id($conn,$task_module_id,'名称');
                $task_module_name=$task_module_infos['名称'];
          
                //防止和上次开机后别人同jobid的作业
                $itemid_INFOs=fetch_slurmjobid($conn,$job_id_slurm,$userid,'*'); 
                if($itemid_INFOs!=false){continue;}

                //
                $updateSql = "INSERT INTO 执行3_作业列表 (作业层级,作业slurm编号,作业编号,创建时间,更新时间,拥有者,文件目录,项目编号,任务编号,模块编号,模块名称,状态) values ('L1',?,?,?,?,?,?,?,?,?,?,?)"; 
                $params = [
                    ['type' => 's', 'value' => $job_id_slurm],   
                    ['type' => 's', 'value' => $job_id],
                    ['type' => 's', 'value' => $record_time],                 
                    ['type' => 's', 'value' => $record_time],
                    ['type' => 's', 'value' => $userid],     
                    ['type' => 's', 'value' => $project_dir],
                    ['type' => 's', 'value' => $project_id],
                    ['type' => 's', 'value' => $task_id],
                    ['type' => 's', 'value' => $task_module_id],     
                    ['type' => 's', 'value' => $task_module_name],
                    ['type' => 's', 'value' => $state]
                ];
                $success = database_insert($conn, $updateSql, $params); 
            }
            elseif($layer=='L2'){
                $sample_name=$columns[6];
                //防止和上次开机后别人同jobid的作业
                $itemid_INFOs=fetch_slurmjobid($conn,$job_id_slurm,$userid,'*'); 
                if($itemid_INFOs!=false){continue;}
                //
                $updateSql = "INSERT INTO 执行3_作业列表 (作业层级,作业slurm编号,作业编号,创建时间,更新时间,拥有者,任务编号,状态,样本名称) values ('L2',?,?,?,?,?,?,?,?)"; 
                $params = [
                    ['type' => 's', 'value' => $job_id_slurm],   
                    ['type' => 's', 'value' => $job_id],
                    ['type' => 's', 'value' => $record_time],                 
                    ['type' => 's', 'value' => $record_time],
                    ['type' => 's', 'value' => $userid],
                    ['type' => 's', 'value' => $task_id], 
                    ['type' => 's', 'value' => $state],
                    ['type' => 's', 'value' => $sample_name]
                ];
                $success = database_insert($conn, $updateSql, $params);      
            }
            elseif($layer=='L3'){
                //防止和上次开机后别人同jobid的作业
                $itemid_INFOs=fetch_slurmjobid($conn,$job_id_slurm,$userid,'*'); 
                if($itemid_INFOs!=false){continue;}
                //
                $updateSql = "INSERT INTO 执行3_作业列表 (作业层级,作业slurm编号,作业编号,创建时间,更新时间,拥有者,任务编号,状态) values ('L3',?,?,?,?,?,?,?)"; 
                $params = [
                    ['type' => 's', 'value' => $job_id_slurm],   
                    ['type' => 's', 'value' => $job_id],
                    ['type' => 's', 'value' => $record_time],                 
                    ['type' => 's', 'value' => $record_time],
                    ['type' => 's', 'value' => $userid],
                    ['type' => 's', 'value' => $task_id], 
                    ['type' => 's', 'value' => $state]
                ];
                $success = database_insert($conn, $updateSql, $params);      
            }          
        }
        
        elseif($state=='start'){
            if($layer=='L1'|| $layer=='L2'){
                $updateSql = "UPDATE 执行3_作业列表 SET 开始时间 = ?, 更新时间 = ?,状态='start' WHERE 拥有者=? and 作业slurm编号=?"; 
                $params = [
                    ['type' => 's', 'value' => $record_time],     
                    ['type' => 's', 'value' => $record_time],
                    ['type' => 's', 'value' => $userid],
                    ['type' => 's', 'value' => $job_id_slurm]
                ];
                $success = database_insert($conn, $updateSql, $params);
            }  
            elseif($layer=='L3'){
                $step_num=$columns[6];
                $updateSql = "UPDATE 执行3_作业列表 SET 开始时间 = ?, 更新时间 = ?,状态='start',步骤数量=? WHERE 拥有者=? and 作业slurm编号=?"; 
                $params = [
                    ['type' => 's', 'value' => $record_time],     
                    ['type' => 's', 'value' => $record_time],
                    ['type' => 's', 'value' => $step_num],
                    ['type' => 's', 'value' => $userid],
                    ['type' => 's', 'value' => $job_id_slurm]
                ];
                $success = database_insert($conn, $updateSql, $params);
            }    
        }        
        
        elseif($state=='end'){
            //查询开始时间
            $task_start_time=fetch_slurmjobid($conn,$job_id_slurm,$userid,'创建时间')['创建时间'];
            $used_time=formatTimeDifference($task_start_time,$record_time);
            //
            $updateSql = "UPDATE 执行3_作业列表 SET 结束时间 = ?, 更新时间 = ?,状态='end',使用时间=? WHERE 拥有者=? and 作业slurm编号=?"; 
            $params = [
                ['type' => 's', 'value' => $record_time],     
                ['type' => 's', 'value' => $record_time],
                ['type' => 's', 'value' => $used_time],
                ['type' => 's', 'value' => $userid],
                ['type' => 's', 'value' => $job_id_slurm]
            ];
            $success = database_insert($conn, $updateSql, $params);
        }    
        
        elseif($state=='mid'){
            $desc=$columns[6];
            $itemid_INFOs=fetch_slurmjobid($conn,$job_id_slurm,$userid,'*'); 
            $old_mid_state=$itemid_INFOs['中间状态'];
            if($old_mid_state){$new_mid_state=$old_mid_state.'_;;;_'.$record_time.'||'.$desc;}
            else{$new_mid_state=$record_time.'||'.$desc;}
            $updateSql = "UPDATE 执行3_作业列表 SET 中间状态 = ?, 更新时间 = ?,状态='mid' WHERE 拥有者=? and 作业slurm编号=?"; 
            $params = [
                ['type' => 's', 'value' => $new_mid_state],     
                ['type' => 's', 'value' => $record_time],
                ['type' => 's', 'value' => $userid],
                ['type' => 's', 'value' => $job_id_slurm]
            ];
            $success = database_insert($conn, $updateSql, $params);
        }
        
    }

    
    
    
    
    // 直接返回字符串数组（每行作为一个元素）
    $result = $lines;
    
    // 成功响应
    echo json_encode([
        'success' => true,
        'result' => $result
    ]);
   


// http_response_code(400);echo json_encode(['error' => '错误的路径格式']); // 检测到非法路径die();



























?>


























