<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
     
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);



    //链接数据库
    include 'database_connect.php';

    
    //echo json_encode(['result' => '执行中-内部-Gene']);die();
    //排序，页码，检索可能同时存在
    if (isset($input["action"]) && isset($input["userid"]) && $input["action"]=="refresh_task" && isset($input["project_belong_id"])){
        $userid         =$input["userid"]; 
        if(isset($input["project_belong_id"])){$project_belong_id=$input["project_belong_id"];}else{$project_belong_id='';} 

        if(isset($input["page"])){$page=intval($input["page"]);}else{$page=1;}

        if(isset($input["searchword"])){$searchword=$input["searchword"];}else{$searchword='';}
        if(isset($input["sortcol"]) && trim($input["sortcol"])!=''){$sortcol=$input["sortcol"];}else{$sortcol='';}
        if(isset($input["sortdirection"])){$sortdirection=$input["sortdirection"];}else{$sortdirection='';}
        
        if(isset($input["num_per_page"])){$num_per_page=intval($input["num_per_page"]);}else{$num_per_page=5;}
        //确定页码
        $items_per_page = $num_per_page;
        $offset = ($page - 1) * $items_per_page;
        
        //确认排序的方向
        if($sortcol=="")        {$sortcol ='更新时间';}
        if($sortdirection=="")  {$sortdirection='desc';} 
        
        $sort_str="$sortcol $sortdirection";
        $where_str="拥有者 = ? and 所属项目编号= ? and (系统备注1 IS NULL or 系统备注1<>'删除')  ";
        //确认排序的方向
        if($searchword==""){
            $sql = "SELECT 创建时间,唯一识别码,状态,更新时间,所属项目编号,所属项目目录,使用模块,模块名称,备注信息 from 执行2_任务列表 where {$where_str} order by {$sort_str} limit {$items_per_page} offset {$offset}"; 
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();  }  
            mysqli_stmt_bind_param($stmt, 'ss', $userid,$project_belong_id); 
            ///单纯计数
            $sql2 = "SELECT COUNT(*) from 执行2_任务列表 where {$where_str}  ";  
            $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();  }  
            mysqli_stmt_bind_param($stmt2, 'ss', $userid,$project_belong_id); 
        }
        else{
            $searchword = "%" . $searchword . "%";
            $where_str2="(创建时间 like ? or 唯一识别码 like ?  or 更新时间 like ? or 所属项目目录 like ? or 使用模块 like ? or 模块名称 like ?)";
            $sql = "SELECT 创建时间,唯一识别码,状态,更新时间,所属项目编号,所属项目目录,使用模块,模块名称,备注信息 from 执行2_任务列表 where ({$where_str} and {$where_str2}) order by {$sort_str} limit {$items_per_page} offset {$offset}";  
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();  }  
            mysqli_stmt_bind_param($stmt, 'ssssssss', $userid,$project_belong_id,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword); 
            ///单纯计数
            $sql2 = "SELECT COUNT(*) from 执行2_任务列表 where ({$where_str} and {$where_str2}) ";  
            $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();  }  
            mysqli_stmt_bind_param($stmt2, 'ssssssss', $userid,$project_belong_id,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword); 
        }
        
        //正式执行sql
        mysqli_stmt_execute($stmt);  
        $result = mysqli_stmt_get_result($stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($stmt); 
        if (empty($results)) {  
            //http_response_code(401);  
            //mysqli_close($conn); 
            //exit;  
            
        } 
        
        //简单计数
        mysqli_stmt_execute($stmt2);  
        mysqli_stmt_bind_result($stmt2, $total_count);
        mysqli_stmt_fetch($stmt2);
        mysqli_stmt_close($stmt2);

        $page_count = ceil($total_count / $items_per_page);


        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
            'result_num' =>$total_count,
            'page_num' =>$page_count,
        ]);
        
    }
    
    else if (isset($input["action"]) && isset($input["userid"]) && $input["action"]=="specific_one_task" && isset($input["task_item_id"])){   
        
        $userid         =$input["userid"]; 
        if(isset($input["task_item_id"])){$task_item_id=$input["task_item_id"];}else{http_response_code(500);  echo json_encode(['error' => '无法获取信息']);die();} 
        
        //
        $sql = "SELECT 线程分配,使用模块,模块名称,模板修订,参数修订,变量设置,作业运行列表,作业依赖,作业模板修订,作业参数修订 FROM 执行2_任务列表 WHERE 拥有者=? and 唯一识别码 = ?";
        $params = [
            ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
            ['type' => 's', 'value' => $task_item_id]
        ]; 
        $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
        $results=$rows[0];
        // 返回 JSON 响应
        
        echo json_encode([
            'status' => 'success',
            'result' => $results,
        ]);        
        
    }
    
    
    else{
        http_response_code(500);  echo json_encode(['error' => '无法获取信息']);die();
    }
    
    
    
    
?>    