<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["item_id"])  && isset($input["col_name"])  && isset($input["input_value"]) ){
        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $item_id                =$input["item_id"];   
        $col_name               =$input["col_name"]; 
        $input_value            =trim($input["input_value"]);  
        $input_value            =str_replace('？', '?', $input_value);  
        $input_value            =str_replace('；', ';', $input_value);         
        $input_value            =preg_replace('/_;;;_$/', '', $input_value); // 去掉右侧的 `_;;;_`
        // 检查 $col_value 是否为空字符串，如果是，则设置为 NULL  
        if($input_value == ''){$input_value=null;}  
        
        if(in_array($col_name,['分类1','分类2','分类3','名称','描述1','描述2','描述3','线程分配','模板预设','参数预设','变量预设','结果预设','备注信息','流程内容'])==false){
            http_response_code(400);  echo json_encode(['error' => '列名错误']);die();
        }
         
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
        
        //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
        $updateSql = "UPDATE 预设2_线性流程 SET 更新时间 = '$current_time',$col_name=?  WHERE 唯一识别码=? ";  
        $updateStmt = mysqli_prepare($conn, $updateSql);  
        if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}  
      
        mysqli_stmt_bind_param($updateStmt, 'ss',$input_value, $item_id); 
            
        if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}
            
        mysqli_stmt_close($updateStmt);  
        mysqli_close($conn);       
          
  
          
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
        ]);
        


        
        
        die();
    }

?>























