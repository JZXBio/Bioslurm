<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    function generateRandomString($length) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomIndex = rand(0, $charactersLength - 1);
            $randomString .= $characters[$randomIndex];
        }
        return $randomString;
    }
    if (isset($input["action"]) && isset($input["item_id"]) && isset($input["userid"])){

        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $action                     =$input["action"];       //action为 向外分享 或 向内拷贝
        $item_id                    =$input["item_id"];  
        $userid                     =$input["userid"];  
        $new_item_id0 = 'structure_' . generateRandomString(10);
        $new_item_id1 = $new_item_id0;
 
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
         
        //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
        if($action=="向外分享"){
            //先复制各种依赖，最后复制主的item
            //先把网络内容提取出来，并分析出子node
            /*
            $sql = "SELECT 网络内容 FROM 预设3_网络结构 WHERE 唯一识别码 = '$item_id'";
            $sql_result=mysqli_query($conn,$sql);
            $row = mysqli_fetch_assoc($sql_result);
            $structure_content=$row['网络内容'];*/
            $sql = "SELECT 网络内容 FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params =[ ['type' => 's', 'value' => $item_id]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
            $structure_content=$rows[0]['网络内容'];
            //http_response_code(500);  echo json_encode(['error' =>$rows[0]['网络内容']  ]);die();
            //获取所有网络内容的child的list
            $parts = explode("_|||_", $structure_content);$child_id_arr=[];
            foreach ($parts as $part) {if (strpos($part, 'stream') === 0 || strpos($part, 'script') === 0) {$child_id_arr[] = $part;}}
            $unique_child_id_arr = array_unique($child_id_arr); // 去重
            //每个网络结构的child复制过来
            $structure_content_new=$structure_content;
            foreach ($unique_child_id_arr as $one_child_oldid){
                if (strpos($one_child_oldid, 'stream_') === 0){
                    $new_child_id = 'stream_' . generateRandomString(10);
                    //获取所有流程内容的child的list
                    $sql = "SELECT 流程内容 FROM 预设2_线性流程 WHERE 唯一识别码 = ?";
                    $params =[ ['type' => 's', 'value' => $one_child_oldid]];// 's' 表示字符串类型
                    $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
                    $stream_content=$rows[0]['流程内容'];
                    $parts = explode("_|||_", $stream_content);$child_id_arr=[];
                    foreach ($parts as $part) {if (strpos($part, 'script') === 0) {$child_id_arr[] = $part;}}
                    $unique_child_id_arr2 = array_unique($child_id_arr);                    
                    //每个流程的child复制过来
                    $stream_content_new=$stream_content;
                    foreach ($unique_child_id_arr2 as $one_child_oldid2){
                        $new_child_id2 = 'script_' . generateRandomString(10);
                        //复制一个script开始
                        $updateSql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备) SELECT '$current_time','$one_child_oldid','$new_child_id2',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'公开','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备 FROM 预设1_命令脚本 WHERE 唯一识别码 = ?"; 
                        $params = [
                            ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                            ['type' => 's', 'value' => $one_child_oldid2]          // 第2个 ?：源唯一识别码
                        ];
                        //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$one_child_oldid2]); die();
                        $success = database_insert($conn, $updateSql, $params);
                        if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                        //复制一个script结束
                        $stream_content_new = str_replace($one_child_oldid2, $new_child_id2, $stream_content_new);
                    }    
                    
                    //最后复制一个子的stream
                    $updateSql = "INSERT INTO 预设2_线性流程
                        (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,参数预设,模板预设,结果预设,变量预设,备注信息,流程内容)  
                        SELECT '$current_time','$new_item_id0','$new_child_id',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'公开','$current_time',参数预设,模板预设,结果预设,变量预设,备注信息,?
                        FROM 预设2_线性流程 WHERE 唯一识别码 = ?";
                    $params = [
                        ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                        ['type' => 's', 'value' => $stream_content_new], // 第2个 ?：流程内容
                        ['type' => 's', 'value' => $one_child_oldid]          // 第3个 ?：源唯一识别码
                    ];
                    $success = database_insert($conn, $updateSql, $params);
                    //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$stream_content_new.$one_child_oldid]); die();
                    if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                }
                else if (strpos($one_child_oldid, 'script_') === 0){
                    $new_child_id = 'script_' . generateRandomString(10);
                    //复制一个script开始
                    $updateSql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备)  SELECT '$current_time','$new_item_id0','$new_child_id',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'公开','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备 FROM 预设1_命令脚本 WHERE 唯一识别码 = ?"; 
                    $params = [
                        ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                        ['type' => 's', 'value' => $one_child_oldid]          // 第2个 ?：源唯一识别码
                    ];
                    //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$item_id]); die();
                    $success = database_insert($conn, $updateSql, $params);
                    if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                    //复制一个script结束
                }
                $structure_content_new = str_replace($one_child_oldid, $new_child_id, $structure_content_new);
            }
            
            //最后复制一个主的item网络结构
            // 定义 SQL 语句（3个占位符 ?）
            $updateSql = "INSERT INTO 预设3_网络结构 
                (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,参数预设,模板预设,结果预设,变量预设,备注信息,网络内容)  
                SELECT '$current_time','$new_item_id0','$new_item_id1',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'公开','$current_time',参数预设,模板预设,结果预设,变量预设,备注信息,?
                FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params = [
                ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                ['type' => 's', 'value' => $structure_content_new], // 第2个 ?：网络内容
                ['type' => 's', 'value' => $item_id]          // 第3个 ?：源唯一识别码
            ];
            $success = database_insert($conn, $updateSql, $params);
            if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
       
            

        }
        elseif($action=="向内简单拷贝"){
            //先复制各种依赖，最后复制主的item
            $sql = "SELECT 网络内容 FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params =[ ['type' => 's', 'value' => $item_id]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
            $structure_content=$rows[0]['网络内容'];
            $structure_content_new=$structure_content;
            
            //最后复制一个主的item网络结构
            // 定义 SQL 语句（3个占位符 ?）
            $updateSql = "INSERT INTO 预设3_网络结构 
                (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,参数预设,模板预设,结果预设,变量预设,备注信息,网络内容)  
                SELECT '$current_time','$new_item_id0','$new_item_id1',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',参数预设,模板预设,结果预设,变量预设,备注信息,?
                FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params = [
                ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                ['type' => 's', 'value' => $structure_content_new], // 第2个 ?：网络内容
                ['type' => 's', 'value' => $item_id]          // 第3个 ?：源唯一识别码
            ];
            $success = database_insert($conn, $updateSql, $params);
            if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
       

        }
        elseif($action=="向内拷贝"){
            //先复制各种依赖，最后复制主的item
            $sql = "SELECT 网络内容 FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params =[ ['type' => 's', 'value' => $item_id]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
            $structure_content=$rows[0]['网络内容'];
            $structure_content_new=$structure_content;            
            //http_response_code(500);  echo json_encode(['error' =>$rows[0]['网络内容']  ]);die();
            //获取所有网络内容的child的list
            $parts = explode("_|||_", $structure_content);$child_id_arr=[];
            foreach ($parts as $part) {if (strpos($part, 'stream') === 0 || strpos($part, 'script') === 0) {$child_id_arr[] = $part;}}
            $unique_child_id_arr = array_unique($child_id_arr); // 去重
            //每个网络结构的child复制过来
            foreach ($unique_child_id_arr as $one_child_oldid){
                if (strpos($one_child_oldid, 'stream_') === 0){
                    $new_child_id = 'stream_' . generateRandomString(10);
                    //获取所有流程内容的child的list
                    $sql = "SELECT 流程内容 FROM 预设2_线性流程 WHERE 唯一识别码 = ?";
                    $params =[ ['type' => 's', 'value' => $one_child_oldid]]; // 's' 表示字符串类型
                    $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
                    $stream_content=$rows[0]['流程内容'];
                    $parts = explode("_|||_", $stream_content);$child_id_arr=[];
                    foreach ($parts as $part) {if (strpos($part, 'script') === 0) {$child_id_arr[] = $part;}}
                    $unique_child_id_arr2 = array_unique($child_id_arr);                    
                    //每个流程的child复制过来
                    $stream_content_new=$stream_content;
                    foreach ($unique_child_id_arr2 as $one_child_oldid2){
                        $new_child_id2 = 'script_' . generateRandomString(10);
                        //复制一个script开始
                        $updateSql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备) SELECT '$current_time','$one_child_oldid','$new_child_id2',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备 FROM 预设1_命令脚本 WHERE 唯一识别码 = ?"; 
                        $params = [
                            ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                            ['type' => 's', 'value' => $one_child_oldid2]          // 第2个 ?：源唯一识别码
                        ];
                        //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$one_child_oldid2]); die();
                        $success = database_insert($conn, $updateSql, $params);
                        if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                        //复制一个script结束
                        $stream_content_new = str_replace($one_child_oldid2, $new_child_id2, $stream_content_new);
                    }    
                    
                    //最后复制一个子的stream
                    $updateSql = "INSERT INTO 预设2_线性流程
                        (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,参数预设,模板预设,结果预设,变量预设,备注信息,流程内容)  
                        SELECT '$current_time','$new_item_id0','$new_child_id',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',参数预设,模板预设,结果预设,变量预设,备注信息,?
                        FROM 预设2_线性流程 WHERE 唯一识别码 = ?";
                    $params = [
                        ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                        ['type' => 's', 'value' => $stream_content_new], // 第2个 ?：流程内容
                        ['type' => 's', 'value' => $one_child_oldid]          // 第3个 ?：源唯一识别码
                    ];
                    $success = database_insert($conn, $updateSql, $params);
                    //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$stream_content_new.$one_child_oldid]); die();
                    if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                }
                else if (strpos($one_child_oldid, 'script_') === 0){
                    $new_child_id = 'script_' . generateRandomString(10);
                    //复制一个script开始
                    $updateSql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备)  SELECT '$current_time','$new_item_id0','$new_child_id',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备 FROM 预设1_命令脚本 WHERE 唯一识别码 = ?"; 
                    $params = [
                        ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                        ['type' => 's', 'value' => $one_child_oldid]          // 第2个 ?：源唯一识别码
                    ];
                    //http_response_code(500);echo json_encode(['error' => '无法完成数据库更新'.$updateSql.$userid.$item_id]); die();
                    $success = database_insert($conn, $updateSql, $params);
                    if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
                    //复制一个script结束
                }
                $structure_content_new = str_replace($one_child_oldid, $new_child_id, $structure_content_new);
            }
            
            //最后复制一个主的item网络结构
            // 定义 SQL 语句（3个占位符 ?）
            $updateSql = "INSERT INTO 预设3_网络结构 
                (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,参数预设,模板预设,结果预设,变量预设,备注信息,网络内容)  
                SELECT '$current_time','$new_item_id0','$new_item_id1',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',参数预设,模板预设,结果预设,变量预设,备注信息,?
                FROM 预设3_网络结构 WHERE 唯一识别码 = ?";
            $params = [
                ['type' => 's', 'value' => $userid],          // 第1个 ?：拥有者
                ['type' => 's', 'value' => $structure_content_new], // 第2个 ?：网络内容
                ['type' => 's', 'value' => $item_id]          // 第3个 ?：源唯一识别码
            ];
            $success = database_insert($conn, $updateSql, $params);
            if (!$success) {http_response_code(500);echo json_encode(['error' => '无法完成数据库更新']); die();}
       

        }
    }
    echo json_encode(['status' => 'success']);
?>























