<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["new_name"])  && isset($input["new_item_id0"])  && isset($input["new_item_id1"]) && isset($input["project_dir"])  ){
        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $base_path                  =$input["base_path"]; 
        $new_item_id0               =$input["new_item_id0"];  
        $new_item_id1               =$input["new_item_id1"];   
        $userid                     =$input["userid"];   
        $project_dir                   =$input["project_dir"];
        $new_name                   =$input["new_name"];   
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
        
        //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
        $updateSql = "INSERT INTO 执行1_项目列表 (创建时间,识别码,唯一识别码,创建者,拥有者,名称,更新时间,共享权限,项目目录) VALUES ('{$current_time}',?,?,?,?,?,'{$current_time}','个人',?)";  
        $updateStmt = mysqli_prepare($conn, $updateSql);  
        if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}  
      
        mysqli_stmt_bind_param($updateStmt, 'ssssss',$new_item_id0,$new_item_id1,$userid,$userid,$new_name,$project_dir); 
            
        if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}
            
        mysqli_stmt_close($updateStmt);  
        mysqli_close($conn);       
          
  
        /*生成project_log文件夹*/
        //$project_log_dir=$base_path.$project_dir.'/000_log_'.$project_id.'/';
        $project_log_dir=$base_path.substr($project_dir,5).'/log_'.$new_item_id1.'/';
        if (!file_exists($project_log_dir)) {  
            if (mkdir($project_log_dir, 0777, true)) {
                //$result_log_text="文件夹创建成功"; 
            } 
            else {
                http_response_code(400);echo json_encode(['error' => 'project_log_dir文件夹创建失败']);die();  
            }  
        }   
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
        ]);
        


        
        
        die();
    }

?>























