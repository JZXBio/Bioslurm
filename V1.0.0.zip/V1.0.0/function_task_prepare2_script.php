<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    //链接数据库
    include 'database_connect.php';
    $current_time = date('Y-m-d_H:i:s');
    {
        /*去掉每行的#及之后的内容，主要针对参数预设*/
        function parameter_delete_annotation($str) {  
            if (empty($str)){return '';}
            if(trim($str)==''){return '';}
            $lines = explode("\n", $str);  
            $processedLines = array_map(function ($line) {  
                $trimmedLine = trim(preg_replace('/#.*/', '', $line)); // 去掉#后面的内容   
                if ($trimmedLine === '' || $trimmedLine === '#' || preg_match('/^\s*#\s*$/', $line)) {  return null;}   // 返回null表示我们稍后将删除这行  
                return $trimmedLine; // 返回处理后的行  
            }, $lines);  
            $filteredLines = array_filter($processedLines, function ($line) {  return $line !== null;  });  
            $processedString = implode("\n", $filteredLines);  return $processedString;  
        }
        
        //模板预设和模板修订每行不一定有等号，模板预设当作纯字符串，修订必定有===号：旧===新，===新，旧===
        function template_preset_revise($preset, $revise) {
            //$preset去掉其中的换行符并替换为空格，并将多个连续空格替换为单空格
            $preset = trim(preg_replace('/\s+/', ' ', str_replace("\n", ' ', $preset)));
            // 分割修订行并过滤空行
            $reviseLines = array_filter(explode("\n", trim($revise)),fn($line) => trim($line) !== ''            );
            foreach ($reviseLines as $line) {
                $line = trim(preg_replace('/\s+/', ' ', $line));//将多个连续空格替换为单空格
                if (strpos($line, '===') === false || $line=='===') {continue; }
                // 格式：===新 → 追加到末尾（避免多余空格）
                if (str_starts_with($line, '===')) {$preset .= ' '.trim(str_replace('===', '', $line));} 
                // 格式：旧=== → 删除所有旧（精确匹配整个单词）
                elseif (str_ends_with($line, '===')) {$old = trim(str_replace('===', '', $line));$preset =str_replace($old, '', $preset);} 
                // 格式：旧===新 → 替换旧为新（精确匹配整个单词）
                else {list($old, $new) = explode('===', $line, 2);$old = trim($old); $new = trim($new);$preset =str_replace($old, $new, $preset);}
            }
            return trim($preset); // 清理首尾空格
        }
  
        
        //参数预设和参数修订每行必须要有等号！
        function parameter_preset_revise($preset, $revise) {
            // 将 preset 和 revise 按换行符分割成数组
            $presetLines = explode("\n", trim($preset));
            $reviseLines = explode("\n", trim($revise));
            
            // 创建一个关联数组来存储 preset 的键值对
            $presetArray = [];
            foreach ($presetLines as $line) {
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $key=trim(preg_replace('/\s+/', ' ', $key));$value=trim(preg_replace('/\s+/', ' ', $value));//将多个连续空格替换为单空格
                    $presetArray[$key] = $value;
                }
            }
            // 处理 revise，根据规则进行替换和添加
            foreach ($reviseLines as $line) {
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $key=trim(preg_replace('/\s+/', ' ', $key));$value=trim(preg_replace('/\s+/', ' ', $value));//将多个连续空格替换为单空格
                    if ($key == ''){continue;}
                    if ($value === '' || $value === '""') {unset($presetArray[$key]);} // 如果值为空字符串或者仅有等号（即 param3=），则从 preset 中删除该键
                    elseif(isset($presetArray[$key])) {$presetArray[$key] = $value;} // 否则，只有键存在，才更新键值对
                    else{$presetArray[$key] = $value; } //键不存在，新增该键值对
                } 
            }
            // 将最终结果转换回字符串，使用换行符分隔
            $result = [];
            foreach ($presetArray as $key => $value) {
                $result[] = "$key=$value";
            }
            return implode("\n", $result);
        }   
        
        //模板用参数进行替换
        function template_repalce_para($template_str,$parameter_str){
            
            $template_str=preg_replace("/\r\n|\r|\n/", " ", $template_str);  //去掉windows,mac,linux的换行符为空格
            
            $parameter_arr=explode("\n",$parameter_str);
            foreach ($parameter_arr as $oneline) {
                $oneline_arr=explode("=",$oneline);       if (count($oneline_arr)!=2){continue;}
                $oneline_arr_name=trim($oneline_arr[0]);
                $oneline_arr_value=trim($oneline_arr[1]);  
                $template_str = str_replace("{".$oneline_arr_name."}", $oneline_arr_value, $template_str);
                
            }
            $template_str = preg_replace('/\s+/', ' ', $template_str); //替换所有连续空白（包括换行、制表符等）为单个空格
            return $template_str;
        }
        function normal_repalce_para($template_str,$parameter_str){
            //$template_str=preg_replace("/\r\n|\r|\n/", " ", $template_str);  //去掉windows,mac,linux的换行符为空格
            $parameter_arr=explode("\n",$parameter_str);
            foreach ($parameter_arr as $oneline) {
                $oneline_arr=explode("=",$oneline);       if (count($oneline_arr)!=2){continue;}
                $oneline_arr_name=trim($oneline_arr[0]);
                $oneline_arr_value=trim($oneline_arr[1]);  
                $template_str = str_replace("{".$oneline_arr_name."}", $oneline_arr_value, $template_str);
                
            }
            $template_str = preg_replace('/[ \t]+/', ' ', $template_str);//替换所有连续空格或tab为单个空格
            return $template_str;
        }        
        /*有问题，太复杂了，还是不考虑小括号的情况了
        //获得所有括号内的值及括号内/分隔符带来的多个值，生成一个list
        function parentheses2arr($str) {  //去掉所有非括号内容，仅保留括号内的内容"Hello (world), this is (a test) with (multiple) brackets"=>world a test multiple
            $str = str_replace(['（', '）'], ['(', ')'], $str);//将所有汉语括号替换为英文括号
            preg_match_all('/\(([^()]*)\)/', $str, $matches);
            $str= implode(' ', $matches[1]); // 用空格连接所有括号内的内容
            $str=str_replace('/',' ',$str);            //{名称}(.fa/.fasta)(.fas)   
            $str = trim(preg_replace('/\s+/', ' ',  $str)); //替换多个空格为单个
            $str_arr=explode(" ",$oneline);
            return $str_arr;
        }   */
        //模板参数，用变量进行替换
        function replace_template_by_variable($template_str, $variable_obj) {
            foreach ($variable_obj as $key => $value) {
                // 直接替换 {key} 为对应的 value
                //$template_str = str_replace("{{$key}}", $value, $template_str);
                $template_str = str_replace("{".$key."}", $value, $template_str);
            }
            //以空格为分隔符分为part，看是否某一part含有小括号()，取小括号内容，小括号可能有多对，每个小括号内部可能有斜线/，斜线隔开多个，将part内的小括号的内容依次替换掉，也要去掉括号
            /*有问题，太复杂了，还是不考虑小括号的情况了
            if(preg_match('/\(|\)/', $template_str) === 1){
                $template_str_arr=explode(" ",$oneline);
                $template_str='';
                foreach($template_str_arr as $template_str_arr_one){
                    if (preg_match('/\(|\)/', $template_str_arr_one) === 1){
                        $part_parentheses=parentheses2arr($template_str_arr_one);
                        foreach($part_parentheses as $part_parentheses_one){
                            $template_str_arr_one=preg_replace($part_parentheses_one,'',$template_str_arr_one);
                        }
                        $template_str_arr_one=preg_replace('/\(.*?\)/', '', $template_str_arr_one);; //去掉括号及其内容
                    }
                    $template_str.=' '.$template_str_arr_one;
                }
            }*/
            return $template_str;
        }    
        
        function generate_script($task_id,$conn,$base_path,$job_nameid,$task_log_absolute_dir,$child_itemid,$revise1,$revise2,$dict_variablename_value,$one_name_pure){
            [$one_template_revise,$one_parameter_revise]=$revise1;[$onenode_template_revise,$onenode_parameter_revise]=$revise2;
            $itemid_INFOs=fetch_id($conn,$child_itemid,'*'); 
            $script_commandtype         =$itemid_INFOs['命令类型'];
            $script_name                =$itemid_INFOs['名称'];
            //$script_env                 =$itemid_INFOs['环境类型'];
            ##############
            $script_threads             =$itemid_INFOs['线程分配']?? 1;
            $script_commandname         =$itemid_INFOs['命令名称'];
            $script_commandurl          =$itemid_INFOs['命令地址'];
            if($script_commandurl){
                $script_commandurl=$script_commandurl.'/';
                $script_commandurl=preg_replace('/\/+/', '/', $script_commandurl);
            }
            $script_template_preset     =parameter_delete_annotation($itemid_INFOs['模板预设']); //同$task_module_template_good
            $script_parameter_preset    =parameter_delete_annotation($itemid_INFOs['参数预设']); //同$task_module_parameter_good
            $script_content             =$itemid_INFOs['脚本内容'];

            //
            //如果有脚本内容,写入一个文件
            $script_file='';
            if($script_commandtype=='自定义'){
                $script_file = "{$task_log_absolute_dir}{$job_nameid}.script";
                if (file_put_contents($script_file, $script_content) !== false) {  } 
                else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  }
            }
            //本来的修订
            if($one_template_revise){$script_template_preset        =template_preset_revise($script_template_preset,$one_template_revise);  }
            if($one_parameter_revise){$script_parameter_preset      =parameter_preset_revise($script_parameter_preset,$one_parameter_revise); }
            //临时修订
            if($onenode_template_revise){$script_template_preset        =template_preset_revise($script_template_preset,$onenode_template_revise);  }
            if($onenode_parameter_revise){$script_parameter_preset      =parameter_preset_revise($script_parameter_preset,$onenode_parameter_revise); }     
            //模板用参数解释
            $script_template_parameter=template_repalce_para($script_template_preset,$script_parameter_preset);    
            $script_template_parameter_var=replace_template_by_variable($script_template_parameter,$dict_variablename_value); 
            //如果含有{*}
            if (str_contains($script_template_parameter_var, '{*}')) {$script_template_parameter_var = str_replace('{*}', $one_name_pure, $script_template_parameter_var);}           
            /////环境预备
            $script_env_name            =$itemid_INFOs['环境预备'];$script_env_source_str='';
            if($script_env_name){
                //$script_env_name        =parameter_delete_annotation($script_env_name);
                //$script_env_source_str=$script_env_name.' && ';
                //$script_env_source_str= preg_replace('/ *&& */', ' && ', $script_env_source_str); //匹配 任意数量的空格 + && + 任意数量的空格替换为 一个空格 + && + 一个空格。
                //$script_env_source_str= preg_replace('/\s+/', ' ', $script_env_source_str); //多个空格替换为单个
                //$script_env_source_str = str_replace(['&& &&', ' &&&& '], ' && ', $script_env_source_str);
                $script_env_source_str=$script_env_name;
                //用参数解释
                $script_env_source_str=normal_repalce_para($script_env_source_str,$script_parameter_preset);    
                $script_env_source_str=replace_template_by_variable($script_env_source_str,$dict_variablename_value); 
                //如果含有{*}
                if (str_contains($script_env_source_str, '{*}')) {$script_env_source_str = str_replace('{*}', $one_name_pure, $script_env_source_str);}       
            }
            else{$script_env_source_str='#';}
            /////完成整备
            $script_after=$itemid_INFOs['完成整备'];
            if($script_after){
                $script_after             =$script_after;
                //$script_after        =parameter_delete_annotation($script_after);
                //用参数解释
                $script_after=normal_repalce_para($script_after,$script_parameter_preset);    
                $script_after=replace_template_by_variable($script_after,$dict_variablename_value); 
                //如果含有{*}
                if (str_contains($script_after, '{*}')) {$script_after = str_replace('{*}', $one_name_pure, $script_after);}                  
            }    
            else{$script_after='#';}
            /////
            $addition_str="
##########{$script_name}
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL3\t{$job_nameid}\t\$SLURM_JOB_ID\tmid\t{$task_id}\t{$script_name}\" >> {$base_path}/.job_ids.txt  
{$script_env_source_str}
{$script_commandurl}{$script_commandname} {$script_file} {$script_template_parameter_var}
{$script_after}\n";
            return [$addition_str,$script_threads];
        }
    }
    //echo json_encode(['result' => '执行中-内部-Gene']);die();
    if (isset($input["task_id"]) && isset($input["userid"])){
        $user_id=$input['userid'];
        $task_id                                    =$input["task_id"];  
        $base_path = '/www/wwwroot/bioslurm/user/'.$user_id.'/'; 
       
        //查找数据
        $sql = "select 所属项目编号,所属项目目录, 线程分配, 使用模块, 模板修订, 参数修订, 变量设置, 作业运行列表, 作业依赖, 作业模板修订, 作业参数修订  from 执行2_任务列表 where `拥有者`=? and `唯一识别码` = ? and (`系统备注1` <> '删除' OR `系统备注1` IS NULL) ";  
        $params =[  ['type' => 's', 'value' => $user_id],
                    ['type' => 's', 'value' => $task_id]]; // 's' 表示字符串类型
                    
        $results = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
        if (!$results) {  http_response_code(404);  echo json_encode(['error' => '任务编码未指定，请生成任务或选择一个已有任务'.$task_id]);die();} 
      

        //唯一结果
        $result_one=$results[0];
        $project_id                             =$result_one['所属项目编号'];
        $project_dir                            =$result_one['所属项目目录'];   $project_dir=substr($project_dir, 5);   //去掉开头的/home字样
        //$task_sum_threads                       =$result_one['线程分配']?? 1;
        $task_module_id                         =$result_one['使用模块'];
        $task_start_template_revise             =parameter_delete_annotation($result_one['模板修订']);
        $task_start_parameter_revise            =parameter_delete_annotation($result_one['参数修订']);
        $dict_variablename_value                =json_decode($result_one['变量设置']);
        $good_node_list                         =json_decode($result_one['作业运行列表']);//这个顺序可能不太对，第一步先矫正这个
        $real_node_relyARR_dict                 =json_decode($result_one['作业依赖']);  
        $dict_node_templaterevise               =json_decode($result_one['作业模板修订']);
        $dict_node_parameterrevise              =json_decode($result_one['作业参数修订']);

        //echo json_encode(['result' => $dict_variablename_value]);die();
        //log确定文件夹
        {
            /*project文件夹*/
            $project_absolute_dir=$base_path.$project_dir.'/';
            /*project_log文件夹*/
            $project_log_dir=$base_path.$project_dir.'/log_'.$project_id.'/';
            /*生成task_log文件夹，并确认有log文件夹*/
            $task_log_absolute_dir=$project_log_dir.$task_id.'/';  //似乎在slurm脚本中不需要绝对路径
            $task_log_absolute_dir = preg_replace('/\/+/', '/', $task_log_absolute_dir);    // 替换 // 为 /
            $task_log_absolute_dir = preg_replace('/\/\.\//', '/', $task_log_absolute_dir);// 替换 /./ 为 /
            if (!file_exists($task_log_absolute_dir) && !mkdir($task_log_absolute_dir, 0777, true)) {http_response_code(400);echo json_encode(['error' => 'task_log_dir文件夹创建失败']);die();}
        }
        
        
        //1. structure排序节点，有依赖的节点往后排,节点循环为异常，抛出错误*/
        if(strpos($task_module_id, 'structure_') === 0){
            function topologicalSort($allNodes,$dependencies) {
                /*{"node_tlxfm027hb":["node_rjmtm73q89","node_tqksqyandg","node_bjgunf1bld"],"node_a5s2ci3lj6":["node_rjmtm73q89"],"node_0b1l6pd440":["node_a5s2ci3lj6"],"node_2gtno6c2pm":["node_a5s2ci3lj6"],"node_m5tmx505as":["node_a5s2ci3lj6"],"node_vuv13spz5w":["node_0b1l6pd440"],"node_sgdmfgd5x7":["node_0b1l6pd440"]}我现在有很多node，每个node记录了node的依赖列表，如何整理一个最后的整体的node顺序，包含所有的node，没有依赖的在前，后面的出现时，其依赖都已经出现*/
                //
                /*你可以通过拓扑排序（Topological Sorting）来解决这个问题。拓扑排序是用于有向无环图（DAG）的排序算法，它确保依赖项在被依赖项之前出现。你所提供的 node 和它们的依赖关系正好构成了一个 DAG。
                    我们可以使用 Kahn 算法（基于入度）或 DFS 算法来实现拓扑排序。Kahn 算法的思路是通过遍历节点的入度（依赖数量），将入度为 0 的节点放入最终结果中，然后减少它们后续节点的入度。这个过程持续到所有节点都被遍历为止。*/                
                // 1. 计算每个节点的入度
                $inDegree = [];
                $adjList = [];
                // 初始化邻接表和入度
                foreach ($dependencies as $node => $deps) {
                    foreach ($deps as $dep) {
                        if (!isset($adjList[$dep])) { $adjList[$dep] = [];}
                        $adjList[$dep][] = $node;
                        if (!isset($inDegree[$node])) { $inDegree[$node] = 0;}
                        $inDegree[$node]++;
                    }
                }
                // 确保所有节点都在入度数组中，即使是入度为 0 的节点
                foreach ($dependencies as $node => $deps) {
                    if (!isset($inDegree[$node])) {$inDegree[$node] = 0;}
                    foreach ($deps as $dep) {if (!isset($inDegree[$dep])) { $inDegree[$dep] = 0; }}
                }
            
                // 2. 将所有入度为 0 的节点加入队列
                $queue = [];
                foreach ($inDegree as $node => $degree) {if ($degree === 0) { $queue[] = $node; }}
                $result = [];
            
                // 3. 进行拓扑排序
                while (!empty($queue)) {
                    $node = array_shift($queue);
                    $result[] = $node;
                    if (isset($adjList[$node])) {
                        foreach ($adjList[$node] as $neighbor) {
                            $inDegree[$neighbor]--;
                            if ($inDegree[$neighbor] === 0) {$queue[] = $neighbor;}
                        }
                    }
                }
            
                // 4. 检查是否所有节点都被排序了（有环则无法全部排序）
                if (count($result) === count($inDegree)) {
                    // 将没有依赖的节点放到结果前面
                    $noDependencyNodes = array_diff($allNodes, $result);
                    return array_merge($noDependencyNodes, $result); // 返回拓扑排序结果
                } // 返回拓扑排序结果
                else {return false; } // 返回 false 表示有循环依赖
                /*/ 示例用法
                $dependencies = [
                    "node_tlxfm027hb" => ["node_rjmtm73q89", "node_tqksqyandg", "node_bjgunf1bld"],
                    "node_a5s2ci3lj6" => ["node_rjmtm73q89"],
                    "node_0b1l6pd440" => ["node_a5s2ci3lj6"],
                    "node_2gtno6c2pm" => ["node_a5s2ci3lj6"],
                    "node_m5tmx505as" => ["node_a5s2ci3lj6"],
                    "node_vuv13spz5w" => ["node_0b1l6pd440"],
                    "node_sgdmfgd5x7" => ["node_0b1l6pd440"]
                ];
                
                $sortedNodes = topologicalSort($dependencies);
                
                if ($sortedNodes !== false) {
                    echo "拓扑排序结果：" . implode(", ", $sortedNodes) . PHP_EOL;
                } else {
                    echo "图中存在循环依赖，无法进行拓扑排序" . PHP_EOL;
                }
                */                            
            }
            
            $good_node_list=topologicalSort($good_node_list,$real_node_relyARR_dict);     //这个$good_node_list2顺序是矫正过的，所有带依赖的都往后排
            if ($good_node_list !== false) {} 
            else { http_response_code(500);  echo json_encode(['error' => 'DAG图中存在循环依赖，无法进行拓扑排序(Kahn)']);die();}
        }
       

        //2. 检测多输入文件，直接分析所有变量，如果变量中含有{*}则指示多输入文件，这样的变量最多拥有一个。且这样的变量内部只能有一个{*}
        $multi_input_variable='';$multi_input_variable_value='';
        $multi_keys_num = 0;
        foreach ($dict_variablename_value as $key => $value) {
            if (is_string($value) && strpos($value, '{*}') !== false) {
                $multi_keys_num++; 
                //计算$value中{*}字符的数量
                $start_count = preg_match_all('/\{\*\}/', $value, $matches);
                if ($start_count!=1){http_response_code(400);echo json_encode(['error' => "变量只允许使用一个多输入指示符{*}，当前为{$start_count} "]);die();}
                $multi_input_variable=$key;$multi_input_variable_value=$value;
            }
        }
        if ($multi_keys_num>1){http_response_code(400);echo json_encode(['error' => "只能有1个变量含有{*}，当前为{$multi_keys_num}"]);die();} 
            
        //3.//分析最高级模块的内容
        $task_module_INFOs=fetch_id($conn,$task_module_id,'*'); 
        $task_module_template=parameter_delete_annotation($task_module_INFOs['模板预设']);        //模板预设 根据 模板修订 得到修订后的模板
        $task_module_parameter=parameter_delete_annotation($task_module_INFOs['参数预设']);      //参数预设 根据 参数修订 得到修订后的参数
        $task_module_name=$task_module_INFOs['名称']??"未命名模块";
        
        $task_module_template_good         =template_preset_revise($task_module_template,$task_start_parameter_revise);             //模板自己修订后
        $task_module_parameter_good         =parameter_preset_revise($task_module_parameter,$task_start_parameter_revise);          //参数自己修订后
        $task_module_template_parameter_good=template_repalce_para($task_module_template_good,$task_module_parameter_good);    //模板用参数修订后  
        $task_module_template_parameter_variable_good=replace_template_by_variable($task_module_template_parameter_good,$dict_variablename_value);             //模板用参数和变量修订后
        

        //4.如果为多输入{*}，判断真正的输入文件数量，先判断最底层的文件夹是哪里
        //具体的，将模板中的内容替换参数得到完整输入。即按照空格分隔完整的输入，存在{*}的part，分离最后一个斜线/之前的内容，从而确定输入的文件夹
        $name_list_len=1;$name_list=['单一输入'];$name_pure_list=['单一输入'];
        if ($multi_keys_num==1){  //该步骤生成一个变量名字为$name_list
            function extractMatchingName($star_name, $file_name) {
                if ($star_name=="{*}"){return [$file_name, $file_name]; }
                elseif (str_starts_with($star_name, "{*}")){
                    //如{*}.sra
                    $suffix=substr($star_name, 3);
                    if(str_ends_with($file_name, $suffix)){
                        $extracted = substr($file_name, 0, -strlen($suffix)); // 去掉后缀部分
                        return [$file_name, $extracted];
                    }
                    
                }
                elseif(str_ends_with($star_name, "{*}")){
                    //如SRR{*}
                    $prefix=substr($star_name, 0, -3);
                    if(str_starts_with($file_name, $prefix)){
                        $extracted = substr($file_name, strlen($prefix)); // 去掉前缀部分
                        return [$file_name, $extracted];
                    }
                }
                else{
                    $pre_suffix = explode("{*}", $star_name);
                    $prefix=$pre_suffix[0];
                    $suffix=$pre_suffix[1];
                    if (str_starts_with($file_name, $prefix) && str_ends_with($file_name, $suffix)){
                        $extracted = substr($file_name, strlen($prefix), -strlen($suffix)); // 去掉前后缀
                        return [$file_name, $extracted];
                    }
                }
                return [null, null];
            }            
            
            if(empty($task_module_template_parameter_variable_good) || trim($task_module_template_parameter_variable_good)==''){$dir_freename=$project_absolute_dir.'/'.$multi_input_variable_value;}
            else if (strpos($task_module_template_parameter_variable_good, '{*}') !== false){
                $list = explode(" ", $task_module_template_parameter_variable_good);
                $reversedList = array_reverse($list); // 倒序数组
                foreach  ($reversedList as $value) {if (is_string($value) && strpos($value, '{*}') !== false) {$dir_freename=$project_absolute_dir.$value;break;}}
            }
            else{
                 http_response_code(400);echo json_encode(['error' => '通配符{*}涉及目录操作，但模板中未设置输入文件']);die(); 
            }
            //if(empty($star_name)){$star_name=$multi_input_variable_value;}   //未填写模板，直接就是在项目目录，直接使用“SRR{*}”等去匹配
            // 找到最后一个 / 的位置
            $lastSlashPos = strrpos($dir_freename, '/');
            if ($lastSlashPos === false) { http_response_code(400);echo json_encode(['error' => '路径格式错误']);die();  }
            // 分离路径
            $directoryPath = substr($dir_freename, 0, $lastSlashPos).'/'; // 提取路径
            $directoryPath = preg_replace('/\/+/', '/', $directoryPath);    // 替换 // 为 /
            $directoryPath = preg_replace('/\/\.\//', '/', $directoryPath);// 替换 /./ 为 /
     
            //分离文件名
            $star_name = substr($dir_freename, $lastSlashPos + 1); // 提取文件名部分（包含通配符）
            
            //判断路径存在
            if (!is_dir($directoryPath)) { http_response_code(400);echo json_encode(['error' => '通配符{*}涉及目录操作，未指定一个有效目录：<br>'.$directoryPath]);die(); } 
            elseif (!is_readable($directoryPath)) {http_response_code(400);echo json_encode(['error' => '目录存在但不可读：'.$directoryPath]);die();;  } 
             
            // 扫描目录中的所有文件
            $file_names = scandir($directoryPath); 
            $name_list=[];$name_pure_list=[];$i=0;   #$name_list是路径最后/后的文件名,$name_pure是{*}替换的内容
            foreach ($file_names as $one_file_name) {
                if($one_file_name=='.'||$one_file_name=='..'){continue;}
                $i+=1;
                
                // 检查文件名是否符合通配符模式
                [$one_name,$one_name_pure]=extractMatchingName($star_name,$one_file_name);
                if($one_name){$name_list[]=$one_name;$name_pure_list[]=$one_name_pure;}                
            }
            if($name_list==[] ){http_response_code(400);echo json_encode(['error' => '未找到标识符对应文件：'.$star_name]);die(); }
            //else{echo json_encode(['status' => 'success','result' => $name_list]);die();}
            $name_list_len = count($name_list);
        }
        
        //5.生成一个主文件slm
        $slurm_txt = "#!/bin/bash
#SBATCH --chdir={$task_log_absolute_dir}        
#SBATCH --job-name=job0_{$user_id}  # 总作业，一般情况下1个子作业，批量多输入生成多个子作业
#SBATCH --output=./job0.log  
#SBATCH --error=./job0.err  
#SBATCH --nodes=1  
#SBATCH --ntasks=1  
echo '总作业开始'
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL1\tjob0\t\$SLURM_JOB_ID\tstart\t{$task_id}\" >> {$base_path}/.job_ids.txt     
        ";
        $ii=0 ;
        while ($ii<$name_list_len){
            $one_name=$name_list[$ii];
            $ii++;
            $slurm_txt.="\n
#提交子作业, 输入文件：{$one_name}
job{$ii}=$(sbatch --parsable  ./job{$ii}.sh)
echo job1=\${job{$ii}}
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL2\tjob{$ii}\t\${job{$ii}}\tcreate\t{$task_id}\t{$one_name}\" >> {$base_path}/.job_ids.txt
";
        }
        //
        $slurm_txt.="\n
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL1\tjob0\t\$SLURM_JOB_ID\tend\t{$task_id}\" >> {$base_path}/.job_ids.txt  
";
        //
        $slurm_file = "{$task_log_absolute_dir}job0.sh";
        if (file_put_contents($slurm_file, $slurm_txt) !== false) {  } 
        else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  }      
        
        //6.生成子文件slm
        $ii=0 ;
        while ($ii<$name_list_len){
            $one_name=$name_list[$ii];
            $ii++;
            $slurm_txt="#!/bin/bash
#SBATCH --chdir={$task_log_absolute_dir}            
#SBATCH --job-name=job{$ii}_{$user_id}
#SBATCH --output=./job{$ii}.log 
#SBATCH --error=./job{$ii}.err
#SBATCH --nodes=1  
#SBATCH --ntasks=1
echo '子作业开始，{$one_name}'
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL2\tjob{$ii}\t\$SLURM_JOB_ID\tstart\t{$task_id}\" >> {$base_path}/.job_ids.txt
";
            $iii = 0;
            $rely_node_str='';$dependency_str=''; // 临时存储节点名到实际 Job ID 的映射
            //
            if(strpos($task_module_id, 'script_') === 0 || strpos($task_module_id, 'stream_') === 0){
                $slurm_txt.="\n
#提交最小基础作业, {$task_module_id}无依赖
job{$ii}_1=$(sbatch --parsable  ./job{$ii}_1.sh)
echo job{$ii}_1=\${job{$ii}_1}
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL3\tjob{$ii}_1\t\${job{$ii}_1}\tcreate\t{$task_id}\" >> {$base_path}/.job_ids.txt
";
            }
            else if(strpos($task_module_id, 'structure_')=== 0 ){   
                foreach ($good_node_list as $onenode) {
                    $iii++;
                    if (property_exists($real_node_relyARR_dict, $onenode)) {
                        $onenode_rely_arr = $real_node_relyARR_dict->$onenode;   //如果$onenode存在于$real_node_relyARR_dict，获取其值并赋值给 $onenode_rely_arr
                        $onenode_rely_serial_arr=[];$onenode_rely_jobid_arr=[];
                        
                        foreach($onenode_rely_arr as $one_reply){
                            //计算node所属的序号
                            $one_reply_serial = array_search($one_reply, $good_node_list)+1;
                            $onenode_rely_serial_arr[]="{$one_reply}(job{$ii}_{$one_reply_serial})";
                            $onenode_rely_jobid_arr[]="\$job{$ii}_{$one_reply_serial}";
                        }
                        
                        $rely_node_str=implode(',',$onenode_rely_serial_arr);
                        $rely_node_str="\n#作业依赖node：".$rely_node_str;
                        $dependency_str=implode(',',$onenode_rely_jobid_arr);
                        $dependency_str="--dependency=afterok:{$dependency_str}";
                    }    
                    $dependency_str2 = ($dependency_str ?? '') . '.';
                    $slurm_txt.="\n
#提交最小基础作业, node：{$onenode}{$rely_node_str}
job{$ii}_{$iii}=$(sbatch {$dependency_str} --parsable  ./job{$ii}_{$iii}.sh)
echo job{$ii}_{$iii}=\${job{$ii}_{$iii}}
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL3\tjob{$ii}_{$iii}\t\${job{$ii}_{$iii}}\tcreate\t{$task_id}\" >> {$base_path}/.job_ids.txt
";
                }
            }    
            else{http_response_code(500);echo json_encode(['error' => 'task类型错误'.$task_module_id]);die(); }
            //
            $slurm_txt.="\n
time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"\$time\tL2\tjob{$ii}\t\$SLURM_JOB_ID\tend\t{$task_id}\" >> {$base_path}/.job_ids.txt            
";
            //
            $slurm_file = "{$task_log_absolute_dir}job{$ii}.sh";
            if (file_put_contents($slurm_file, $slurm_txt) !== false) {  } 
            else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  }                
        }    

        //7.生成最小作业单元文件slm        
        $ii=0;$dict_node_info=[];
        while ($ii<$name_list_len){
            $one_name=$name_list[$ii];
            $one_name_pure=$name_pure_list[$ii];
            $ii++;
            //如果task的模块类型为命令脚本, 只有
            if (strpos($task_module_id, 'script_') === 0 ){
                /////////////////////////////
                $job_nameid="job{$ii}_1";
                [$addition_str,$script_threads]=generate_script($task_id,$conn,$base_path,$job_nameid,$task_log_absolute_dir,$task_module_id,['',''],[$task_start_template_revise,$task_start_parameter_revise],$dict_variablename_value,$one_name_pure);
                $slurm_txt="#!/bin/bash
#SBATCH --chdir={$task_log_absolute_dir}            
#SBATCH --job-name={$job_nameid}_{$user_id}
#SBATCH --output=./{$job_nameid}.log 
#SBATCH --error=./{$job_nameid}.err
#SBATCH --nodes=1  
#SBATCH --ntasks={$script_threads} 
echo '上级子作业：{$one_name}'
cd ../../
pwd

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元开始：\$time\"
echo \"\$time\tL3\tjob{$ii}_1\t\$SLURM_JOB_ID\tstart\t{$task_id}\t1\" >> {$base_path}/.job_ids.txt

{$addition_str}

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元完成：\$time\"
echo \"\$time\tL3\tjob{$ii}_1\t\$SLURM_JOB_ID\tend\t{$task_id}\" >> {$base_path}/.job_ids.txt
                ";                                          
                /////////////////////////////
                $slurm_file = "{$task_log_absolute_dir}{$job_nameid}.sh";
                if (file_put_contents($slurm_file, $slurm_txt) !== false) {  } 
                else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  } 
            }
            //如果task的模块类型为线性流程
            if (strpos($task_module_id, 'stream_') === 0 ){
                //如果task的类型为线性流程先对“流程内容”进行解析，定义字典$dict_node_info，用于查询node对应的子模块的信息
                $stream_content=        $task_module_INFOs['流程内容'];
                $stream_threads=        $task_module_INFOs['线程分配']?? 1;
                $stream_content_arr         =explode("_;;;_\n",$stream_content);   
                $addition_str='';
                $job_nameid="job{$ii}_1";
                /////////////////
                foreach ($stream_content_arr as $oneline){
                    $oneline_arr=explode("_|||_",$oneline);
                    $one_node                =trim($oneline_arr[0]); 
                    if (!in_array($one_node, $good_node_list)) {continue; }

                    $one_node_item           =trim($oneline_arr[2]);                //$dict_node_info[$one_node]['node_itemid']               =$one_child_item;       
                    $one_node_template_revise     =trim($oneline_arr[3]);                //$dict_node_info[$one_node]['node_template_revise']     =$one_template_revise;
                    $one_node_parameter_revise    =trim($oneline_arr[4]);                //$dict_node_info[$one_node]['node_parameter_revise']    =$one_parameter_revise;
                    /////////////////////////////
                    //临时修订
                    $onenode_template_revise='';$onenode_parameter_revise='';
                    if ($dict_node_templaterevise && property_exists($dict_node_templaterevise, $one_node)) {$onenode_template_revise = $dict_node_templaterevise->$one_node;}    
                    if ($dict_node_parameterrevise && property_exists($dict_node_parameterrevise, $one_node)) {$onenode_parameter_revise = $dict_node_parameterrevise->$one_node;} 
                    
                    [$addition_one_str,$script_threads]=generate_script($task_id,$conn,$base_path,$job_nameid,$task_log_absolute_dir,$one_node_item,[$one_node_template_revise,$one_node_parameter_revise],[$onenode_template_revise,$onenode_parameter_revise],$dict_variablename_value,$one_name_pure);
                    $addition_str.=$addition_one_str;
                }
                $good_node_list_len=count($good_node_list);
                ////////////////////////
                $slurm_txt="#!/bin/bash
#SBATCH --chdir={$task_log_absolute_dir}            
#SBATCH --job-name={$job_nameid}_{$user_id}
#SBATCH --output=./{$job_nameid}.log 
#SBATCH --error=./{$job_nameid}.err
#SBATCH --nodes=1  
#SBATCH --ntasks={$stream_threads} 
echo '上级子作业：{$one_name}'
cd ../../
pwd

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元开始：\$time\"
echo \"\$time\tL3\tjob{$ii}_1\t\$SLURM_JOB_ID\tstart\t{$task_id}\t{$good_node_list_len}\" >> {$base_path}/.job_ids.txt

{$addition_str}

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元完成：\$time\"
echo \"\$time\tL3\tjob{$ii}_1\t\$SLURM_JOB_ID\tend\t{$task_id}\" >> {$base_path}/.job_ids.txt
";
                $slurm_file = "{$task_log_absolute_dir}{$job_nameid}.sh";
                if (file_put_contents($slurm_file, $slurm_txt) !== false) {  } 
                else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  }     
            }
            //如果task的模块类型为网络结构
            
            if (strpos($task_module_id, 'structure_') === 0 ){
                //如果task的类型为网络结构先对“网络内容”进行解析，定义字典$dict_node_info，用于查询node对应的子模块的信息
                $structure_content=$task_module_INFOs['网络内容'];
                $structure_content_arr         =explode("_;;;_\n",$structure_content);   
                foreach ($structure_content_arr as $oneline){
                    $oneline_arr=explode("_|||_",$oneline);
                    $one_node                =trim($oneline_arr[0]); 
                    $one_child_item          =trim($oneline_arr[2]);                $dict_node_info[$one_node]['node_itemid']               =$one_child_item;       
                    $one_template_revise     =trim($oneline_arr[3]);                $dict_node_info[$one_node]['node_template_revise']     =$one_template_revise;
                    $one_parameter_revise    =trim($oneline_arr[4]);                $dict_node_info[$one_node]['node_parameter_revise']    =$one_parameter_revise;
                }
                ////////////////////////            
                $iii = 0;
                foreach ($good_node_list as $onenode) {
                    $iii++;
                    $job_nameid="job{$ii}_{$iii}";
                    //
                    /////////////////////////////
                    $child_itemid=$dict_node_info[$onenode]['node_itemid'];//此时有两种可能，script或stream
                    //网络结构里的线性流程/命令脚本的info
                    $addition_str='';$onenode_thread=1;
                    if(strpos($child_itemid, 'stream_') === 0 ){ 
                        $itemid_INFOs=fetch_id($conn,$child_itemid,'*'); 
                        $onenode_thread        =$itemid_INFOs['线程分配']?? 1;;     //如果子模块中含有script，覆盖其线程预设
                        $child_template     =parameter_delete_annotation($itemid_INFOs['模板预设']);
                        $child_parameter    =parameter_delete_annotation($itemid_INFOs['参数预设']);
                        $stream_content     =$itemid_INFOs['流程内容'];         $stream_content_arr         =explode("_;;;_\n",$stream_content);   
                        //
                        foreach ($stream_content_arr as $oneline){
                            $oneline_arr=explode("_|||_",$oneline);
                            $script_itemid              =$oneline_arr[2];               
                            $script_template_revise     =$oneline_arr[3];               
                            $script_parameter_revise    =$oneline_arr[4]; 
                            //
                            [$addition_one_str,$script_threads]=generate_script($task_id,$conn,$base_path,$job_nameid,$task_log_absolute_dir,$script_itemid,[$script_template_revise,$script_parameter_revise],['',''],$dict_variablename_value,$one_name_pure);
                            $addition_str.=$addition_one_str;
                        }    
                        $step_num=count($stream_content_arr);
                    }
                    else{
                        //网络结构里的修订
                        $one_template_revise=$dict_node_info[$onenode]['node_template_revise'];
                        $one_parameter_revise=$dict_node_info[$onenode]['node_parameter_revise'];
                        //临时修订
                        $onenode_template_revise='';$onenode_parameter_revise='';
                        if ($dict_node_templaterevise && property_exists($dict_node_templaterevise, $one_node)) {$onenode_template_revise = $dict_node_templaterevise->$one_node;}    
                        if ($dict_node_parameterrevise && property_exists($dict_node_parameterrevise, $one_node)) {$onenode_parameter_revise = $dict_node_parameterrevise->$one_node;}                           
                        [$addition_one_str,$onenode_thread]=generate_script($task_id,$conn,$base_path,$job_nameid,$task_log_absolute_dir,$child_itemid,[$one_template_revise,$one_parameter_revise],[$onenode_template_revise,$onenode_parameter_revise],$dict_variablename_value,$one_name_pure);   //script的id，预定的修订，临时修订, 变量，
                        //
                        $addition_str.=$addition_one_str;
                        $step_num=1;
                    }
                
                    //
                    $slurm_txt="#!/bin/bash
#SBATCH --chdir={$task_log_absolute_dir}            
#SBATCH --job-name={$job_nameid}_{$user_id}
#SBATCH --output=./{$job_nameid}.log 
#SBATCH --error=./{$job_nameid}.err
#SBATCH --nodes=1  
#SBATCH --ntasks={$onenode_thread}
echo '上级子作业：{$one_name}'
cd ../../
pwd

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元开始：\$time\"
echo \"\$time\tL3\tjob{$ii}_{$iii}\t\$SLURM_JOB_ID\tstart\t{$task_id}\t{$step_num}\" >> {$base_path}/.job_ids.txt

{$addition_str}

time=$(date +'%Y-%m-%d_%H:%M:%S')
echo \"最小作业单元完成：\$time\"
echo \"\$time\tL3\tjob{$ii}_{$iii}\t\$SLURM_JOB_ID\tend\t{$task_id}\" >> {$base_path}/.job_ids.txt
";
                    /////////////////////////////
                    $slurm_file = "{$task_log_absolute_dir}{$job_nameid}.sh";
                    if (file_put_contents($slurm_file, $slurm_txt) !== false) {  } 
                    else {http_response_code(500);echo json_encode(['error' => 'slm文件新建失败']);die();  }                    
                }
            }    
        }
        

        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        echo json_encode(['status' => 'success','result' => '生成了slurm脚本，请检查确认，下一步为提交作业']);die();
    }
?>      

















