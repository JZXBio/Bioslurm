<?php

//链接数据库

        {
            $dbhost = '192.168.200.230';  // mysql服务器主机地址.............改为需要的IP地址
            $dbuser = 'bioslurm';            // mysql用户名
            $dbpass = '改为真实密码';          // mysql用户名密码，可以在宝塔面板中设置
            $conn = mysqli_connect($dbhost, $dbuser, $dbpass); 
            $conn->set_charset("utf8mb4");                     //读中文库，写中文库，因为PHP7.4不支持mysql_query
            //mysql_query("set character set 'utf8'");    //读中文库，为PHP5.4可用
            //mysql_query("set names 'utf8'");            //写中文库，为PHP5.4可用
            mysqli_select_db($conn, 'bioslurm' );
        } 
{        
    // 检查表是否存在，如果不存在则创建
    $tableName = '用户信息';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `用户UUID` CHAR(36),
            `姓名拼音` VARCHAR(100),
            `用户名自动生成` VARCHAR(50),
            `邮箱` VARCHAR(100) UNIQUE,
            `密码` VARCHAR(100),
            `创建时间` VARCHAR(20),
            `更新时间` VARCHAR(20),
            `存储变量1` TEXT,
            `设置_文本编辑器` VARCHAR(20),
            `设置_文本编辑器_自动换行` VARCHAR(20)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
            echo "表 '$tableName' 创建成功";
        } else {
            echo "创建表 '$tableName' 错误: " . $conn->error;
        }
    }
    $tableName = '预设1_命令脚本';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `创建时间` VARCHAR(20),
            `识别码` VARCHAR(30),  
            `唯一识别码` VARCHAR(30) NOT NULL UNIQUE,              
            `名称` VARCHAR(100),
            `分类1` VARCHAR(100),
            `分类2` VARCHAR(100),
            `分类3` VARCHAR(100),    
            `描述1` VARCHAR(100),
            `描述2` VARCHAR(100),
            `描述3` VARCHAR(100),                
            `创建者` VARCHAR(100),
            `拥有者` VARCHAR(100),
            `共享权限` VARCHAR(100),
            `编辑权限` VARCHAR(100),
            `编辑历史` VARCHAR(100),            
            `更新时间` VARCHAR(20),
            `系统备注1` VARCHAR(100),  
            `系统备注2` VARCHAR(100),              
            `环境类型` VARCHAR(100),
            `环境预备` text,  
            `运行模式` VARCHAR(100), 
            `线程分配` VARCHAR(100), 
            `命令类型` VARCHAR(100), 
            `命令名称` VARCHAR(100), 
            `命令地址` text, 
            `模板预设` text,   
            `参数预设` text, 
            `变量预设` text, 
            `结果预设` text,             
            `备注信息` text, 
            `脚本内容` mediumtext,
            `完成整备` text,  
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    }    
    $tableName = '预设2_线性流程';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `创建时间` VARCHAR(20),
            `识别码` VARCHAR(30),  
            `唯一识别码` VARCHAR(30) NOT NULL UNIQUE,              
            `名称` VARCHAR(100),
            `分类1` VARCHAR(100),
            `分类2` VARCHAR(100),
            `分类3` VARCHAR(100),    
            `描述1` VARCHAR(100),
            `描述2` VARCHAR(100),
            `描述3` VARCHAR(100),                
            `创建者` VARCHAR(100),
            `拥有者` VARCHAR(100),
            `共享权限` VARCHAR(100),
            `编辑权限` VARCHAR(100),
            `编辑历史` VARCHAR(100),            
            `更新时间` VARCHAR(20),
            `系统备注1` VARCHAR(100),  
            `系统备注2` VARCHAR(100),              
            `线程分配` VARCHAR(100), 
            `模板预设` text,   
            `参数预设` text, 
            `变量预设` text, 
            `结果预设` text,             
            `备注信息` text, 
            `流程内容` mediumtext            
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    }   
    $tableName = '预设3_网络结构';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `创建时间` VARCHAR(20),
            `识别码` VARCHAR(30),  
            `唯一识别码` VARCHAR(30) NOT NULL UNIQUE,              
            `名称` VARCHAR(100),
            `分类1` VARCHAR(100),
            `分类2` VARCHAR(100),
            `分类3` VARCHAR(100),    
            `描述1` VARCHAR(100),
            `描述2` VARCHAR(100),
            `描述3` VARCHAR(100),                
            `创建者` VARCHAR(100),
            `拥有者` VARCHAR(100),
            `共享权限` VARCHAR(100),
            `编辑权限` VARCHAR(100),
            `编辑历史` VARCHAR(100),            
            `更新时间` VARCHAR(20),
            `系统备注1` VARCHAR(100),  
            `系统备注2` VARCHAR(100),              
            `线程分配` VARCHAR(100), 
            `模板预设` text,   
            `参数预设` text, 
            `变量预设` text, 
            `结果预设` text,             
            `备注信息` text, 
            `网络内容` mediumtext            
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    }   
    $tableName = '执行1_项目列表';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `创建时间` VARCHAR(20),
            `识别码` VARCHAR(30),  
            `唯一识别码` VARCHAR(30) NOT NULL UNIQUE,              
            `名称` VARCHAR(100),
            `描述` VARCHAR(255),
            `创建者` VARCHAR(100),
            `拥有者` VARCHAR(100),
            `共享权限` VARCHAR(100),
            `编辑权限` VARCHAR(100),
            `编辑历史` VARCHAR(100),            
            `更新时间` VARCHAR(20),
            `系统备注1` VARCHAR(100),  
            `系统备注2` VARCHAR(100),              
            `项目目录` text,   
            `备注信息` text
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    } 
    $tableName = '执行2_任务列表';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `创建时间` VARCHAR(20),
            `识别码` VARCHAR(30),  
            `唯一识别码` VARCHAR(30) NOT NULL UNIQUE,              
            `状态` VARCHAR(255),
            `创建者` VARCHAR(100),
            `拥有者` VARCHAR(100),
            `共享权限` VARCHAR(100),
            `编辑权限` VARCHAR(100),
            `编辑历史` VARCHAR(100),            
            `更新时间` VARCHAR(20),
            `系统备注1` VARCHAR(100),  
            `系统备注2` VARCHAR(100),   
            `所属项目编号` VARCHAR(100),   
            `所属项目目录` text,   
            `线程分配` VARCHAR(100), 
            `使用模块` VARCHAR(100), 
            `模块名称` VARCHAR(100), 
            `模板修订` text, 
            `参数修订` text, 
            `变量设置` text, 
            `作业运行列表` text,        
            `作业依赖` text,   
            `作业模板修订` text,   
            `作业参数修订` text,   
            `备注信息` text,
            `slurm脚本内容` text
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    }     
    $tableName = '执行3_作业列表';
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($checkTable->num_rows == 0) {
        // 表不存在，创建新表
        $createTableSQL = "CREATE TABLE `$tableName` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `作业slurm编号` VARCHAR(20),
            `作业层级` VARCHAR(20),
            `作业编号` VARCHAR(20),
            `创建时间` VARCHAR(20),
            `开始时间` VARCHAR(20),
            `中间状态` text,
            `结束时间` VARCHAR(20),
            `更新时间` VARCHAR(20),          
            `使用时间` VARCHAR(20),          
            `状态` VARCHAR(20), 
            `拥有者` VARCHAR(100),
            `文件目录` text,   
            `项目编号` VARCHAR(100),
            `任务编号` VARCHAR(100),
            `模块编号` VARCHAR(100),
            `模块编号` VARCHAR(255),
            `样本名称` VARCHAR(100),
            `步骤数量` VARCHAR(100),
            `系统备注` VARCHAR(100)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if ($conn->query($createTableSQL) === TRUE) {
        } else {
            http_response_code(500);  echo json_encode(['error' => '无法完成数据库初始化']);die();
        }
    }    
}    
//读取数据
//主要应用在share那个功能上，频繁查询太啰嗦
function database_query(mysqli $conn, string $sql, array $params = []): ?array {
    /**
     * 执行安全的 SELECT 查询，返回结果数组
     * 
     * @param mysqli $conn 数据库连接
     * @param string $sql SQL 查询语句（可包含 ? 占位符）
     * @param array $params 绑定参数（数组，如 ['s' => 'value'] 或 ['i' => 123]）
     * @return array|null 查询结果（成功返回数组，失败返回 null）
     */
    // 准备语句
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log("数据库准备语句失败: " . mysqli_error($conn));
        return null;
    }

    // 绑定参数（如果有）
    if (!empty($params)) {
        $types = '';
        $values = [];
        foreach ($params as $param) {
            $types .= $param['type'];
            $values[] = $param['value'];
        }
        mysqli_stmt_bind_param($stmt, $types, ...$values);
    }

    // 执行查询
    if (!mysqli_stmt_execute($stmt)) {
        error_log("查询执行失败: " . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return null;
    }

    // 获取结果集
    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        error_log("获取结果集失败: " . mysqli_error($conn));
        mysqli_stmt_close($stmt);
        return null;
    }

    // 返回关联数组
    $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_free_result($result);
    mysqli_stmt_close($stmt);

    return $data;
}

//插入新数据
//主要应用在share那个功能上，频繁查询太啰嗦
function database_insert(mysqli $conn, string $sql, array $params = []) {
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;

    if (!empty($params)) {
        $types = '';
        $values = [];
        foreach ($params as $param) {
            $types .= $param['type'];
            $values[] = $param['value'];
        }
        mysqli_stmt_bind_param($stmt, $types, ...$values);
    }

    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $success;

}


//根据id查询数据
function fetch_id($conn,$item_id,$search_content){
    if (strpos($item_id, 'script_') === 0) {$sheet_name='预设1_命令脚本';}
    else if (strpos($item_id, 'stream_') === 0) {$sheet_name='预设2_线性流程';}
    else if (strpos($item_id, 'structure_') === 0) {$sheet_name='预设3_网络结构';}
    else if (strpos($item_id, 'project_') === 0) {$sheet_name='执行1_项目列表';}
    else if (strpos($item_id, 'task_') === 0) {$sheet_name='执行2_任务列表';}
    
    
    $sql = "SELECT {$search_content} FROM {$sheet_name} WHERE `唯一识别码` = ?";
    $stmt = mysqli_prepare($conn, $sql);if (!$stmt) {http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}
    
    mysqli_stmt_bind_param($stmt, 's', $item_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);if (!$result|| mysqli_num_rows($result) === 0) {http_response_code(500);  echo json_encode(['error' => '查询失败']);die();} // 获取结果
    while ($row = mysqli_fetch_assoc($result)) {  return $row;  }  
    mysqli_stmt_close($stmt);
}


//根据id查询数据
function fetch_slurmjobid($conn,$item_id,$userid,$search_content){
    $sql = "SELECT {$search_content} FROM 执行3_作业列表 WHERE `作业slurm编号` = ? and 拥有者=?";
    $stmt = mysqli_prepare($conn, $sql);if (!$stmt) {http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}
    mysqli_stmt_bind_param($stmt, 'ss', $item_id,$userid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);if (!$result|| mysqli_num_rows($result) === 0) {return false;} // 获取结果
    while ($row = mysqli_fetch_assoc($result)) {  return $row;  }  
    mysqli_stmt_close($stmt);
}









//删除数据
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
?>