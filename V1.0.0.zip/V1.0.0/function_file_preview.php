<?php
// 获取文件路径
if (isset($_GET['filename'])) {
    $file_path = $_GET['filename'];
    $max_size = 104857; // 1MB=1048576

    // 检查文件是否存在
    if (file_exists($file_path)) {
        // 读取文件的前1MB内容
        $handle = fopen($file_path, "r");
        if ($handle) {
            $content = fread($handle, $max_size);
            fclose($handle);

            // 设置响应头
            header("Content-Type: text/plain; charset=utf-8");
            echo $content;
        } else {
            // 读取文件时出错
            http_response_code(500);
            echo "文件读取失败";
        }
    } else {
        // 文件不存在时返回404
        http_response_code(404);
        echo "文件不存在";
    }
} else {
    // 没有提供文件名时返回400
    http_response_code(400);
    echo "未提供文件名";
}
