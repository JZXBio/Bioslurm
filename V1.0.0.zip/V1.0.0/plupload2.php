<?php  
// plupload2.php  
  
$targetDir = isset($_POST['targetDir']) ? $_POST['targetDir'] : '/tmp/';  
$chunkSize = 10 * 1024 * 1024; // 10MB, 与前端设置保持一致  
$uploadDir = $targetDir;// . 'uploads/';  
  
// 确保上传目录存在  
if (!is_dir($uploadDir)) {  
    mkdir($uploadDir, 0777, true);  
}  
  
// 获取文件信息  
$fileName = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';  
$chunkIndex = isset($_REQUEST['chunk']) ? intval($_REQUEST['chunk']) : 0;  
$totalChunks = isset($_REQUEST['chunks']) ? intval($_REQUEST['chunks']) : 1;  
  
// 临时文件路径  
$tempFilePath = $uploadDir . $fileName . '.part' . $chunkIndex;  
$targetFilePath = $uploadDir . $fileName;  
  
// 保存分块文件  
if (move_uploaded_file($_FILES['file']['tmp_name'], $tempFilePath)) {  
    // 检查是否所有分块都已上传  
    $allChunksUploaded = true;  
    for ($i = 0; $i < $totalChunks; $i++) {  
        if (!file_exists($uploadDir . $fileName . '.part' . $i)) {  
            $allChunksUploaded = false;  
            break;  
        }  
    }  
  
    // 如果所有分块都已上传，则合并它们  
    if ($allChunksUploaded) {  
        $output = fopen($targetFilePath, 'wb');  
        for ($i = 0; $i < $totalChunks; $i++) {  
            $input = fopen($uploadDir . $fileName . '.part' . $i, 'rb');  
            while ($buff = fread($input, 4096)) {  
                fwrite($output, $buff);  
            }  
            fclose($input);  
            // 删除分块文件  
            unlink($uploadDir . $fileName . '.part' . $i);  
        }  
        fclose($output);  
  
        // 返回成功响应  
        echo json_encode(['status' => 'success', 'message' => '文件上传成功']);  
    } else {  
        // 返回继续上传的响应  
        echo json_encode(['status' => 'continue', 'message' => '继续上传分块']);  
    }  
} else {  
    // 返回上传失败的响应  
    echo json_encode(['status' => 'error', 'message' => '文件上传失败']);  
}  
?>