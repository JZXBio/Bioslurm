<?php
header('Content-Type: application/json');

try {
    // 1. 验证请求方法
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('仅支持 POST 请求');
    }

    // 2. 解析并验证输入
    $input = json_decode(file_get_contents('php://input'), true);
    if (json_last_error() !== JSON_ERROR_NONE || empty($input['dir_complete_path'])) {
        throw new Exception('无效的请求数据');
    }

    // 3. 严格过滤路径（防止路径遍历攻击）
    $requestedPath = $input['dir_complete_path'];
    
    // 3.1 移除连续斜杠和末尾斜杠（可选）
    $requestedPath = preg_replace('/\/+/', '/', rtrim($requestedPath, '/'));
    
    // 3.2 验证路径是否在允许的基目录内（关键安全措施！）
    //$basePath = realpath('/var/www/your_allowed_base_dir'); // 替换为你的实际基目录
    $targetPath = realpath($requestedPath);
    /*
    if ($targetPath === false || strpos($targetPath, $basePath) !== 0) {
        throw new Exception("非法路径访问: {$requestedPath}");
    }*/

    // 4. 验证目录存在且可读
    if (!is_dir($targetPath)) {
        throw new Exception("目录不存在: {$targetPath}");
    }
    if (!is_readable($targetPath)) {
        throw new Exception("目录不可读: {$targetPath}");
    }

    // 5. 强制使用 du 命令（如失败则报错）
    $command = "du -sb " . escapeshellarg($targetPath) . " 2>&1";
    $output = shell_exec($command);
    
    if (!preg_match('/^(\d+)\s+/', $output, $matches)) {
        throw new Exception("du 命令执行失败: " . trim($output));
    }

    // 6. 返回成功响应
    echo json_encode([
        'status' => 'success',
        'bytes' => (int)$matches[1],
        'path' => $targetPath
    ]);

} catch (Exception $e) {
    // 统一错误响应格式
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
