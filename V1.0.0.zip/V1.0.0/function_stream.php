<?php    
    session_start(); // 开始会话
    
    if (isset($_SESSION["user_uuid"])  &&  isset($_SESSION["user_email"]) &&  isset($_SESSION["user_name"]) &&  isset($_SESSION["user_name_id"]) ) {
        $navi_user_state= "
            <span style='font-size:xx-small;margin-left:50px'>欢迎, </span>{$_SESSION['user_name']}<span style='font-size:xx-small'> [{$_SESSION['user_email']}] </span> 
            <div style='display:inline-block'>
                <form  action='index.php' method='post'>
                    <input type='hidden'  name='action' ID='action' value='logout'></input><button id='logout'>[退出]</button>
                </form>    
            </div> ";
    }
    else{
        header("Location: index.php");  
        exit; // 确保重定向后停止脚本执行  
    }    

    $user_name_id=$_SESSION['user_name_id'];
    $folderPath = "/www/wwwroot/bioslurm/user/{$user_name_id}";  
    if (is_dir($folderPath)==false)  {  echo "用户未初始化，用户文件夹不存在。";  die();} 
    ///////////    
    $searchword='';
    if (isset($_GET["searchword"]) && $_GET["searchword"] !== ''){
        //if(strpos($_GET["searchword"], "script_") === 0){
            $searchword=$_GET["searchword"];//var_dump($_GET["searchword"] );
            //echo "searchword".$searchword; 
        //}
    }    
    else{$searchword='';}
?>


<!DOCTYPE  html>
<html  lang="en">
<head>
    <meta  charset="UTF-8">
    <meta  name="viewport"  content="width=device-width,  initial-scale=1.0">
    <title>BioSlurm生信服务器</title>
    <meta name="keywords" content="BioSlurm生信服务器">
    <meta name="description" content="BioSlurm生信服务器" >
    <link rel="icon" href="000_image/favicon.png" type="image/png">
    <script src="plug/jquery-3.1.1.min.js" type="text/javascript"></script>  
    <style>

        * {box-sizing: border-box;margin:0;padding:0;font-family: '微软雅黑', 'Microsoft YaHei', sans-serif; }
        body {font-family: sans-serif;min-width:300px;background-color: rgba(0,0,0,0.06);}/*background-color: rgba(0,0,0,0.03);*/
        .no_select {user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;}
        .can_select {user-select: text; -webkit-user-select: text; -moz-user-select: text; -ms-user-select: text;}
        .no_drag{-webkit-user-drag: none; -khtml-user-drag: none;-moz-user-drag: none; -o-user-drag: none;  user-drag: none;}
        .display_none{display:none}
        .grey_text{color:grey}
        #top_navigator {position:fixed;top:0;width: 100%;background-color:#005580;padding:4px;margin:0 0 auto 0;height:30px;color:white;z-index:111111}
        #top_navigator a{color:white; text-decoration:none; margin:0 10px;font-size:17px;}
        #top_navigator a:hover{color:#ffff99}
        #top_navigator_title_name{font-weight:500;text-shadow: 0 0 1px black, 1px 1px 5px black;}
        #top_navigator_current_time{font-size:xx-small}
        #logout{background: none;border:none;padding: 0;font: inherit;cursor: pointer; color: rgb(200,200,200);outline: none;display:inline-block; font-size:xx-small; }
        #logout:hover{color:red}
        
        #main_content{margin:50px 25px 20px 75px;border:solid 0px red;transition:1s;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:left;align-items:top}
        #main_content_part1{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s;flex:none;min-width:300px;transition:1s}
        #stream_show_head{color:#336699;font-size:20px;font-weight:bold;margin-bottom:20px;height:28px;cursor:pointer}
        #stream_show_option{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:left;align-items:center}
        #stream_show_option_inner1{;flex:none;;height:28px;padding:0;}
        .stream_show_option_inner1_button{border: none;;font: inherit;color: inherit;text-decoration: none;cursor: pointer;outline: none;
            background-color:rgba(0, 153, 204,0.4); ;;margin:1px;height:40px;padding: 3px 6px 20px 6px;font-size:12px;
            clip-path: polygon(0% 0%, 100% 0%, 100% 70%, 50% 70%, 0% 70%, 0% 0%);border-radius:4px 4px 0 0;transition:0.5s}
        .stream_show_option_inner1_button:hover{background-color:rgba(0, 153, 204,0.6);clip-path: polygon(0% 0%, 100% 0%, 100% 70%, 50% 100%, 0% 70%, 0% 0%);}
        .stream_show_option_inner1_button:active{background-color:rgba(255, 102, 153,0.4);}
        .button_polygon{clip-path: polygon(0% 0%, 100% 0%, 100% 70%, 50% 100%, 0% 70%, 0% 0%);}
        #stream_show_content{}
        
        #stream_show_option_inner2{padding:0 20px;;height:28px;}
        #stream_show_option_inner2_inner{border:solid 0px blue;height:100%;;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:left;align-items:bottom}
        #stream_show_option_inner2_inner>div{height:22px;border:solid 0px green;height:100%;position:relative}
        #stream_show_option_inner2_inner input{height:20px;margin-top:6px;border:solid 1px rgba(0,0,0,0.2);padding:1px 24px 1px 4px;width:120px}
        #stream_show_option_inner2_inner_div{position:absolute;right:0;top:6px;width:20px;height:20px;cursor:pointer;border:solid 0px #000066;
            background-color:rgba(0, 0, 102,0.1);display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center}
        #stream_show_option_inner2_inner_div:hover{background-color:rgba(0, 0, 102,0.3)}
        #stream_show_option_inner2_inner_div:active{background-color:rgba(204, 102, 153,0.3)}
        #stream_show_option_inner2_inner_div img{width:15px;height:15px}
        
        #stream_show_option_inner3{font-size:xx-small;position:relative;top:30px;margin-left:auto;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center}
        

        #easylink_div{position:fixed;left:0;top:0;height:100%;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;background-color:rgba(0, 0, 0,0.1);padding:70PX 0 20px 0;z-index:1}
        .function_link_div{display:block;width:40px;height:40px;margin:5px 10px;border:solid 0px grey;border-radius:5px;background-color:#e6e6e6;cursor:pointer;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;position: relative; 
        }
        .function_link_div:hover{background-color:white;}
        .function_link_div_dropdown{position: absolute;top:100%;left:1px;font-size:10px;opacity:0;width:100px;color:grey;z-index:100;transition: opacity 1s cubic-bezier(0.68, -0.55, 0.27, 1.55);}
        .function_link_div:hover .function_link_div_dropdown{opacity:1}
        .select_div{background-color:#fafafa;position: relative; }
        .select_div:after{
            content: '';  
            position: absolute;  
            right: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-left: 8px solid #fafafa; }
        .select_div:hover:after{border-left: 8px solid white}
  
        /*table的上方信息*/
        #table_top{width:100%;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center}
        #table_top_1{width:200px;flex:none}
        #table_top_2{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-end;align-items:center;width:100%}
        #table_top_2_function{margin-right:25px}
        .table_top_2_function_button{background:rgba(51, 102, 153,0.1);border:solid 1px grey;padding: 1px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;border-radius:2px;cursor:pointer;line-height:1}
        .table_top_2_function_button:hover{background-color:rgba(51, 102, 153,0.9);color:white}
        .table_top_2_function_button:active{background-color:black;color:white}
        #table_top_2_page{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;}
        .table_top_2_page_arrow{cursor:pointer}
        .refresh_time {  color: red; animation: fadeToBlack 1s forwards;}  
        @keyframes fadeToBlack {  from { color: red;}  to {  color: black;}  }
        .refresh_time2 {  color: red; animation: fadeToBlack2 1s forwards;}  
        @keyframes fadeToBlack2 {  from { color:#004c4d;}  to {  color: #009999;}  }
        .link_setting{margin-right:25px;position:relative;}
        .link_setting_a{text-decoration:none}
        .link_setting_dropdown{position:absolute;left:100%;top:0;display:none;}
        .link_setting:hover .link_setting_dropdown{display:block}
        .link_setting_dropdown_div{display: grid;grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));gap: 0px;justify-content: start; align-items: center; border: solid 1px rgba(0,0,0,0.1);color:black}
        .link_setting_dropdown_button{background: #f2f2f2;border: none;padding: 2px 5px; margin: 0;font: inherit;color: inherit;text-decoration: none;cursor: pointer;outline: none; white-space: nowrap;;font-size:xx-small}
        .link_setting_dropdown_button:hover{background: #99ccff;color:#cc0066}
    
        
        /**table信息*/
        .info_table{}
        .info_table{margin:30px 0;border-collapse: collapse;background-color:white;font-size:small;z-index:1;min-width:300px}
        .info_table th{background-color:rgba(51, 102, 153,0.3);user-select: none;font-size:normal;transition:0s}
        .info_table th:not(:first-child):not(:last-child):hover{background-color:rgba(51, 102, 153,0.6);cursor:pointer}
        .info_table th:not(:first-child):not(:last-child):active{background-color:rgba(151, 102, 153,1);}
        .info_table th, .info_table td {padding: 1px 0px;border-bottom: 1px solid #ddd;text-align: left;height:24px;white-space:nowrap;overflow:hidden;transition:1s}
        .info_table tr:nth-child(even) {background-color: rgba(0, 0, 0,0.03);}
        .info_table tr:not(:first-child):hover {background-color:rgba(0, 102, 102,0.2)}
        /*table的最后一列*/
        .table_link_col>div {display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;}
        .link_svg{cursor:pointer;}        
        /*隐藏或展开的列*/
        .hide_td{transition: max-width 0.5s ease;  max-width: 0;width:0;  transition:1s}
        .hide_td_show {   max-width: 100px;width:100px;  }
        
        /*新建数据*/
        #new_folder_tr,#new_file_tr{;display:none}
        #new_folder_tr td,#new_file_tr td{background-color: rgba(0, 153, 153,0.3);}
        #new_folder_tr input,#new_file_tr input{background:transparent;border: none;padding: 2px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;width:100%}
        .colored_row td{background-color:rgba(51, 102, 204,0.5)}
        
        /*table内部的input*/
        .edited_info {width:100%;height:24px;margin:0;box-sizing:border-box;border:none;border-radius:5px;background-color:transparent;padding:0 5px;outline:none;border:solid 1px transparent;transition:0.3s}
        .edited_info:focus{border:solid 1px #3366ff;}
        .edited_info:hover{border:solid 1px #3366ff;} 
        .slight_border{border:solid 1px rgba(0,0,0,0.1);background-color:rgba(255,255,255,0.3)}
        /*层叠的列，三合一*/
        .marked_row td{background-color:rgba(255, 102, 153,0.08);transition:1s;}
        .marked_row:hover td{background-color:rgba(255, 102, 153,0.1);transition:0.1s;}
        .marked_row2 td{height:72px;}
        .stack_div{display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column}
        .stack_div_hide{display:none}
        
        /*右侧的详细table*/
        #main_content_part2{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s;flex:1;position:relative;min-width:300px;width:100%;transition:1s;} 
        #stream_edit_head{color:#336699;font-size:15px;font-weight:bold;margin-bottom:7px;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center}
        #stream_edit_head_txt{cursor:pointer}
        #edit_head_gear{margin:0 10px;cursor:pointer;position:relative;top:5px;width:25px;height:25px}
        #edit_setting{;overflow:hidden;height:0px;border:solid 0px red;transition:0.5s}
        .table_topright{border-collapse: collapse;background-color:white;font-size:small;font-size:xx-small;margin-bottom:5px}
        .table_topright td{padding: 1px 0px;border: 1px solid #ddd;padding:1px 5px;white-space: nowrap;}
        #edit_setting button{margin-right:2px;}
        #stream_edit_content{position:relative}
        #goat_div{width:120px;height:72px;background-color:rgba(51, 102, 153,0.5);border:solid 1px grey;border-radius:15px;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;cursor:pointer;z-index:999;color:white;flex-direction: column;font-weight:bold;padding: 10px;;transition:1s;margin-bottom:10px}
        #goat_div:hover{background-color:rgba(0, 153, 204,0.5);transition:0.1s}
        #goat_div:active{color:darkblue;background-color:rgb(0, 204, 0);transition:0.1s}
        #goat_div div:first-child{font-size:20px;}
        #goat_div div:last-child{font-size:small}
        .stream_edit_inner{font-size:small;width:100%;border:solid 0px blue;}
        .stream_edit_inner_table{width:100%;border:solid 0px blue;margin-bottom:400px}
        .stream_edit_inner_table tr td{vertical-align:top;padding: 0;border-radius:5px;}
        .stream_edit_inner_table tr td:first-child{width:65px;min-width:65px;max-width:65px;text-align:right;padding:0px 6px} /*第一列*/
        .stream_edit_inner_table tr td:last-child{width:100%}/*第二列*/
        .stream_edit_inner_table select{width:100px}
        .stream_edit_inner_table textarea{resize:vertical;min-height:30px}
        .stream_edit_inner_table tr td{vertical-align:top}
        .edited_info2 {height:24px;margin:0;box-sizing:border-box;border-radius:5px;background-color:transparent;padding:0 5px;outline:none;border:solid 1px rgb(0, 95, 204,0.3);resize:vertical}
        .edited_info2:focus{border:solid 1px #3366ff;}
        .edited_info2:hover{border:solid 1px #3366ff;} 
        .container{position:relative;cursor:pointer;}
        .container_dropdown{position:absolute;top:0;right:100%;border:solid 1px #a3c2c2;border-radius:5px;background:#476b6b;color:white;width:300px;padding:5px 10px;display:none;font-size:xx-small;text-align:left}
        .container_dropdown .head_span{color:#ffcccc;font-size:small;font-weight:bold}
        .container_dropdown .middle_span{color:#ccffff;font-size:small;font-weight:bold}
        .container:hover{background:#0099cc;color:white}
        .container:hover .container_dropdown{display:block}       
        
        #file_preview_close{position:absolute;top:5px;right:5px;display:block;height:36px;width:36px;cursor:pointer;padding:3px;border-radius:8px}
        #file_preview_close:hover{background-color:#f0f5f5}

        #stream_content_ul {list-style-type: none;margin-bottom:20px}
        #stream_content_ul textarea{;font-weight:bold}
        .stream_content_li {cursor: pointer;border:solid 0px grey;margin:0 0 10px 0;padding:0;width:100%;}
        .stream_content_li.dragging {opacity: 0.5;}        
        .stream_content_li:hover .stream_content_li_input{background-color:rgba(240, 240, 240,0.9);} 
        .stream_content_li_input{outline:none;border:solid 1px grey;width:100%;max-width:300px;height:30px;;background-color:rgba(240, 240, 240,0.8);border-radius:10px;font-size:15px;;margin-top:2px;padding:5px;}
    

        .li_one_div{position:relative}
        
        .addition_info{position:absolute;right:100%;top:1px;max-width:500px;;background:linear-gradient(to left, rgba(0, 153, 204,0.5), rgba(255, 255, 255,0.5)); width:auto;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column; overflow:hidden;
            border:solid 0px red;}
        .addition_info_topborder {;height: 1px;width:100px;background: linear-gradient(to left, #5c8a8a, white);  }
        .addition_info div{max-width:500px;width:500px;word-wrap: nowrap; text-align:right;text-overflow: ellipsis;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 1;overflow:hidden}
        .addition_info div:not(:first-child){padding:1px 4px}
        .li_topdiv{width:100%;display:flex;display:-webkit-flex;justify-content:stretch;align-items:center;border:solid 0px blue}
        .li_topdiv_head{flex:none;border-top:solid 1px #669999;border-left:solid 1px #669999;border-right:solid 1px #669999;padding:2px 5px;}
        .li_topdiv_head a{text-decoration:none}

        .li_topdiv_middle{flex:1;width:100%;flex-grow:1;margin:auto}
        .li_topdiv_setting{flex:none}        
        .li_serial{color:red}
        .li_name{color:blue;font-weight:bold;margin:0 5px}
        .li_name2{color:#009999;margin:0 5px}
        .li_itemid{color:#0099cc;font-size:xx-small}
        .li_itemid:hover{color:#007399}
        .li_itemid:active{color:#ff0066}
        
        
        .li_maindiv{background-color:#d1e0e0;border:solid 1px #669999;}
        .li_maindiv_table{border-collapse: collapse;}
        .li_maindiv_table td{padding:1px 2px}
        .li_maindiv_table td:first-child{width:60px;min-width:60px;max-width:60px}
        .li_maindiv_table td:nth-of-type(2) input{width:100%;}
        .li_maindiv_table textarea{resize:vertical;width:100%;padding:5px;min-height:30px}
        .template_revise_texarea{background-color:#ebf9eb;color:#006666}
        .parameter_revise_texarea{background-color:#e5eeff;color:#cc0066}
        .paste_part{background-color:rgba(255,255,255,0.1);margin:0 5px}
        .paste_part:hover{background-color:rgba(255,255,255,0.8)}
        .paste_part:active{background-color:rgba(255,255,255,1)}
        .paste_button span{color:#006699}
        /*其他*/
        .green_background{background-color: rgba(0, 204, 0,0.4); /* 立刻变成绿色底纹 */}/*transition: background-color 6s linear;  */
        
        /*#top_message{padding:5px 10px;border:solid 1px grey;border-radius:10px;position:fixed;top:30px;left:50%;transform: translateX(-50%);font-size:small;display:none;opacity: 0; }*/
        .message-box {padding: 5px 10px;border: solid 1px grey;border-radius: 10px;position: fixed;left: 50%;transform: translateX(-50%);font-size: small;display: block;opacity: 1; z-index: 9999;background-color: white;transition: opacity ease-in-out; margin-top: 40px; }
    </style>
</head>
<body>
    <div id='top_navigator'>
        <a id='top_navigator_title_name' href='index.php'>Bioslurm</a>
        <span id="top_navigator_current_time"></span>
        <span id="user_state"><?php echo $navi_user_state;?></span>
    </div>     
    <div  id='easylink_div'>
        <a href='index.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_home.svg">
            </div>
        </a>
        
        <a href='function_file.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_file.svg">
                <div class='function_link_div_dropdown'>文件目录</div>
            </div>
        </a>
        
        <a href='function_script.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_script.svg">
                <div class='function_link_div_dropdown'>命令脚本</div>
            </div>
        </a>

        <a href='function_stream.php' >
            <div class='function_link_div select_div'><img style='width:30px;height:30px' src="000_image/svg_function_stream.svg">
                <div class='function_link_div_dropdown'>线性流程</div>
            </div>
        </a>
        
        <a href='function_structure.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_structure.svg">
                <div class='function_link_div_dropdown'>网络结构</div>
            </div>
        </a>

        <a href='function_project.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_project.svg">
                <div class='function_link_div_dropdown'>项目执行</div>
            </div>
        </a>   
        
        <a href='function_progress.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_progress.svg">
                <div class='function_link_div_dropdown'>作业进度</div>
            </div>
        </a>   
        
        <a href='function_zoom.php' style='margin-top: auto;margin-bottom:50px'>
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_gear.svg">
            </div>
        </a>              
    </div>    
    <div id='all_sum' class="no_select">
        <div id='main_content'>
            <div id='main_content_part1'>
                <div id='stream_show_head' onclick="option_button_click('get_self')">
                    线性流程<span style='font-size:small'> (组合型处理单元，输入→→→输出)</span>
                </div>
                <div id='stream_show_option'>
                    <div id='stream_show_option_inner1'>
                        <button id="option_button_1" class='stream_show_option_inner1_button' onclick="option_button_click('get_self')">个人仓储</button>
                        <button id="option_button_2" class='stream_show_option_inner1_button' onclick="option_button_click('get_selfshare')">向外分享</button>
                        <button id="option_button_3" class='stream_show_option_inner1_button' onclick="option_button_click('get_public')">外部区域</button>                        
                    </div>
                    <div id='stream_show_option_inner2'>
                        <div id='stream_show_option_inner2_inner'>
                            <div>
                                <input type='text' id='search_input'></input>
                            </div>    
                            <div>  
                                <div id="stream_show_option_inner2_inner_div" onclick='search_input_click()'>
                                    <img style='' src="000_image/svg_magnify.svg">
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <div id='stream_show_content'>
                </div>
                
            </div>
            <div id='main_content_part2'>
                <div id='stream_edit_content'>
                </div>
            </div>
        </div>      

    </div> 
    <div id='top_message'></div>
    
    <div id='state_circle_bottom' style='display:none;position:fixed;bottom:10px;left:30px;width:100px'>
        <div style='display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center'>
            <span style='width:20px;height:20px;border-radius:10px;background-color:#00ff00;display:block'></span>
            <span id = 'state_circle_bottom_text' style='font-weight:bold;margin-left:4px'></span>
        </div>
    </div>    
    
    <input type='hidden' id="expand_shrink_state_hidden" value='0'>

    <input type='hidden' id="current_action_hidden" value='get_self'>
    <input type='hidden' id="current_page_hidden" value='1'>
    <input type='hidden' id="current_page_sum_hidden" value='0'>
    <input type='hidden' id="current_searchword_hidden" value='<?php echo $searchword; ?>'>
    <input type='hidden' id="current_sortcol_hidden" value=''>
    <input type='hidden' id="current_sortcol_direction_hidden" value='desc'>
    <input type='hidden' id="current_itemid_hidden" value=''>

    <input type='hidden' id="first_element_state_hidden" value=''>
</body>      
</html>

<?php
   
    
    
    
    
    
?>
    
<script>
    const urlget_searchword='<?php echo $searchword; ?>';
    
    function getCurrentTime() {
        const now = new Date();
    
        // 获取小时、分钟和秒
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();
    
        // 格式化时间（例如：09:05:03）
        const formattedTime = [
            String(hours).padStart(2, '0'),
            String(minutes).padStart(2, '0'),
            String(seconds).padStart(2, '0')
        ].join(':');
    
        return formattedTime;
    }
    
    function generateRandomString(length) {  
        const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';  
        let result = '';  
        for (let i = 0; i < length; i++) {  
            const randomIndex = Math.floor(Math.random() * characters.length);  
            result += characters[randomIndex];  
        }  
        return result;  
    }  

    const userid='<?php echo $user_name_id;?>';

    // 渐显并渐隐函数
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        // 创建新的消息元素
        var div = document.createElement("div");
        div.className = "message-box"; // 应用样式类
    
        let message_text_new = '';
        
        // 根据消息类型设置背景颜色和内容
        if (message_type == "error") {
            div.style.backgroundColor = "rgb(255, 255, 153)";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> " + message_text;
        } else if (message_type == "success") {
            div.style.backgroundColor = "#e5ffe5";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> " + message_text;
        } else {
            div.style.backgroundColor = "gray";
            message_text_new = message_text;
        }
    
        div.innerHTML = message_text_new;
        div.style.transition = `opacity ${fadeDuration}s ease-in-out`; // 动态设置渐隐时长
    
        // 将新的消息元素添加到 body
        document.body.appendChild(div);
    
        // 动态调整所有消息的 vertical 位置，防止重叠
        adjustMessagesPosition();
    
        // 延时后开始渐隐
        setTimeout(function() {
            div.style.opacity = 0; // 开始渐隐
            
            // 渐隐完成后移除元素
            setTimeout(function() {
                document.body.removeChild(div);
                adjustMessagesPosition(); // 调整剩余消息的位置
            }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
        }, delayBeforeFade);
    }
    // 动态调整所有消息的位置，防止重叠
    function adjustMessagesPosition() {
        const messages = document.querySelectorAll('.message-box'); // 选择所有消息元素
        let currentTop = 0; // 从顶部开始，预留一些空间
    
        messages.forEach(message => {
            message.style.top = `${currentTop}px`;
            currentTop += message.offsetHeight + 2; // 累加消息高度和间距
        });
    }
    
    window.onload = function() {
        refresh_stream_click("get_self",'',urlget_searchword,'','');
        // 定义一个函数来检查元素的值，并在值为1时执行特定操作  
        function checkElementValue() {  
            var element = document.getElementById('first_element_state_hidden');  
            if (element && element.value === "1") {  
                clearInterval(intervalId); // 移除轮询  
                if(urlget_searchword){refresh_stream_click2(urlget_searchword); }// 执行函数  
            } 
        }  
        var intervalId = setInterval(checkElementValue, 10); //  // 设置一个定时器来每隔一段时间检查一次元素的值  每秒检查一次
    }
    
    function refresh_stream_click(action,page,searchword,sortcol,sortdirection,colored_itemid){
        console.log("refresh_stream_click_____action:",action," page:",page," searchword:",searchword," sortcol:",sortcol," sortdirection:",sortdirection);
        
        // 获取option_button_1和option_button_2元素  
        var optionButton1 = document.getElementById("option_button_1");  
        var optionButton2 = document.getElementById("option_button_2");  
        var optionButton3 = document.getElementById("option_button_3");   
        // 根据action的值来添加或移除button_polygon类  
        if (action == "get_self") {  
            optionButton1.classList.add("button_polygon");  
            optionButton2.classList.remove("button_polygon");
            optionButton3.classList.remove("button_polygon");
            document.getElementById("current_action_hidden").value='get_self'; 
        } else if (action == "get_selfshare") {  
            optionButton1.classList.remove("button_polygon");  
            optionButton2.classList.add("button_polygon"); 
            optionButton3.classList.remove("button_polygon"); 
            document.getElementById("current_action_hidden").value='get_selfshare'; 
        } else if (action == "get_public") {  
            optionButton1.classList.remove("button_polygon");  
            optionButton2.classList.remove("button_polygon");
            optionButton3.classList.add("button_polygon");
            document.getElementById("current_action_hidden").value='get_public'; 
        }else {  
            // 如果action不是"get_self"或"get_public"，则移除两个按钮的button_polygon类  
            optionButton1.classList.remove("button_polygon");  
            optionButton2.classList.remove("button_polygon");  
            optionButton3.classList.remove("button_polygon");  
        }

        
        //action可能是'get_self','get_all','page'
        fetch('function_stream_get_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'dataregin':"content_simple",
                'action':action,
                'page':page,
                'searchword':searchword,
                'sortcol':sortcol,
                'sortdirection':sortdirection,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            let result_num=data.result_num;
            let page_num=data.page_num;
            document.getElementById("current_page_sum_hidden").value=page_num; 
            let current_page=document.getElementById("current_page_hidden").value; 
            //console.log(data);
            console.log("data.result:",data.result);
            console.log("data.result_num:",result_num);
            //
            // 假设你有一个select元素  
            let selectHTML = ``;  let current_page_str='';
            for (let i = 1; i <= page_num; i++) {  
                if(current_page==i){current_page_str='selected';}else{current_page_str='';}
                selectHTML += `<option value='${i}' ${current_page_str}>${i}</option>`;  
            }  
            //
            let marked_col_id='';
            if (sortcol!=''){
                if(sortcol=='创建时间'){marked_col_id='th1';}
                else if(sortcol=='唯一识别码'){marked_col_id='th2';}
                else if(sortcol=='分类1'){marked_col_id='th3';}
                else if(sortcol=='分类2'){marked_col_id='th4';}
                else if(sortcol=='分类3'){marked_col_id='th5';}
                else if(sortcol=='名称'){marked_col_id='th6';}
                else if(sortcol=='描述1'){marked_col_id='th7';}
                else if(sortcol=='描述2'){marked_col_id='th8';}
                else if(sortcol=='描述3'){marked_col_id='th9';}
                else if(sortcol=='更新时间'){marked_col_id='th10';}
            }    
            //
            let current_action=document.getElementById("current_action_hidden").value;
            let state1='';let state2='';
            if (current_action=='get_self'){}
            else if (current_action=='get_selfshare'){state1='hidden';}
            else if (current_action=='get_public'){state1='hidden';state2='hidden';}
            //            
            let current_time=getCurrentTime();
            let table1=`         
                            <table class="info_table">
    
                                <tr class='file_table_desc'>
                                    <td colspan='12' style='vertical-align:bottom'>
                                        <div id='table_top'>
                                            <div id='table_top_1'>
                                                <div><span  style='cursor:pointer' class='refresh_time' onclick="refresh_stream_click('${action}','${page}','${searchword}','${sortcol}','${sortdirection}')">刷新时间: ${current_time}</span></div> 
                                            </div>  
                                            
                                            <div id='table_top_2'>
                                                <div id='table_top_2_function'>
                                                    <button class='table_top_2_function_button' onclick='create_stream_click()'  ${state1}>新建</button>
                                                    <button class='table_top_2_function_button' onclick='extract_itemid_click()' ${state1}>提取</button>  
                                                    <button class='table_top_2_function_button' onclick='expand_shrink_click()' id='expand_shrink_button'>展开</button>                                                    
                                                </div>                                                 
                                                <div class='link_setting' ${state2}>
                                                    <button class='table_top_2_function_button'> > </button>
                                                    <div class='link_setting_dropdown'>
                                                         <div class='link_setting_dropdown_div'>
                                                            <button class='link_setting_dropdown_button' onclick="item_operate_multi('批量删除')">批量删除</button>
                                                        </div>   
                                                    </div>    
                                                </div> 
                                                <div  id='table_top_2_page' >
                                                    <div>页码:</div>
                                                    <div class='table_top_2_page_arrow' onclick="page_click_addminus('减一')">
                                                        <img style='width:10px;height:10px' src="000_image/svg_arrow_left.svg">
                                                    </div>
                                                    <div>
                                                        <select class='studynote_page_option' id='' name='' onchange="page_click(this.value)" ondblclick='enterEditMode(this)'>
                                                            ${selectHTML}
                                                        </select>
                                                    </div>
                                                    <div class='table_top_2_page_arrow' onclick="page_click_addminus('加一')">
                                                        <img style='width:10px;height:10px' src="000_image/svg_arrow_right.svg">
                                                    </div>
                                                </div>    
                                            </div>
                                        </div>
                                    </td>
                                </tr>                                
                                <tr>
                                    <th style='width:20px'><input  type='checkbox' id='all_checkbox' name='all_checkbox' value='all_checkbox' onclick='all_checkbox_click()' style='position:relative;top:2px' ${state2}>
                                        <input type='hidden' id='all_checkbox_state' name='all_checkbox_state' value='0'  />
                                        <input type='hidden' id='all_checkbox_value' name='all_checkbox_value' value=''  />
                                        <span id='checkbox_selected_num' style='font-size:10px;color:darkblue'></span>
                                    </th>
                                    <th class='hide_td'   id='th1'  onclick="th_click('th1','创建时间')" >创建时间</th>
                                    <th class='hide_td'   id='th2'  onclick="th_click('th2','唯一识别码')" >ID</th>
                                    <th                   id='th3'  onclick="th_click('th3','分类1')" >分类</th>
                                    <th class='hide_td'   id='th4'  onclick="th_click('th4','分类2')" >分类2</th>
                                    <th class='hide_td'   id='th5'  onclick="th_click('th5','分类3')" >分类3</th>
                                    <th                   id='th6'  onclick="th_click('th6','名称')" >名称</th>
                                    <th                   id='th7'  onclick="th_click('th7','描述1')" >描述</th>
                                    <th class='hide_td'   id='th8'  onclick="th_click('th8','描述2')" >描述2</th>
                                    <th class='hide_td'   id='th9'  onclick="th_click('th9','描述3')" >描述3</th>
                                    <th class='hide_td'   id='th10' onclick="th_click('th10','更新时间')" >更新时间</th>
                                    <th style='text-align:center'></th>
                                </tr>
                                <tr id='new_folder_tr' >
                                    <td colspan='6' style='text-align:right;padding-right:5px'><img style='position:relative;top:3px;height:20px;width:20px' src='/000_image/svg_function_stream.svg'></td>
                                    <td colspan='5'><input type='text' id='new_folder_tr_input' value='新建流程'></td>
                                </tr>
                                `;
            let table2=``;
            let ii=0;let serial_base=(current_page-1)*100;
            raw_result.forEach((item) => {
                ii+=1;//serial=serial_base+ii;
                
                //console.log(item);
                let item_create_time     = item["创建时间"]; 
                let item_id_nouniq       = item["识别码"]; 
                let item_id              = item["唯一识别码"];  
                let item_class1          = item["分类1"]|| "";
                let item_class2          = item["分类2"]|| "";
                let item_class3          = item["分类3"]|| "";
                let item_name            = item["名称"]|| "";  
                let item_desc1           = item["描述1"]|| ""; 
                let item_desc2           = item["描述2"]|| ""; 
                let item_desc3           = item["描述3"]|| ""; 
                let item_update_time     = item["更新时间"]|| ""; 
                let item_owner          = item["拥有者"]|| ""; 
                let item_authority       = item["共享权限"]|| ""; 
                //
                let item_belong_style='';
                if(item_id_nouniq!=item_id){item_belong_style="background-color:#cceeff";} 
                //
                let input_style='';
                if(item_authority=='公开' && item_owner!=userid){input_style='readonly';console.log("非本人信息，编辑禁用");}
                //
                let colored_itemid_str='';
                if(colored_itemid==item_id){colored_itemid_str='colored_row';}
                //
                table2+=`       <tr id='${item_id}' class='${colored_itemid_str}'>
                                    <td style='width:10px'>
                                        <input  type='checkbox' class='select_checkbox' style='position:relative;top:3px' name='selected_files' onclick='one_checkbox_click(this)' value='${item_id}' ${state2}>
                                    </td>                                    
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_create_time}' disabled></td>
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_id}' disabled></td>
                                    <td>
                                        <div class='stack_div'>
                                            <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','分类1')"    value='${item_class1}' onclick="main_input_click('${item_id}')" ${input_style}>
                                            <input  class='edited_info stack_div_hide' style='max-width:100px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','分类2')"  value='${item_class2}' onclick="main_input_click('${item_id}')" ${input_style}>
                                            <input  class='edited_info stack_div_hide' style='max-width:100px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','分类3')"  value='${item_class3}' onclick="main_input_click('${item_id}')" ${input_style}>
                                        </div>  
                                    </td>    
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:110px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','分类2')"  value='${item_class2}' ${input_style}></td>
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','分类3')"  value='${item_class3}' ${input_style}></td>                                    
                                    <td>
                                        <input  class='edited_info name_input' style='${item_belong_style};max-width:300px;font-weight:bold' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','名称')"  value='${item_name}' onclick="main_input_click('${item_id}')" ${input_style}></input></td> 
                                    <td>
                                        <div class='stack_div'>
                                            <input  class='edited_info' style='max-width:300px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','描述1')"  value='${item_desc1}' onclick="main_input_click('${item_id}')" ${input_style}>
                                            <input  class='edited_info stack_div_hide' style='max-width:300px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','描述2')"  value='${item_desc2}' onclick="main_input_click('${item_id}')" ${input_style}>
                                            <input  class='edited_info stack_div_hide' style='max-width:300px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','描述3')"  value='${item_desc3}' onclick="main_input_click('${item_id}')" ${input_style}>
                                        </div>
                                    </td> 
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:300px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','描述2')"  value='${item_desc2}' ${input_style}></td> 
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:300px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','描述3')"  value='${item_desc3}' ${input_style}></td>
                                    <td class='hide_td'>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','更新时间')"  value='${item_update_time}'disabled></td>
                                    <td class='table_link_col'  style='cursor:pointer;padding:0 2px' onclick="refresh_stream_click2('${item_id}','双击隐藏')"><div class='link_svg_div' ><svg  t="1724591230364" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="29720" width="20" height="20"><path d="M133.8 115h756.4c20.9 0 37.8 16.9 37.8 37.8v37.8c0 20.9-16.9 37.8-37.8 37.8H133.8c-20.9 0-37.8-16.9-37.8-37.8v-37.8c0-20.9 16.9-37.8 37.8-37.8zM133.8 455.3h491.6c20.9 0 37.8 16.9 37.8 37.8v37.8c0 20.9-16.9 37.8-37.8 37.8H133.8c-20.9 0-37.8-16.9-37.8-37.8v-37.8c0-20.9 16.9-37.8 37.8-37.8zM133.8 795.6h756.4c20.9 0 37.8 16.9 37.8 37.8v37.8c0 20.9-16.9 37.8-37.8 37.8H133.8c-20.9 0-37.8-16.9-37.8-37.8v-37.8c0-20.9 16.9-37.8 37.8-37.8zM757.8 600.7V423.3c0-22 29.2-33.1 46.2-17.5l97.1 88.7c10.6 9.7 10.6 25.3 0 35L804 618.1c-17 15.6-46.2 4.6-46.2-17.4z" fill="#1296db" p-id="29721" id='path_${item_id}'></path></svg></td></td>
                                </tr>`;
            });
            let table3=`        <tr>
                                    <td colspan='12' style='font-size:15px;color:grey;font-size:xx-small'>
                                        共<span id='result_num'></span>个线性流程（含隐藏）。
                                    </td>
                                </tr>

                            <table>`;
            let table_sum=table1+table2+table3;
            let contentHtml = `${table_sum}`;    
            //改内容
            document.getElementById('stream_show_content').innerHTML = contentHtml;   ;
            document.getElementById('first_element_state_hidden').value=1;
            //
            //获得收缩和扩展的状态
            let expand_shrink_state=document.getElementById('expand_shrink_state_hidden').value;
            if(expand_shrink_state==1){
                document.querySelectorAll('.hide_td').forEach(function(element) {element.classList.add('hide_td_show')});
                document.getElementById('expand_shrink_button').innerText='折叠';
            }
            
            //获得应该高亮的行
            let old_itemid=document.getElementById('current_itemid_hidden').value;
            if(old_itemid){
                $('#'+old_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'none');  });
                $('#'+old_itemid+' .name_input').each(function() {  $(this).css('height', '24px');  });
                $('#'+old_itemid+' input').each(function() {  $(this).removeClass('slight_border'); });
            }
        
            //高亮被排序的列
            if(marked_col_id!=''){document.getElementById(marked_col_id).style.backgroundColor = 'rgba(51, 102, 153,0.6)';}
            
            //显示结果数量和page
            document.getElementById('result_num').innerText=result_num;
            
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }

    function option_button_click(action,colored_itemid){
        
        document.getElementById('expand_shrink_state_hidden').value='0';
        document.getElementById('current_page_hidden').value='1';
        document.getElementById('current_page_sum_hidden').value='0';
        document.getElementById("current_searchword_hidden").value='';
        document.getElementById("current_sortcol_hidden").value='';
        document.getElementById("current_sortcol_direction_hidden").value='';        
        document.getElementById("current_itemid_hidden").value=''; 
        document.getElementById("search_input").value='';
        document.getElementById("stream_edit_content").innerHTML='';
        
        refresh_stream_click(action,'','','','',colored_itemid);
        
    }
    
    function expand_shrink_click(){
        console.log('点击来了expand_shrink_click');
        let expand_shrink_state_old=document.getElementById('expand_shrink_state_hidden').value;
        if (expand_shrink_state_old==0){
            console.log("即将展开");
            document.querySelectorAll('.hide_td').forEach(function(element) {element.classList.add('hide_td_show');});
            document.getElementById('expand_shrink_button').innerText='折叠';
            document.getElementById('expand_shrink_state_hidden').value='1';
            //document.getElementById("main_content_part2").style.display='none';
            //
            let itemid_hidden=document.getElementById('current_itemid_hidden');
            let old_itemid=itemid_hidden.value;             
            if(old_itemid){
                document.getElementById(old_itemid).classList.remove('marked_row2');
                $('#'+old_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'none');  });
                $('#'+old_itemid+' .name_input').each(function() {  $(this).css('height', '24px');  });
                $('#'+old_itemid+' input').each(function() {  $(this).removeClass('slight_border'); });
            }
        }
        else{
            console.log("即将关闭");
            document.querySelectorAll('.hide_td').forEach(function(element) {element.classList.remove('hide_td_show');});
            document.getElementById('expand_shrink_button').innerText='展开';
            document.getElementById('expand_shrink_state_hidden').value='0';
            //document.getElementById("main_content_part2").style.display='block';
            //
            let itemid_hidden=document.getElementById('current_itemid_hidden');
            let old_itemid=itemid_hidden.value;             
            if(old_itemid){
                document.getElementById(old_itemid).classList.add('marked_row', 'marked_row2');
                $('#'+old_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'block');  });
                $('#'+old_itemid+' .name_input').each(function() {  $(this).css('height', '72px');  });
                $('#'+old_itemid+' input').not('.hide_td input').each(function() {  $(this).addClass('slight_border'); });
            }
        }
    }
    document.addEventListener('keydown', function(event) {  if (event.key === '`') {  expand_shrink_click();  }   }); // 检测反引号`键  
    
    function main_input_click(item_id){
        if(document.getElementById('expand_shrink_state_hidden').value==0){
            if(document.getElementById('current_itemid_hidden').value!=item_id){
                refresh_stream_click2(item_id);}
        }
    }
    
    function th_click(th_id,col_name){
        //先确定是排哪列，是升序还是降序
        //console.log('点击了列名，即将排序');
        let current_sortcol = document.getElementById("current_sortcol_hidden");                     
        let current_sortcol_direction= document.getElementById("current_sortcol_direction_hidden");  
        let current_sortcol_old=current_sortcol.value;                            let current_sortcol_new=col_name;
        let current_sortcol_direction_old=current_sortcol_direction.value;        let current_sortcol_direction_new='';
        if (current_sortcol_new==current_sortcol_old){
            if(current_sortcol_direction_old=='asc'){current_sortcol_direction_new='desc';          }
            else{                                     current_sortcol_direction_new='asc';          }
        }
        else{
            current_sortcol_direction_new='desc';
        }
        current_sortcol.value              =current_sortcol_new; 
        current_sortcol_direction.value    =current_sortcol_direction_new;
        console.log("需要排序的col和方向：",current_sortcol_new,current_sortcol_direction_new)
        ///生成刷新表格的命令
        let current_action = document.getElementById("current_action_hidden").value;                //get_self或get_selfshare或get_public
        let current_page = document.getElementById("current_page_hidden").value;                    //页码
        let current_searchword = document.getElementById("current_searchword_hidden").value;        //搜索内容
        refresh_stream_click(current_action,current_page,current_searchword,current_sortcol_new,current_sortcol_direction_new);
    }
    
    function search_input_click(){
        let current_searchword = document.getElementById("search_input").value;
        document.getElementById("current_searchword_hidden").value=current_searchword;
        console.log("current_searchword:",current_searchword);
        //
        ///生成刷新表格的命令
        let current_action = document.getElementById("current_action_hidden").value;                //get_self或get_selfshare或get_public
        document.getElementById("current_itemid_hidden").value='';
        refresh_stream_click(current_action,'',current_searchword,'','');
    }

    function page_click(page){
        document.getElementById("current_page_hidden").value=page;
        let current_action              = document.getElementById("current_action_hidden").value;
        let current_searchword          = document.getElementById("current_searchword_hidden").value;
        let current_sortcol             = document.getElementById("current_sortcol_hidden").value;
        let current_sortcol_direction   = document.getElementById("current_sortcol_direction_hidden").value;
        console.log("page_click启动:",current_action,page,current_searchword,current_sortcol,current_sortcol_direction);
        refresh_stream_click(current_action,page,current_searchword,current_sortcol,current_sortcol_direction);
    }    
    function page_click_addminus(addminus){
        let current_page=parseInt(document.getElementById('current_page_hidden').value);
        let page_max=parseInt(document.getElementById('current_page_sum_hidden').value);
        let new_page='';
        if (addminus=="减一"){
            let current_page_minus=current_page-1;
            if(current_page_minus==0){new_page=1;}else{new_page=current_page_minus;}
        }
        if (addminus=="加一"){
            let current_page_add=current_page+1;
            if(current_page_add>page_max){new_page=page_max;}else{new_page=current_page_add;}
        }
        console.log("新页码:",new_page);
        page_click(new_page);
        file_preview_close_click();
    } 
    
    //复选框
    const checkboxValuesSet = new Set();  //外部声明一个set，虽然是const定义的的，由于是set仍然可以编辑
    function one_checkbox_click(this_checkbox) {
        // 检查当前复选框的状态
        if (this_checkbox.checked) {
            checkboxValuesSet.add(this_checkbox.value);  // 将值添加到 Set 中
        }
        else{
            // 如果当前复选框不是选中的状态，则将 all_checkbox_state 设为 0
            document.querySelector('#all_checkbox_state').value=0;
            document.querySelector('#all_checkbox').checked = false;
            checkboxValuesSet.delete(this_checkbox.value);  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}
    }    
    function all_checkbox_click(){
        let all_checkbox_state_old = document.getElementById("all_checkbox_state").value;
        let all_checkbox_state_new='';
        if (all_checkbox_state_old==0){     all_checkbox_state_new=1;}
        else{                               all_checkbox_state_new=0;}
        document.getElementById("all_checkbox_state").value=all_checkbox_state_new;
        console.log("所有复选框state:",all_checkbox_state_old,"变为",all_checkbox_state_new);
        let select_checkboxes = document.querySelectorAll('.select_checkbox');
        if (all_checkbox_state_new==1){
            select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = true;
                checkboxValuesSet.add(checkbox.value);  // 将值添加到 Set 中
            });
        }
        else{
             select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = false;
            });
            checkboxValuesSet.clear();  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}
    }
    //提取复选框到用户信息表
    function extract_itemid_click(){
        console.log('extract_itemid_click开始');
        // 将 Set 转换为数组  
        const checkboxValuesString = Array.from(checkboxValuesSet).join(';'); 
        console.log('checkboxValuesString:',checkboxValuesString);
        if(checkboxValuesString== "") {showAndFadeOut('error', 2000, 3,'至少一个复选框被选中！');return false;}
        /////////
        fetch('function_save2load.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':'存储剪切itemid',
                'itemids_str':checkboxValuesString,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                showAndFadeOut('success', 2000, 3,"已提取item_id，请前往网络结构进行粘贴");
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }   
    function extract2paste_itemid_click(){
        console.log('extract2paste_itemid_click开始');
        // 将 Set 转换为数组  
        fetch('function_save2load.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':'提取剪切itemid',
                'target':'粘贴至stream',
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log("raw_result:",raw_result);
            if(!raw_result){return false;}
            let item_array=raw_result[0]["存储变量1"].split(";");

            let modified_item_array = item_array.map(item => 'node_'+generateRandomString(10)+"_|||__|||_" + item + "_|||__|||__|||_"); 
            let item_array_str=modified_item_array.join("_;;;_\n");
            //
            /*
            let stream_content=document.getElementById('stream_content');
            stream_content_new=stream_content.value+"\n"+item_array_str
            stream_content_new = stream_content_new.split("\n").filter(line => line.trim() !== "").join("\n");  // 移除 stream_content_new 中的空白行 
            stream_content.value=stream_content_new;
            // 创建一个新的Event对象，表示change事件 触发元素的change事件   
            var event = new Event('change');  stream_content.dispatchEvent(event);*/
            let container = document.getElementById('stream_content_ul');  
            let exitst_Index = container.children.length; // 获取当前容器中li的数量，这将作为新li的起始index  
            modified_item_array.forEach((line, index) => {  
                let serial=exitst_Index + index + 1;
                let parts = line.split('_|||_');  
                let node_name           =parts[0]; //   li_itemid_random="li_"+generateRandomString(10);
                let li_itemid           =parts[2];
                let href_php='';
                if (li_itemid.startsWith('script_')) {href_php="function_script";  }
                //else if (li_itemid.startsWith('stream_')) {href_php="function_stream";  }
                else{showAndFadeOut('error', 2000, 3,"线性流程只能由命令脚本构成");return false;}
                //
                let li = document.createElement('li');  
                li.draggable = true;  
                li.className = 'stream_content_li';  
                li.id           = node_name;
                li.dataset.id = exitst_Index+index; // 使用 data-id 属性来存储索引  
                // 上中下分别是输入-参数-输出，右侧为更改，顶部作为选项卡1，顶部右侧为删除
                li.innerHTML = `  
                    <div class='li_one_div'>
                        <div>
                            <textarea class="stream_content_li_input"  onchange='update_stream_content_change()' hidden>${li_itemid}</textarea>
                            <div class='li_topdiv'>
                                <div class='li_topdiv_head'>
                                    <span class='li_serial' hidden>${serial}</span>
                                    <span class='li_name' id="${node_name}_name"></span>
                                    <input type='hidden' class='collection_marked' value='${node_name}'>
                                    <input type='hidden' class='collection_marked' value=''>
                                    <span class='li_itemid collection_marked' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')">${li_itemid}</span>
                                </div>
                                <div class='li_topdiv_middle'></div>
                                <div class='li_topdiv_setting'>
                                    <button onclick="delete_li('${node_name}')"><img style='width:16px;height:16px' src="000_image/svg_button_garbage.svg"></button>
                                </div>
                            </div>
                            
                            <div class='li_maindiv'>
                                <div>
                                    <table class='li_maindiv_table'>
                                        <tr>
                                            <td>模板预设</td>
                                            <td><span class='li_name2' id="${node_name}_name2"></span><span id="${node_name}_template"></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td><textarea id="${node_name}_template_new" class='collection_marked template_revise_texarea'  placeholder='空白即默认' onchange='update_stream_content_change()'>${parts[3]}</textarea> </td>
                                        </tr>
                                        <tr>
                                            <td>参数预设</td>
                                            <td><span id="${node_name}_parameter"></span></td>
                                        </tr>                                        
                                        <tr>
                                            <td></td>
                                            <td><textarea id="${node_name}_parameter_new" class='collection_marked parameter_revise_texarea' placeholder='空白即默认' onchange='update_stream_content_change()'>${parts[4]}</textarea> </td>
                                        </tr>
                                        <tr class='grey_text'>
                                            <td>结果参考</td>
                                            <td><span id="${node_name}_result"></span>
                                                <input type='hidden' class='collection_marked' value=''>
                                            </td>
                                        </tr>                                          
                                    </table>
                                </div>    
                            </div>
                        </div>
                        <div class='addition_info'>
                                <div class='addition_info_topborder'></div>
                                <div id='${node_name}_addition1'></div>
                                <div id='${node_name}_addition2'></div>
                                <div id='${node_name}_addition3'></div>
                                <div id='${node_name}_addition4'></div>
                                <div id='${node_name}_addition5'></div>
                                <div id='${node_name}_addition6'></div>
                            </table>
                        </div>
                    </div>    
                `;  
                container.appendChild(li);  
                //填充内容
                fetch_item_info(li_itemid).then(item => { 
                    //console.log('获取到的item信息:', item);  
                    if(item["名称"]){  document.getElementById(node_name+"_name").innerText=  item["名称"].replace(/.*\//, '');}
                    if("命令名称" in item){   document.getElementById(node_name+"_name2").innerText=  item["命令名称"];}
                    if(item["模板预设"]){
                        document.getElementById(node_name+"_template").innerHTML= `<span class='paste_part' onclick='copy_str(this.innerText)'>`+ item["模板预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part' onclick='copy_str(this.innerText)'>`);
                    }
                    if(item["参数预设"]){document.getElementById(node_name+"_parameter").innerHTML=  `<span class='paste_part' onclick='copy_str(this.innerText)'>`+ item["参数预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part' onclick='copy_str(this.innerText)'>`);
                    }
                    if(item["结果预设"]){
                        document.getElementById(node_name+"_result").innerHTML= `<span class='paste_part' onclick='copy_str(this.innerText)'>`+ item["结果预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part ' onclick='copy_str(this.innerText)'>`);
                    }                    
                    if(item["分类1"]){document.getElementById(node_name+"_addition1").innerHTML="<span style='color:#2d5986'>分类1:</span>"+item["分类1"];}
                    if(item["分类2"]){document.getElementById(node_name+"_addition2").innerHTML="<span style='color:#2d5986'>分类2:</span>"+item["分类2"];}
                    if(item["分类3"]){document.getElementById(node_name+"_addition3").innerHTML="<span style='color:#2d5986'>分类3:</span>"+item["分类3"];}
                    if(item["描述1"]){document.getElementById(node_name+"_addition4").innerHTML="<span style='color:#2d5986'>描述1:</span>"+item["描述1"];}
                    if(item["描述2"]){document.getElementById(node_name+"_addition5").innerHTML="<span style='color:#2d5986'>描述2:</span>"+item["描述2"];}
                    if(item["描述3"]){document.getElementById(node_name+"_addition6").innerHTML="<span style='color:#2d5986'>描述3:</span>"+item["描述3"];}
                })
            });  
            
      
            //更新下数据库
            update_stream_content_change();
            //
            if(data.status=='success'){
                showAndFadeOut('success', 2000, 3,"已粘贴");
            }
            
            // 重新初始化拖拽事件监听器  
            initDraggableList(container);  
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    // 初始化拖拽功能的函数  
    function initDraggableList(list) {  
        let draggedItem = null;  
        list.addEventListener('dragstart', (e) => {  draggedItem = e.target;  e.target.classList.add('dragging');  });  
        list.addEventListener('dragend', (e) => {  e.target.classList.remove('dragging');  draggedItem = null;  });  
        list.addEventListener('dragover', (e) => {  
            e.preventDefault();  
            const afterElement = getDragAfterElement(list, e.clientY);  
            const currentElement = document.querySelector('.dragging');  
            if (afterElement == null) {  list.appendChild(currentElement);  } 
            else {  list.insertBefore(currentElement, afterElement);  }  
            //
            update_stream_content_change();
        });  
    }  
        
    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('li:not(.dragging)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {return { offset, element: child };} 
            else { return closest;}
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }
    function refresh_stream_click2(item_id,hidden_mark){
        let itemid_hidden=document.getElementById('current_itemid_hidden');
        let old_itemid=itemid_hidden.value; 
        if(hidden_mark && item_id==old_itemid){file_preview_close_click();return false;}
        
        console.log("refresh_stream_click2_____item_id:",item_id);
        document.getElementById("main_content_part2").style.display='block';
        document.querySelectorAll('.hide_td').forEach(function(element) {element.classList.remove('hide_td_show')});
        document.getElementById('expand_shrink_button').innerText='展开';
        document.getElementById('expand_shrink_state_hidden').value='0';
        //
        if(old_itemid){
            document.getElementById(old_itemid).classList.remove('marked_row', 'marked_row2');
            $('#'+old_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'none');  });
            $('#'+old_itemid+' .name_input').each(function() {  $(this).css('height', '24px');  });
            $('#'+old_itemid+' input').each(function() {  $(this).removeClass('slight_border'); });
            $('#path_'+old_itemid).css('fill', '#1296db');
        }
        let new_itemid=item_id;     
            document.getElementById(new_itemid).classList.add('marked_row', 'marked_row2');
            $('#'+new_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'block');  });
            $('#'+new_itemid+' .name_input').each(function() {  $(this).css('height', '72px');  });
            $('#'+new_itemid+' input').not('.hide_td input').each(function() {  $(this).addClass('slight_border'); });
            $('#path_'+new_itemid).css('fill', 'red');
        console.log("old_itemid：",old_itemid,"new_itemid：",new_itemid);
        itemid_hidden.value=new_itemid;
        
        ////
        fetch('function_stream_get_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'dataregin':"content_edit",
                'item_id':item_id,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            let item=raw_result[0];
            //console.log(data);
            //console.log("data.result:",data.result);
            //console.log('raw_result_0',raw_result[0]);
            let item_belong               = item["识别码"]|| ""; 
            let item_name               = item["名称"]|| ""; 
            let item_creator              = item["创建者"]|| "";
            let item_creator_time              = item["创建时间"]|| "";            
            let item_owner              = item["拥有者"]|| "";
            let item_authority          = item["共享权限"]|| "";
            let item_update_time              = item["更新时间"]|| "";
            let item_threads            = item["线程分配"]|| "";         
            let item_stream_template      = item["模板预设"]|| ""; 
            let item_stream_parameter     = item["参数预设"]|| "";
            let item_stream_result         = item["结果预设"]|| "";                       
            let item_stream_variable     = item["变量预设"]|| "";
            let item_stream_note       = item["备注信息"]|| ""; 
            let item_stream_content     = item["流程内容"]|| "";
            
            let item_threads_options_str='';
            let item_threads_array = Array.from({length: 40}, (_, i) => i + 1);        // 生成一个包含1到40的数字的列表  
            item_threads_array.forEach(one => { 
                if (item_threads==one){item_threads_options_str+=`<option value='${one}' selected>${one}</option>  `;}
                else{item_threads_options_str+=`<option value='${one}'>${one}</option>  `;}
            });
            //
            let current_time=getCurrentTime();
            ///是否是公开并且拥有者不是自己
            let goat_div='';let gear_button_style='';let share_button_style='';let input_style='';
            if(item_authority=='公开' && item_owner==userid){
                share_button_style='hidden';}             
            if(item_authority=='公开' && item_owner!=userid){
                goat_div=`<div id='goat_div' onclick="share_info('向内拷贝','${new_itemid}')" ><div>Add+</div><div>加入个人仓储</div></div>`;
                gear_button_style='hidden';
                input_style='disabled';
            }
            //
            let ischild='Normal';
            if(item_belong!=item_id){ischild='Ischild';}
            
            let stream_edit_content=document.getElementById("stream_edit_content");
            stream_edit_content.innerHTML=`   
                <div id='file_preview_close' onclick='file_preview_close_click()'><img style='width:30px;height:30px' src="000_image/svg_close.svg"></div>
                <div style=''>${goat_div}</div>                
                <div class='stream_edit_inner'>
                    <div id='stream_edit_head' >
                        <div  id='stream_edit_head_txt'  class='can_select'  onclick="refresh_stream_click2('${item_id}')">
                            ${item_name}
                            <span  id='stream_edit_head_time' style='font-size:xx-small;color:rgba(0, 153, 153,0.5);font-weight:normal' class='refresh_time2'>
                                ${current_time}
                            </span>
                        </div>    
                        <input type='hidden' id='edit_setting_hidden' value='0'>
                        <div id='edit_head_gear' onclick="edit_setting_click()"><img style='width:16px;height:16px' src="000_image/svg_link_gear.svg"></div>
                    </div> 
                    <div id='edit_setting'>
                        <table class='table_topright'>
                            <tr><td>创建者</td><td onclick='copy_str(this.innerText)'>${item_creator}</td><td>拥有者</td><td onclick='copy_str(this.innerText)'>${item_owner}</td><td>创建时间</td><td onclick='copy_str(this.innerText)'>${item_creator_time}</td><td>共享权限</td><td onclick='copy_str(this.innerText)'>${item_authority}</td></tr>
                            <tr><td>指向码</td><td onclick='copy_str(this.innerText)'>${item_belong}</td><td>识别码</td><td onclick='copy_str(this.innerText)'>${item_id}</td><td>更新时间</td><td onclick='copy_str(this.innerText)'>${item_update_time}</td><td>层级位置</td><td onclick='copy_str(this.innerText)'>${ischild}</td></tr>
                        </table>                    
                        <button  onclick="delete_info('${new_itemid}')"  ${gear_button_style}>删除<button>
                        <button  onclick="share_info('向内简单拷贝','${new_itemid}')" ${share_button_style} >复制（不含子模块）<button>
                        <button  onclick="share_info('向内拷贝','${new_itemid}')"  ${gear_button_style}>复制（所有子模块）<button>
                        <button  onclick="share_info('向外分享','${new_itemid}')" ${share_button_style}  ${gear_button_style}>分享（复制所有子模块为新拷贝）<button>
                        </div> 
                    <table class='stream_edit_inner_table'>
                        <tr>
                            <td class='container'>线程预设
                                <div class='container_dropdown'>
                                    <span class='head_span'>线程预设:</span><br>
                                    整个流程的线程请求数量(--ntasks)<br>
                                </div>                            
                            </td>
                            <td><select class='edited_info2' onchange="info_change(this,'${item_id}','线程分配')" onmouseover='this.title=this.value' ${input_style}>  
                                    ${item_threads_options_str}
                                </select></td></tr>
                        <tr>
                            <td class='container'>模板预设
                                <div class='container_dropdown'>
                                    <span class='head_span'>模板预设:</span><br>
                                    一般仅作提示<br>
                                    作为主模块时，根据多输入符号{*}影响输入判断<br>
                                    
                                    <br>例：<br> 
                                    <span class='middle_span'>{输入}</span><br>           
                                    
                                    <br>注:<br>
                                    
                                    作为主模块时，项目任务生成时若存在多输入符号{*}，影响输入判断<br>
                                    {value}花括号内容可被进一步解释
                                </div>                            
                            </td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:20px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','模板预设')"  ${input_style} >${item_stream_template}</textarea></td></tr>  
                        <tr>
                            <td class='container'>参数预设
                                <div class='container_dropdown'>
                                    <span class='head_span'>参数预设:</span><br>
                                    一般仅作提示，对模板预设的进一步解释<br>
                                    作为主模块时，根据多输入符号{*}影响输入判断<br>
                                    
                                    <br>例：<br>
                                    <span class='middle_span'>
                                        输入基因组={输入文件夹}/{名称}.fa<br>
                                        kmer长度=21
                                    </span>
                                    
                                    <br>注:<br>
                                    {value}花括号内容可被进一步解释<br>
                                    多个参数间必须用换行符分隔<br>
                                    每行参数预设必须带等号(=)且等号两边不为空<br>
                                    =value设置固定值不被变量预设进一步解释
                                </div>                            
                            </td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:20px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','参数预设')"  ${input_style} >${item_stream_parameter}</textarea></td></tr>   
                        <tr>
                            <td class='container'>结果预设
                                <div class='container_dropdown'>
                                    <span class='head_span'>结果预设:</span><br>
                                    仅作提示<br>
                                    
                                    <br>例：<br>
                                    <span class='middle_span'>结果={输出文件夹}/{名称}.outfmt6</span><br>           
                                    
                                    <br>注:<br>
                                    {value}花括号内容根据变量输入动态更改
                                </div>
                            </td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:20px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','结果预设')"  ${input_style}>${item_stream_result}</textarea></td></tr>  
                        <tr>
                            <td class='container'>变量预设
                                <div class='container_dropdown' style="bottom:0;top:auto">
                                    <span class='head_span'>变量预设:</span><br>
                                    只作为主模块时生效,用于指定输入文件和参数等<br>
                                    
                                    <br>例：<br>
                                    <span class='middle_span'>
                                        输入文件夹=?<br>
                                        名称=?<br>
                                        kmer=21
                                    </span><br>           
                                    
                                    <br>注:<br>
                                    多个变量间必须用换行符分隔<br>
                                    每行变量预设必须带等号(=)且等号两边不为空<br>
                                    =?为无初始值<br>
                                    =value设置初始值
                                </div>                           
                            </td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:20px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','变量预设')"  ${input_style}>${item_stream_variable}</textarea></td></tr>   
                        <tr>
                            <td>备注信息</td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:20px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','备注信息')"  ${input_style}>${item_stream_note}</textarea></td></tr>                             
                        <tr>
                            <td>功能</td>
                            <td>
                                <button  class='paste_button'  onclick='extract2paste_itemid_click()'>粘贴<span>命令脚本</span></button> 
                                <button  onclick='detail_expand_shrink_click()' id='detail_expand_shrink_button'>折叠</button>  
                        
                            </td>
                        </tr>
                        <!--<tr>                        
                            <td>流程内容</td>
                            <td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:100px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','流程内容')"  ${input_style} id='stream_content'>${item_stream_content}</textarea></td></tr> -->   
                        <tr><td>流程图示</td><td><span style='font-size:xx-small;color:#336699'>通过粘贴快速扩充流程，仅需填写不同于原格式的部分，上下拖动调整处理单元顺序</span></td></tr>    
                        <tr><td style='vertical-align:top'></td><td><ul id='stream_content_ul'></ul></td></tr>
                        <tr style='' hidden><td style='vertical-align:top;'>直接编辑</td><td><textarea  class='edited_info2' style='width:100%;min-width:100%;max-width:100%;min-height:100px'    onmouseover='this.title=this.value' onchange="info_change(this,'${item_id}','流程内容')"  ${input_style} id='stream_content_ul_value'>${item_stream_content}</textarea></td></tr>
                        
            `;
            ////
    
  
            /*document.getElementById('stream_content').addEventListener('input', function() {  
                updateDivs();  
            });  */
          
            function updateDivs() {  
                //const content = document.getElementById('stream_content').value;  
                let content = item_stream_content;
                if (content){
                    let lines = content.split('_;;;_\n');  
                    let container = document.getElementById('stream_content_ul');  
                    container.innerHTML = ''; // 清空现有内容  
                    
                    lines.forEach((line, index) => {  
                        let serial=index+1;
                        let parts = line.split('_|||_');  
                        let li_itemid           =parts[2];
                        //let li_itemid_random    ="li_"+generateRandomString(10);
                        let node_name           ='node_'+generateRandomString(10);
                        let href_php='';
                        if (li_itemid.startsWith('script_')) {href_php="function_script";  }
                        else if (li_itemid.startsWith('stream_')) {href_php="function_stream";  }
                        //
                        let li = document.createElement('li');  
                        li.draggable    = true;  
                        li.className    = 'stream_content_li';  
                        li.id           = node_name; // 设置id属性
                        li.dataset.id   = index; // 使用 data-id 属性来存储索引 
                        // 上中下分别是输入-参数-输出，右侧为更改，顶部作为选项卡1，顶部右侧为删除
                        //是否显示textarea
                        let template_new_button='';let parameter_new_button='';
                        let template_new_tr_class='';let parameter_new_tr_class='';
                        if(parts[3]==''){
                            template_new_button=`<button style='float:right;' onclick="show_textarea(this,'${node_name}_template_new_tr')">修改</button>`;
                            template_new_tr_class=`display_none'`;}
                        if(parts[4]==''){
                            parameter_new_button=`<button style='float:right;' onclick="show_textarea(this,'${node_name}_parameter_new_tr')">修改</button>`;
                            parameter_new_tr_class=`display_none'`;}
                        //
                        li.innerHTML = `  
                            <div class='li_one_div'>
                                <div>
                                    <textarea class="stream_content_li_input "  onchange='update_stream_content_change()' hidden>${li_itemid}</textarea>
                                    <div class='li_topdiv'>
                                        <div class='li_topdiv_head'>
                                            <span class='li_serial'>${serial}</span>
                                            <span class='li_name' id="${node_name}_name"></span>
                                            <input type='hidden' class='collection_marked' value='${node_name}'>
                                            <input type='hidden' class='collection_marked' value=''>
                                            <span class='li_itemid collection_marked' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')">${li_itemid}</span>
                                        </div>
                                        <div class='li_topdiv_middle'></div>
                                        <div class='li_topdiv_setting'>
                                            <button onclick="delete_li('${node_name}')"><img style='width:16px;height:16px' src="000_image/svg_button_garbage.svg"></button>
                                        </div>
                                    </div>
                                    
                                    <div class='li_maindiv'>
                                        <div>
                                            <table class='li_maindiv_table'>
                                                <tr>
                                                    <td>模板预设</td>
                                                    <td><span class='li_name2' id="${node_name}_name2"></span><span id="${node_name}_template"></span>
                                                        ${template_new_button}
                                                    </td>
                                                </tr>
                                                <tr id="${node_name}_template_new_tr" class='${template_new_tr_class}'>
                                                    <td></td>
                                                    <td><textarea class='collection_marked template_revise_texarea' id="${node_name}_template_new" placeholder='空白即默认,三等号（===）两侧为新旧参数,每行一条修订，可以加入新模板' onchange='update_stream_content_change()'>${parts[3]}</textarea> </td>
                                                </tr>
                                                <tr>
                                                    <td>参数预设</td>
                                                    <td><span id="${node_name}_parameter"></span>
                                                        ${parameter_new_button}
                                                    </td>
                                                </tr>                                        
                                                <tr  id="${node_name}_parameter_new_tr" class='${parameter_new_tr_class}'>
                                                    <td></td>
                                                    <td><textarea class='collection_marked parameter_revise_texarea' id="${node_name}_parameter_new" placeholder='空白即默认,等号（=）两侧为新旧参数，每行一条修订，可以加入新参数' onchange='update_stream_content_change()'>${parts[4]}</textarea> </td>
                                                </tr>
                                                <tr class='grey_text'>
                                                    <td>结果参考</td>
                                                    <td><span id="${node_name}_result"></span>
                                                        <input type='hidden' class='collection_marked' value=''>
                                                    </td>
                                                </tr>                                                 
                                            </table>
                                        </div>    
                                    </div>
                                </div>
                                <div class='addition_info'>
                                        <div class='addition_info_topborder'></div>
                                        <div id='${node_name}_addition1'></div>
                                        <div id='${node_name}_addition2'></div>
                                        <div id='${node_name}_addition3'></div>
                                        <div id='${node_name}_addition4'></div>
                                        <div id='${node_name}_addition5'></div>
                                        <div id='${node_name}_addition6'></div>
                                </div>
                            </div>
                        `;  
                        container.appendChild(li);  
 
                        //填充内容
                        fetch_item_info(li_itemid).then(item => { 
                            //console.log('获取到的item信息:', item); 
                            if(item["名称"]){  document.getElementById(node_name+"_name").innerText=  item["名称"].replace(/.*\//, '');}
                            if("命令名称" in item){   document.getElementById(node_name+"_name2").innerText=  item["命令名称"];}
                            if(item["模板预设"]){
                                document.getElementById(node_name+"_template").innerHTML= `<span class='paste_part' onclick='copy_str(this.innerText)'>`+ item["模板预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part ' onclick='copy_str(this.innerText)'>`);
                            }
                            if(item["参数预设"]){document.getElementById(node_name+"_parameter").innerHTML=  `<span class='paste_part ' onclick='copy_str(this.innerText)'>`+ item["参数预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part' onclick='copy_str(this.innerText)'>`);
                            }
                            if(item["结果预设"]){
                                document.getElementById(node_name+"_result").innerHTML= `<span class='paste_part' onclick='copy_str(this.innerText)'>`+ item["结果预设"].replace(/\r?\n|\r/g, `</span><span class='paste_part ' onclick='copy_str(this.innerText)'>`);
                            }
                            if(item["分类1"]){document.getElementById(node_name+"_addition1").innerHTML="<span style='color:#2d5986'>分类1:</span>"+item["分类1"];}
                            if(item["分类2"]){document.getElementById(node_name+"_addition2").innerHTML="<span style='color:#2d5986'>分类2:</span>"+item["分类2"];}
                            if(item["分类3"]){document.getElementById(node_name+"_addition3").innerHTML="<span style='color:#2d5986'>分类3:</span>"+item["分类3"];}
                            if(item["描述1"]){document.getElementById(node_name+"_addition4").innerHTML="<span style='color:#2d5986'>描述1:</span>"+item["描述1"];}
                            if(item["描述2"]){document.getElementById(node_name+"_addition5").innerHTML="<span style='color:#2d5986'>描述2:</span>"+item["描述2"];}
                            if(item["描述3"]){document.getElementById(node_name+"_addition6").innerHTML="<span style='color:#2d5986'>描述3:</span>"+item["描述3"];}
                        })/*.catch(error => {  
                            //console.error('处理item信息时出错:', error);  
                        });
                        console.log("li_item_info:",li_item_info);*/
                          
                    });  
                  
                    // 重新初始化拖拽事件监听器  
                    initDraggableList(container);  
                    
                    //手动调整一次所有textarea的高度
                    adjust_textarea_height();
                    
                }

            }  
            // 初始化  
            updateDivs();  ;
            
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }
    
    function fetch_item_info(item_id) {  
        return fetch('function_stream_get_info.php', {    
            method: 'POST',    
            headers: {    
                'Content-Type': 'application/json',  
            },    
            body: JSON.stringify({  
                'dataregin': "content_simple_one",  
                'item_id': item_id,  
            }),   
        })    
        .then(response => {  
            if (!response.ok) {  
                return response.json().then(errorData => {  
                    // 抛出错误以便在 catch 中捕获  
                    throw new Error(errorData.error);  
                });  
            }  
            return response.json();  
        })  
        .then(data => {  
            let raw_result = data.result;  
            let item = raw_result[0];  
            //console.log('fetch_item_info结果：', item);  
            return item;  
        })  
        .catch(error => {    
            console.error('捕获到的错误:', error); // 查看错误的完整对象 
            showAndFadeOut('error', 2000, 5,error);
            throw error; // 可以选择重新抛出错误，以便上层调用者可以捕获  
        });  
    }  
    function delete_li(liId) {  
        if (confirm('你确定要删除这个项目吗？')) {  
            var li = document.getElementById(liId);  
            if (li) {  
                li.parentNode.removeChild(li);  update_stream_content_change();
            }  
        }  
    }  
    /*function paste_parameter_button(this_value,target_id){
        // 获取目标元素当前的值  
        let currentValue = document.getElementById(target_id).value;  
        currentValue =(currentValue + '\n' + this_value).replace(/^\s*[\r\n]/gm, '').replace(/[\r\n]\s*$/gm, '').replace(/[\r\n]{2,}/g, '\n')
        // 在当前值的基础上添加换行符和this_value  
        document.getElementById(target_id).value = currentValue; 
        update_stream_content_change();
    }*/
    
    //所有的input的value值onchange时触发一个收集，将所有几个li的所有input连起来分别，还是加上\n和_||_分隔符 赋值给<input type='hidden' id='stream_content_ul_value' value=''>
    // 更新隐藏input的函数  
    let debounceTimer = null; 
    function update_stream_content_change() {  
        console.log("update_stream_content_change");
        var container = document.getElementById('stream_content_ul');  
        var lines = Array.from(container.querySelectorAll('li')).map(li => {  
            return Array.from(li.querySelectorAll('.collection_marked')).map(element => {
                if (element.value !== undefined) {
                    // 如果元素有 value 属性，例如 input 或 textarea
                    return element.value.trim();
                } else {
                    // 如果元素没有 value 属性，使用 textContent 或 innerHTML
                    return element.textContent.trim();  // 或者使用 element.innerHTML
                }
            }).join('_|||_');  
        }).join('_;;;_\n');  
        let stream_content_ul_value_object=document.getElementById('stream_content_ul_value');
        stream_content_ul_value_object.value = lines;  
        //stream_content_ul_value_object.onchange();  直接触发太容易了，拖动div时触发了太多次，加个防抖机制
        //
        // 清除之前的定时器，如果它存在的话  //我希望1s内有动作会延迟处理，所有的确定执行动作应发生在一串动作的最后延迟1s
        if (debounceTimer) {  
            clearTimeout(debounceTimer);  
        }  
      
        // 设置一个新的定时器，1秒后执行onchange事件处理函数  
        debounceTimer = setTimeout(() => {  
            stream_content_ul_value_object.onchange();  
            // 清除定时器，以便下次可以重新设置  
            debounceTimer = null;  
        }, 1000);  
    }  
            
            
    function file_preview_close_click(){
        document.getElementById("stream_edit_content").innerHTML='';
        let itemid_hidden=document.getElementById('current_itemid_hidden');
        let old_itemid=itemid_hidden.value;             
        if(old_itemid){
            document.getElementById(old_itemid).classList.remove('marked_row', 'marked_row2');
            $('#'+old_itemid+' .stack_div_hide').each(function() {  $(this).css('display', 'none');  });
            $('#'+old_itemid+' .name_input').each(function() {  $(this).css('height', '24px');  });
            $('#'+old_itemid+' input').each(function() {  $(this).removeClass('slight_border'); });
            $('#path_'+old_itemid).css('fill', '#1296db');
            itemid_hidden.value='';
        }
    }

    function edit_setting_click(){
        console.log('edit_setting_click开始');
        let edit_setting_hidden= document.getElementById('edit_setting_hidden');
        let edit_setting_hidden_old=edit_setting_hidden.value;
        if (edit_setting_hidden_old=='0'){
            edit_setting_hidden.value='1';
            document.getElementById('edit_setting').style.height='75px';
        }
        else{
            edit_setting_hidden.value=0;
            document.getElementById('edit_setting').style.height='0';            
        }
    }

    function info_change(this_object,item_id,col_name){
        let input_value=this_object.value;
        console.log(item_id,col_name,input_value);
        fetch('function_stream_edit_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'item_id':item_id,
                'col_name':col_name,
                'input_value':input_value,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            let current_time=getCurrentTime();
            console.log(raw_result);
            if(data.status=='success'){
                //this_object.classList.remove('green_background_out');  
                this_object.classList.add('green_background');  
                document.getElementById('state_circle_bottom').style.display='block';
                document.getElementById('state_circle_bottom_text').innerText=current_time;
                setTimeout(function() {  
                    this_object.classList.remove('green_background');
                    document.getElementById('state_circle_bottom').style.display='none';
                    //this_object.classList.add('green_background_out');  
                }, 3000);  
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }
    
    //新建脚本
    function create_stream_click(){
        console.log("操作: create_stream_click");
        document.getElementById('new_folder_tr').style.display = "table-row";
        // 将光标移到文本末尾
        let inputElement = document.getElementById('new_folder_tr_input');
        let new_item_id0='stream_'+generateRandomString(10);
        let new_item_id1=new_item_id0;
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
        let new_name='';
        //
        let submitted = false; // 标志位：是否已提交
        function handleSubmit(){
            if(submitted){return false;}
            new_name = inputElement.value;
            create_stream(new_item_id0,new_item_id1,new_name,function() {  
                option_button_click('get_self',new_item_id1);  
            });
            submitted=true;
        }
        // 监听失去焦点事件
        inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            handleSubmit();
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                handleSubmit();
            }
        });
    }
    
    function create_stream(new_item_id0,new_item_id1,new_name,callback){
        console.log('create_stream的新脚本名:',new_name);
        
        fetch('function_stream_create_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'new_item_id0':new_item_id0,
                'new_item_id1':new_item_id1,
                'userid':userid,
                'new_name':new_name,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                callback();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }
    
    function delete_info(item_id){
        console.log('delete_info开始');

        // 弹出确认对话框
        const userConfirmed = confirm("你确定要删除吗？");
        if (!userConfirmed) {return;}// 如果用户没有确认删除，直接返回，不执行删除操作
        
        fetch('function_stream_delete_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'item_id':item_id,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                option_button_click('get_self');  
                showAndFadeOut('success', 2000, 3,'删除成功');
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }
    function item_operate_multi() {
        console.log('批量删除');
        
        // 将 Set 转换为数组（不要 join(';')）
        const checkboxValuesArray = Array.from(checkboxValuesSet);
        console.log('checkboxValuesArray:', checkboxValuesArray);
        let checkboxValuesArray_length=checkboxValuesArray.length;
        if (checkboxValuesArray_length === 0) {
            showAndFadeOut('error', 2000, 3, '至少选择一个复选框！');
            return false;
        }
        
        // 弹出确认对话框
        const userConfirmed = confirm(`你确定要删除所有选中的${checkboxValuesArray_length}条目吗？`);
        if (!userConfirmed) return;
    
        // 遍历数组，逐个删除
        const deletePromises = checkboxValuesArray.map(item_id => 
            fetch('function_stream_delete_info.php', {  
                method: 'POST',  
                headers: { 'Content-Type': 'application/json' },  
                body: JSON.stringify({ item_id }), 
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw new Error(err.error) });
                }
                return response.json();
            })
            .then(data => {
                if (data.status !== 'success') {
                    throw new Error(data.message || '删除失败');
                }
                checkboxValuesSet.clear();
                console.log('删除成功:', data.result);
                return data;
            })
        );
    
        // 等待所有删除操作完成
        Promise.all(deletePromises)
            .then(() => {
                showAndFadeOut('success', 2000, 3, '删除'+checkboxValuesArray_length+'个条目成功');
                option_button_click('get_self'); // 刷新数据
            })
            .catch(error => {
                console.error('删除失败:', error);
                showAndFadeOut('error', 2000, 5, error.message);
            });
    }
        
    function share_info(action,item_id){
        console.log('share_info开始');
        //action为 向外分享 或 向内拷贝
        fetch('function_stream_share_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':action,
                'item_id':item_id,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                if (action=='向外分享'){showAndFadeOut('success', 2000, 3,"分享成功，请点击<span style='#009999'>[向外分享]</span>选项卡");}
                else if (action=='向内拷贝'){showAndFadeOut('success', 2000, 3,"拷贝成功，生成一个全新副本");file_preview_close_click();}
                refresh_stream_click("get_self",'',urlget_searchword,'','');
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 5,error);
        });
    }
    
    /*onclick触发打开新页面，直接用a标签不知道为啥drag时能把元素直接拖出来导致错误*/
    function openNewPage(url) {
        window.open(url, '_blank'); // 在新标签页中打开指定的 URL
    }
    
    function detail_expand_shrink_click(){
        let detail_expand_shrink_button   =document.getElementById('detail_expand_shrink_button');
        if (detail_expand_shrink_button.innerText=="展开"){     detail_expand_shrink_button.innerText='折叠';$(".addition_info").css("width", "auto");}
        else{                                                   detail_expand_shrink_button.innerText='展开';$(".addition_info").css("width", "0");}
        
        
    }
    
    function copy_str(text) {
        // 创建一个不可见的 textarea 元素
        const textArea = document.createElement("textarea");
        textArea.value = text;
    
        // 使 textarea 不可见，但依然可以选择文本
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
    
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
    
        try {
            // 执行复制命令
            const successful = document.execCommand('copy');
            const msg = successful ? '成功' : '失败';
            console.log('文本复制' + msg);
            showAndFadeOut('success', 2000, 3,"已经将文字复制到剪切板，使用ctrl+V进行粘贴");
            //alert('已复制到剪贴板: ' + text);
        } catch (err) {
            console.error('复制文本失败', err);
            showAndFadeOut('error', 2000, 5,error);
        }
    
        // 移除 textarea 元素
        document.body.removeChild(textArea);
    }
    
    /*手动调整一次所有textarea的高度*/
    function adjust_textarea_height(){
        const textareas = document.querySelectorAll('textarea');  
        textareas.forEach(textarea=>{
            textarea.style.height = 'auto';  
            //if (textarea.scrollHeight === 0) { /textarea.style.height = '0px'; //}
            textarea.style.height = textarea.scrollHeight+10 + 'px';  
        });  
    }

    /*显示textarea*/
    function show_textarea(this_object,target_id){
        console.log('show_textarea:',target_id);
        this_object.style.display="none";
        document.getElementById(target_id).classList.remove('display_none');  
    }

    
   
</script>
    
    
    
    
    
    














