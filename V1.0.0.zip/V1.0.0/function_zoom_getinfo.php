<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["userid"]) ){
        $userid         =$input["userid"];   
        //链接数据库
        include 'database_connect.php'; 
        
        $sql = "SELECT * FROM 用户信息 WHERE 用户名自动生成 = ?";
        $params =[ ['type' => 's', 'value' => $userid]]; // 's' 表示字符串类型
        $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量

        $select_theme=$rows[0]['设置_文本编辑器'];
        $select_wrap=$rows[0]['设置_文本编辑器_自动换行'];
        
       
    
        
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => [
                'select_theme' => $select_theme,
                'select_wrap' => $select_wrap,
            ],
        ]);    
    }
    else{
        http_response_code(500);  echo json_encode(['error' => '用户状态错误']);die();
    }
?>























