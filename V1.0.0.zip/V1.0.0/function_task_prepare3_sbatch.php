<?php

    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    
    if (isset($input["task_id"]) && isset($input["userid"]))
    {
        //
        $user_id=$input['userid'];
        $base_path = '/www/wwwroot/bioslurm/user/'.$user_id; 

        
        //链接数据库
        include 'database_connect.php';
       
        $task_id                                    =$input["task_id"];   
        $userid = $input['userid'];
        
        //查找数据
        $sql = "select 所属项目编号,所属项目目录, 线程分配, 使用模块, 模板修订, 参数修订, 变量设置, 作业运行列表, 作业依赖, 作业模板修订, 作业参数修订  from 执行2_任务列表 where 唯一识别码 = ?";  
        $updateStmt = mysqli_prepare($conn, $sql);
        if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}
        mysqli_stmt_bind_param($updateStmt, 's',$task_id); 
        mysqli_stmt_execute($updateStmt);  
        $result = mysqli_stmt_get_result($updateStmt);  
        if (!$result || mysqli_num_rows($result) === 0) {  http_response_code(500);  echo json_encode(['error' => '任务编号错误，找不到任务']);die();} 
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  $results[] = $row;  }  
        mysqli_stmt_close($updateStmt); 
        
        //唯一结果
        $result_one=$results[0];
        $project_id                             =$result_one['所属项目编号'];
        $project_dir                            =$result_one['所属项目目录'];   $project_dir=substr($project_dir, 5);   //去掉开头的/home字样
        $task_module_id                         =$result_one['使用模块']; 
       
        /*project文件夹*/
        $project_absolute_dir=$base_path.$project_dir.'/';
        
        /*project_log文件夹*/
        $project_log_dir=$base_path.$project_dir.'/log_'.$project_id.'/';

        /*生成task_log文件夹*/
        $task_log_absolute_dir=$project_log_dir.$task_id.'/';  //似乎在slurm脚本中不需要绝对路径
        $task_log_absolute_dir = preg_replace('/\/+/', '/', $task_log_absolute_dir);    // 替换 // 为 /
        $task_log_absolute_dir = preg_replace('/\/\.\//', '/', $task_log_absolute_dir);// 替换 /./ 为 /
        
        //判断是否有运行中的任务
        //查找taskid有的jobid
        $sql = "select 作业slurm编号 from 执行3_作业列表 WHERE 拥有者 = ? AND 任务编号 = ? and 状态<>'end' ";  
        $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $task_id]];
        $rows = database_query($conn, $sql, $params); 
        $onejobid_arr = array_column($rows, '作业slurm编号'); // 提取为一维数组
         //本用户的实际运行中的jobid
        $running_jobids=[];
        $squeue  = shell_exec("squeue -h -o '%20i    %60j     %.2t' ");
        if($squeue){
            $lines = array_filter(explode("\n", trim($squeue)));
            foreach ($lines as $line) {
                // 用正则分割字段（处理多个空格）
                $fields = preg_split('/\s+/', trim($line), 3); // 最多分成 3 部分
                if (count($fields) >= 3) {
                    $jobId = $fields[0];    // 第一个字段：作业 ID
                    $jobName = $fields[1];  // 第二个字段：作业名称
                    $status = $fields[2];   // 第三个字段：状态（可能不需要）
                    // 检查作业 ID 是否匹配，且作业名称以 $userid 结尾
                    if (str_ends_with($jobName, $userid)) {$running_jobids[]=$jobId;}
                }
            }
        }
       //交集
        $common_jobs = array_intersect($onejobid_arr, $running_jobids);
        
        if($common_jobs){http_response_code(400); echo json_encode(['error' => '当前task仍有进行中的job，等待完成，或在作业进度中终止已有job']);die();}
        //
        // 使用 exec 执行命令并获取输出
        $job0_slurm_file = $task_log_absolute_dir.'job0.sh';//echo json_encode(['status' => 'success','result' => $job0_slurm_file]);die();
        // 检查文件是否存在
        if (!file_exists($job0_slurm_file)) {http_response_code(400); echo json_encode(['error' => '缺少第二步，请先生成中间脚本']);die();}
        $command="sbatch {$job0_slurm_file} ";
        $command_echo=shell_exec($command);
        $command_echo=trim(array_pop(explode(' ', $command_echo))); // 按空格分割成数组/ 取最后一部分并去除空白
        $time = date('Y-m-d_H:i:s');
        $line = "$time\tL1\tjob0\t$command_echo\tcreate\t$task_id\t$project_dir\t$project_id\t$task_module_id" . PHP_EOL;
        file_put_contents("{$base_path}/.job_ids.txt", $line, FILE_APPEND);
        $result='任务已启动';
        
        // 返回 JSON 响应
        echo json_encode(['status' => 'success','result' => $result,'$onejobid_arr'=>$onejobid_arr,'$running_jobids'=>$running_jobids,'$common_jobs'=>$common_jobs]);die();
    }    
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
    
?>    