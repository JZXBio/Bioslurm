<?php  
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    $action     = $input['action'] ?? '';
    $base_path  = $input['base_path'] ?? '';
    $local_path = $input['local_path'] ?? '';
    
    // 完整路径
    $complete_path = $base_path ."/". $local_path;
    
    // 检查路径是否包含非法字符或模式
    if (preg_match('/(\.\.|\/\.)/', $complete_path)) {
        http_response_code(400);
        echo json_encode(['error' => '错误的路径格式']); // 检测到非法路径
        die();
    }
    // 空格前加转义
    //$complete_path = str_replace(' ', '\ ', $complete_path);
    //$complete_path = str_replace('\\\\', '\\', $complete_path);
    
    
    
    // 执行命令并修改时间格式
    #$cmd = "ls -ll --time-style='+%Y-%m-%d %H:%M' " . escapeshellarg($complete_path);
    if ($action=="get_all"){
        $cmd='ls -ll --time-style="+%Y-%m-%d %H:%M" "'.$complete_path.'"';}
    elseif($action=="get_dir"){
        $cmd='ls -ll --time-style="+%Y-%m-%d %H:%M" "'.$complete_path.'" | grep "^d" | awk \'{print $NF}\' ';}
    else{
        http_response_code(400);
        echo json_encode(['error' => '参数错误']);//ls: 无法访问/home/ddd: 没有那个文件或目录
        die();
    }
    
    
    
    $cmd_result = shell_exec($cmd);
    
    if(strpos("没有那个文件或目录",$cmd_result)!==FALSE ){   //防止输入..等泄露隐藏文件和目录
        http_response_code(400);
        echo json_encode(['error' => '没有那个文件或目录']);//ls: 无法访问/home/ddd: 没有那个文件或目录
        die();
    }
    
    // 确定路径类型
    $is_dir = is_dir($complete_path);

    
    
    // 分割输出为多行  
    $lines = explode("\n", trim($cmd_result));
    
   
    
    if($action=="get_dir"){
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $lines,
        ]);
    }
    else if ($action=="get_all"){
         // 准备结果数组  
        $results = [];
        // 遍历每一行  
        foreach ($lines as $line) {
            /*// 使用正则表达式解析每行，原来的这个可能无法匹配最后的+或.(SELinux 上下文标记)
            #preg_match('/^([\-dl])([rwx\-]{9})\s+(\d+)\s+(\w+)\s+(\w+)\s+(\d+)\s+(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2})\s+(.+)$/', $line, $matches);
            if ($matches) {
                $fileType = $matches[1];        // 文件类型
                //$permissions = $matches[2];     // 权限
                //$linkCount = $matches[3];        // 链接数
                //$owner = $matches[4];            // 所有者   
                //$group = $matches[5];            // 所属组
                $size = $matches[6];             // 文件大小
                $updateTime = $matches[7];      // 更新时间
                $fileName = $matches[8];        // 文件名
        
                // 将解析的数据添加到结果数组
                $results[] = [
                    'fileType' => $fileType,
                    'size' => $size,
                    'updateTime' => $updateTime,
                    'fileName' => $fileName
                ];
            }*/
            preg_match('/^([\-dl])([rwxs\-]{9})([\+\.]*)\s+(\d+)\s+(\w+)\s+(\w+)\s+(\d+)\s+(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2})\s+(.+)$/', $line, $matches);

            if ($matches) {
                $fileType = $matches[1];        // 文件类型（d/-/l）
                $size = $matches[7];            // 文件大小（字节）
                $updateTime = trim($matches[8]); // 更新时间（处理可能的额外空格）
                $fileName = $matches[9];        // 文件名（或链接目标）
            
                // 处理符号链接（如果文件类型是 'l'，文件名可能包含 " -> "）
                if ($fileType === 'l') {
                    $fileName = explode(' -> ', $fileName)[0];
                }
            
                // 将解析的数据添加到结果数组（保持原有结构）
                $results[] = [
                    'fileType' => $fileType,
                    'size' => $size,
                    'updateTime' => $updateTime,
                    'fileName' => $fileName
                ];
            }

        }
        //降序排列数组
        usort($results, function($a, $b) {
            // 如果 $a 是 BioSlurm_share，则 $a 排在前面
            if ($a['fileName'] === 'BioSlurm_share') {
                return -1;
            }
            // 如果 $b 是 BioSlurm_share，则 $b 排在前面
            if ($b['fileName'] === 'BioSlurm_share') {
                return 1;
            }
            
            // 否则按原规则排序
            // 1. 先按 fileType 降序排列（d > l > -）
            if ($a['fileType'] !== $b['fileType']) {
                return strcmp($b['fileType'], $a['fileType']);
            }
            
            // 2. 如果 fileType 相同，则按 fileName 升序排列（A-Z）
            return strcmp($a['fileName'], $b['fileName']);
        });
    
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
            'url_type'=> $is_dir ? '文件夹' :'文件',
            'TEST'=>$cmd,
            'complete_path'=>$complete_path,
            'cmd_result'=>$cmd_result,
        ]);
    }    
?>
