<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["register_user_uuid"])  ){
        //链接数据库
        include 'database_connect.php';
        //http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();
        $register_user_uuid     =$input["register_user_uuid"]; 
        $register_user_name     =$input["register_user_name"]; 
        $register_user_dirname         =$input["register_user_dirname"];         
        $register_email         =$input["register_email"]; 
        $register_password       =$input["register_password"]; 
        
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
        
        $Sql = "SELECT 邮箱 from 用户信息 where 邮箱=?";  
        $Stmt = mysqli_prepare($conn, $Sql);  
        if (!$Stmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}  
        mysqli_stmt_bind_param($Stmt, 's',$register_email); 
        
        //正式执行sql   
        if (!mysqli_stmt_execute($Stmt)) {  http_response_code(500);  echo json_encode(['error' => '无法执行查询']);die();}
        
        $result = mysqli_stmt_get_result($Stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($Stmt); 
        if (empty($results)) {  
        } 
        else {
            http_response_code(500);  echo json_encode(['error' => '邮箱已存在，无法再次注册']);die();
        }
        
        $complete_path_item="/www/wwwroot/bioslurm/user/".$register_user_dirname;
        if (mkdir($complete_path_item, 0777, true)) {$result_log_text="文件夹创建成功"; } 
        else {http_response_code(400);echo json_encode(['error' => '文件夹创建失败']);die();  }  
        
        
        
        //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
        $updateSql = "INSERT INTO 用户信息 (用户uuid,姓名拼音,用户名自动生成,邮箱,密码,创建时间,更新时间,设置_文本编辑器,设置_文本编辑器_自动换行) VALUES (?,?,?,?,?,'{$current_time}','{$current_time}','vs-dark','wrap-yes')";  
        $updateStmt = mysqli_prepare($conn, $updateSql);  
        if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}  
      
        mysqli_stmt_bind_param($updateStmt, 'sssss',$register_user_uuid,$register_user_name,$register_user_dirname,$register_email,$register_password); 
            
        if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}
            
        mysqli_stmt_close($updateStmt);  
        mysqli_close($conn);       
          
  
          
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result'=>'注册成功',
        ]);
        


        
        
        die();
    }

?>























