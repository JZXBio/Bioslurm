<?php
// function_file_download.php

// 获取 POST 数据
$file_path = isset($_POST['file_path']) ? $_POST['file_path'] : '';

if ($file_path) {
    $filePath = '' . $file_path;

    // 确保文件存在
    if (file_exists($filePath)) {
        // 设置头部信息以提示浏览器下载文件
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filePath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        
        // 清空输出缓冲区
        flush();
        
        // 读取文件并输出
        readfile($filePath);
        exit;
    } else {
        http_response_code(404);
        echo '文件未发现.';
    }
} else {
    http_response_code(400);
    echo '未指定文件.';
}