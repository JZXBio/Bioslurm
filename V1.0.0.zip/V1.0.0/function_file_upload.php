<?php
header('Content-Type: application/json'); // 设置内容类型为 JSON

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_path']) && isset($_FILES['files'])) {
        $upload_dir = $_POST['upload_path']; // 获取 POST 数据中的上传目录

        // 确保上传目录存在
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $filelist = []; // 用于存储上传的文件名
        $errors = []; // 用于存储错误信息

        foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
            $file_name = basename($_FILES['files']['name'][$key]);
            $target_file = $upload_dir . DIRECTORY_SEPARATOR . $file_name;

            if (move_uploaded_file($tmp_name, $target_file)) {
                $filelist[] = $file_name; // 成功上传，记录文件名
            } else {
                $errors[] = "Failed to upload file $file_name."; // 上传失败，记录错误信息
            }
        }

        // 返回 JSON 格式的状态和结果
        echo json_encode([
            'status' => empty($errors) ? 'success' : 'error',
            'result' => [
                'filelist' => $filelist,
                'errors' => $errors
            ]
        ]);
    } else {
        // 没有提供上传路径或文件
        echo json_encode([
            'status' => 'error',
            'result' => [
                'filelist' => [],
                'errors' => ['No files or upload path provided.']
            ]
        ]);
    }
} else {
    // 请求方法不正确
    echo json_encode([
        'status' => 'error',
        'result' => [
            'filelist' => [],
            'errors' => ['Invalid request method.']
        ]
    ]);
}
?>
