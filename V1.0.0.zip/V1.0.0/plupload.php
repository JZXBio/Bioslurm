<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>BioSlurm生信服务器</title>  
    <meta name="keywords" content="BioSlurm生信服务器">  
    <meta name="description" content="BioSlurm生信服务器">  
    <link rel="icon" href="000_image/favicon.png" type="image/png">  
    <script src="plug/jquery-3.1.1.min.js" type="text/javascript"></script>  
    <script src="plug/plupload-2.3.9/js/plupload.full.min.js" type="text/javascript"></script>  
    <style>  
        #filelist {  
            margin-top: 10px;  
        }  
        #filelist div {  
            padding: 5px;  
            border-bottom: 1px solid #ccc;  
        }  
        #progressbar {  
            border: 1px solid #ccc;  
            border-radius: 5px;  
            margin-top: 10px;  
        }  
        #progress {  
            transition: width 0.2s; /* 平滑过渡效果 */  
        }  
        #progress-status {  
            margin-top: 5px;  
            text-align: center;  
        }  
    </style>  
</head>  
<body>  
    <div id="container">  
        <a id="pickfiles" href="javascript:;">选择文件</a>  
        <div id="filelist"></div>  
        <button id="start_upload">开始上传</button>  
    </div>  
    <div id="progressbar" style="width: 100%; background-color: #f3f3f3;">  
        <div id="progress" style="width: 0%; height: 25px; background-color: #4caf50;"></div>  
    </div>  
    <div id="progress-status"></div>  
    <script>  
        var uploader = new plupload.Uploader({  
            browse_button: 'pickfiles',  
            url: 'plupload2.php',  
            chunk_size: '10mb', // 分块大小  
            max_file_size: '500gb', // 最大文件大小  
            filters: {  
                mime_types: [  
                    { title: "All files", extensions: "*" }  
                ]  
            },  
            multipart_params: {  
                'targetDir': '/www/wwwroot/bioslurm/user/jinzhongxin_al7dfkas3d/'  
            },  
            init: {  
                PostInit: function() {  
                    document.getElementById('filelist').innerHTML = '';  
                    document.getElementById('start_upload').onclick = function() {  
                        uploader.start();  
                    };  
                },  
                FilesAdded: function(up, files) {  
                    plupload.each(files, function(file) {  
                        document.getElementById('filelist').appendChild(  
                            '<div id="' + file.id + '">' + file.name + ' (' + plupload.formatSize(file.size) + ') <b></b></div>'  
                        );  
                    });  
                },  
                UploadProgress: function(up, file) {  
                    document.getElementById(file.id).getElementsByTagName('b')[0].innerHTML = '<span>' + file.percent + "%</span>";  
                },  
                FileUploaded: function(up, file, info) {  
                    var response = JSON.parse(info.response);  
                    if (response.status === 'success') {  
                        document.getElementById(file.id).getElementsByTagName('b')[0].innerHTML = '<span>上传成功</span>';  
                    } else {  
                        document.getElementById(file.id).getElementsByTagName('b')[0].innerHTML = '<span>上传失败: ' + response.message + '</span>';  
                    }  
                },  
                Error: function(up, err) {  
                    alert("上传出错: " + err.message);  
                }  
            }  
        });  

        uploader.bind('UploadProgress', function(up, file) {  
            var percent = file.percent;  
            document.getElementById('progress').style.width = percent + '%';  
            document.getElementById('progress-status').innerText = percent + '%';  
        });  
        
        uploader.init();  
    </script>  
</body>  
</html>