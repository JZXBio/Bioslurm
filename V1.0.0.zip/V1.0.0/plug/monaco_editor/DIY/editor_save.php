<?php
    // editor_save.php
    
    // 设置响应头为 JSON 格式
    header('Content-Type: application/json');

    // 获取 POST 请求的原始输入数据
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // 检查数据是否解析成功
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400); // Bad Request
        echo json_encode(['error' => '无效的 JSON 数据']);
        exit;
    }
    
    // 验证必要字段
    if (!isset($data['path']) || !isset($data['content'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['error' => '缺少必要参数: path 或 content']);
        exit;
    }
    
    $filePath = $data['path'];
    $content = $data['content'];
    
    // 安全处理：防止目录遍历攻击
    $filePath = str_replace(['../', '..\\'], '', $filePath);
    $filePath = preg_replace('/\/+/', '/', $filePath);
    
    // 定义允许写入的基础目录（确保在 Web 根目录之外更安全）
    //$baseDir = '/var/www/my_site/user_uploads/'; // 示例路径，请根据实际情况修改
    //$baseDir = dirname(__DIR__, 3); 
    $fullPath=$_SERVER['DOCUMENT_ROOT'].'/'. ltrim($filePath, '/');
    
    // 检查路径是否在允许的目录内
    /*if (strpos(realpath($fullPath), realpath($baseDir)) !== 0) {
        http_response_code(403); // Forbidden
        echo json_encode(['error' => '不允许访问该路径']);
        exit;
    }*/
    
    // 尝试写入文件
    try {
        // 确保目录存在
        $dir = dirname($fullPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    
        // 写入文件
        $bytesWritten = file_put_contents($fullPath, $content);
        
        if ($bytesWritten === false) {
            throw new Exception('文件写入失败');
        }
    
        // 返回成功响应
        http_response_code(200);
        echo json_encode(['success' => true, 'bytes_written' => $bytesWritten]);
        
    } catch (Exception $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(['error' => '保存文件时出错: ' . $e->getMessage()]);
    }
?>








