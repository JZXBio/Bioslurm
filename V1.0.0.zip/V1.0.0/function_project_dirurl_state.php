<?php  
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    $base_path  = $input['base_path'] ?? '';
    //$item_id    = $input['item_id'] ?? '';
    $one_url = $input['one_url'] ?? '';
    
    
    // 完整路径
    $complete_path = $base_path ."/". $one_url;
    
    // 检查路径是否包含非法字符或模式
    if (preg_match('/(\.\.|\/\.)/', $complete_path)) {
        http_response_code(400);
        echo json_encode(['error' => '错误的路径格式']); // 检测到非法路径
        die();
    }
    // 空格前加转义
    //$complete_path = str_replace(' ', '\ ', $complete_path);
    //$complete_path = str_replace('\\\\', '\\', $complete_path);
    
    
    
    // 执行命令并修改时间格式
    #$cmd = "ls -ll --time-style='+%Y-%m-%d %H:%M' " . escapeshellarg($complete_path);
    if (file_exists($complete_path)){
       echo json_encode([
            'status' => 'success',
            'result' => '路径存在',
        ]);
    }
    else{
       echo json_encode([
            'status' => 'success',
            'result' => '路径不存在',
        ]);
    }
    
    
    
    
    
    
?>    