<?php
    session_start(); // 开始会话
    //验证登录状态 
    //输入了账号和密码
    if (isset($_POST["user_uuid"]) && isset($_POST["password"])) {  
        if ($_POST["user_uuid"]){$user_input=$_POST["user_uuid"];}
        if ($_POST["password"]){$password_input=$_POST["password"];}
        //链接数据库
        include 'database_connect.php';
        $sql = "SELECT * FROM 用户信息 WHERE (用户UUID = ? OR 用户名自动生成 =? OR 邮箱 = ?)  AND 密码 = ?";  
        $stmt = mysqli_prepare($conn, $sql);  
        if (!$stmt) {  
            http_response_code(500);  
            mysqli_close($conn);  
            echo '<form id="errorForm" action="index.php" method="post">  
                        <input type="hidden" name="error" value="database_connection_failed">  
                  </form>';  
            echo '<script>document.getElementById("errorForm").submit();</script>'; 
            exit; 
        }  
        mysqli_stmt_bind_param($stmt, 'ssss', $user_input, $user_input, $user_input,$password_input); 
        mysqli_stmt_execute($stmt);  
            
        $result = mysqli_stmt_get_result($stmt);  
        $users_info = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $users_info[] = $row;  
        }  

        mysqli_stmt_close($stmt);  

        if (empty($users_info)) {  
            http_response_code(401);  
            mysqli_close($conn);  
            echo '<form id="errorForm" action="index.php" method="post">  
                        <input type="hidden" name="error" value="user_password_failed">  
                  </form>';  
            echo '<script>document.getElementById("errorForm").submit();</script>';             
            exit;  
        }  
        
        // 假设只有一个用户匹配（实际中可能需要处理多个匹配的情况）  
        $one_user_info=$users_info[0];
        $user_uuid                  =$one_user_info['用户UUID'];            $_SESSION['user_uuid'] = $user_uuid;
        $user_name                  =$one_user_info['姓名拼音'];            $_SESSION['user_name'] = $user_name;
        $user_name_id               =$one_user_info['用户名自动生成'];      $_SESSION['user_name_id'] = $user_name_id;
        $user_email                 =$one_user_info['邮箱'];                $_SESSION['user_email'] = $user_email;  
    }
    
    if(isset($_POST["action"]) && $_POST["action"] === "logout") {
        session_start();
        session_unset();
        session_destroy();
        $current_url = $_SERVER['REQUEST_URI'];         // 获取当前页面的 URL
        header("Refresh:0; url=$current_url");          // 刷新当前页面
        exit();
    }
    if (isset($_POST['error'])) {
        if($_POST['error'] === 'database_connection_failed') {  
        echo "<script>alert('error,数据库连接失败');</script>";  }
        elseif($_POST['error'] === 'user_password_failed') {  
        echo "<script>alert('error,用户名/密码错误');</script>";  }
    } 
    
    
    // 根据会话状态设置页面显示逻辑
    if (isset($_SESSION["user_uuid"])){
        //echo 111111111;
        $user_uuid = $_SESSION['user_uuid'];
        $user_email = $_SESSION['user_email'];
        $user_name = $_SESSION['user_name'];

        //改用session了不用form传值了
        $navi_user_state= "
            <span style='font-size:xx-small;margin-left:50px'>欢迎, </span>{$_SESSION['user_name']}<span style='font-size:xx-small'> [{$_SESSION['user_email']}] </span> 
            <div style='display:inline-block'>
                <form  action='' method='post'>
                    <input type='hidden'  name='action' ID='action' value='logout'></input><button id='logout'>[退出]</button>
                </form>    
            </div> ";
        $user_login_div_show="hidden";
        $user_function_show="";
    }
    else{
        $navi_user_state="";
        $user_login_div_show="";
        $user_function_show="hidden";
    }

?>    
    
    
<!DOCTYPE  html>
<html  lang="en">
<head>
    <meta  charset="UTF-8">
    <meta  name="viewport"  content="width=device-width,  initial-scale=1.0">
    <title>BioSlurm生信服务器</title>
    <meta name="keywords" content="BioSlurm生信服务器">
    <meta name="description" content="BioSlurm生信服务器" >
    <link rel="icon" href="000_image/favicon.png" type="image/png">
   
    <style>
        * {box-sizing: border-box;margin:0;padding:0;}
        body {font-family: sans-serif;min-width:300px;background-color: rgba(0,0,0,0.06);}/*background-color: rgba(0,0,0,0.03);*/
        #top_navigator {position:fixed;top:0;width: 100%;background-color:#005580;padding:4px;margin:0 0 auto 0;height:30px;color:white;z-index:100;}
        #top_navigator a{color:white; text-decoration:none; margin:0 10px;font-size:17px;}
        #top_navigator a:hover{color:#ffff99}
        #top_navigator_title_name{font-weight:500;text-shadow: 0 0 1px black, 1px 1px 5px black;}
        #top_navigator_current_time{font-size:xx-small}
        #logout{background: none;border:none;padding: 0;font: inherit;cursor: pointer; color: rgb(200,200,200);outline: none;display:inline-block; font-size:xx-small; }
        #logout:hover{color:red}
        
        #main_content{margin:30px 50px 20px 75px;border:solid 0px red;transition:1s}
        #main_content>div{background-color:white;padding:10px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s;}
        #user_login_div{width:330px}
        #user_register_div{width:330px;}
        
        #easylink_div {position: fixed;left: 0;top: 30px;bottom: 0;width: 60px;display: flex;flex-direction: column;align-items: center;background-color: rgba(0, 0, 0, 0.1);z-index: 100;padding-top:60px}
        .function_link_div{display:block;width:40px;height:40px;margin:5px 10px;border:solid 0px grey;border-radius:5px;background-color:#e6e6e6;cursor:pointer;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;position: relative; 
        }
        .function_link_div:hover{background-color:white;}
        .function_link_div_dropdown{position: absolute;top:100%;left:1px;font-size:10px;opacity:0;width:100px;color:grey;z-index:100;transition: opacity 1s cubic-bezier(0.68, -0.55, 0.27, 1.55);}
        .function_link_div:hover .function_link_div_dropdown{opacity:1}
        .select_div{background-color:#fafafa;position: relative; }
        .select_div:after{
            content: '';  
            position: absolute;  
            right: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-left: 8px solid #fafafa; }
        .select_div:hover:after{border-left: 8px solid white}
        
        
        .part_head{font-weight:bold;color:#006699;font-size:20px;position:relative;padding:3px 5px;width:100px;border:solid 1px rgba(0,0,0,0.0);transition:0.6s}
        .part_head:hover{border:solid 1px rgba(0,0,0,0.05);transition:0s}
        .part_head_dropdown{display:none;position:absolute;top:50%;left:100%;transform: translate(0, -50%);font-size:small;color:#336699;font-weight:normal;border:solid 0px grey;padding:3px 5px;box-shadow: 2px 2px 4px 0px rgba(0,0,0,0.1);border:solid 1px #336699;background-color:#f2f2f2}
        .part_head_dropdown:after{
            content: '';  
            position: absolute;  
            left: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-right: 8px solid #f2f2f2; 
            transition:1s; }
        .part_head_dropdown:before{
            content: '';  
            position: absolute;  
            left: -8px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-right: solid 8px black ;   }
        .part_head:hover .part_head_dropdown{display:inline-block}
 
        .function_div{margin:10px 50px;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center; }
        .function_div a{cursor: pointer; text-decoration:none;color:#335599;font-size:small}
        .function_div_one{
            width:100px;height:100px;border:dashed 1px grey;border-radius: 7px;margin:3px 7px;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: center;align-items:center; 
            background-color:rgba(0, 102, 153,0.1);user-select: none;}
        .function_div_one:hover{background-color:rgba(0, 102, 153,0.15);}
        
        .part_table{margin-left:0px}       
        #slurm_info1{margin-left:50px}
        #slurm_info2{margin-left:50px} 
        .part_table table {padding-bottom:10px;padding-left:0px;font-size:small;margin:5px}
        .part_table table{border-collapse:collapse;;border:solid 0px grey;padding:0}
        .part_table table th:not(:first-child) {border:solid 1px grey;text-align:left;padding:2px 5px;min-width:50px;background-color:rgba(0, 102, 153,0.1);font-weight:normal}
        .part_table table td:not(:first-child){border:solid 1px grey;text-align:left;padding:2px 5px;min-width:50px}
        
        /*#top_message{padding:5px 10px;border:solid 1px grey;border-radius:10px;position:fixed;top:30px;left:50%;transform: translateX(-50%);font-size:small;display:none;opacity: 0; }*/
        .message-box {padding: 5px 10px;border: solid 1px grey;border-radius: 10px;position: fixed;left: 50%;transform: translateX(-50%);font-size: small;display: block;opacity: 1; z-index: 9999;background-color: white;transition: opacity ease-in-out; margin-top: 40px; }
        
        @media screen and  (max-width: 900px) {
             #main_content{margin:35px 10px 70px 10px;}
            #easylink_div{display:none}
    </style>
</head>
<body>
    <div  id='easylink_div' style="margin-top:-20px">
        <a href='index.php' >
            <div class='function_link_div select_div'><img style='width:30px;height:30px' src="000_image/svg_home.svg">
            </div>
        </a>
        
        <a href='function_file.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_file.svg">
                <div class='function_link_div_dropdown'>文件目录</div>
            </div>
        </a>
        
        <a href='function_script.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_script.svg">
                <div class='function_link_div_dropdown'>命令脚本</div>
            </div>
        </a>

        <a href='function_stream.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_stream.svg">
                <div class='function_link_div_dropdown'>线性流程</div>
            </div>
        </a>
        
        <a href='function_structure.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_structure.svg">
                <div class='function_link_div_dropdown'>网络结构</div>
            </div>
        </a>

        <a href='function_project.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_project.svg">
                <div class='function_link_div_dropdown'>项目执行</div>
            </div>
        </a>   

        <a href='function_progress.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_progress.svg">
                <div class='function_link_div_dropdown'>作业进度</div>
            </div>
        </a>           
        
        <a href='function_zoom.php' style='margin-top: auto;margin-bottom:50px'>
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_gear.svg">
            </div>
        </a>              
    </div>        
    <div id='all_sum' >
        <div id='top_navigator'>
            <a id='top_navigator_title_name' href='index.php'>Bioslurm</a>
            <span id="top_navigator_current_time"></span>
            <span id="user_state"><?php echo $navi_user_state;?></span>
        </div>  
        
        <div id='main_content'>
            <div  id='user_login_div' <?php echo $user_login_div_show;?> style='margin-top:60px'>
                <form  action='' method='post'>
                    <table>
                        <tr><td colspan='2'><h4>请先登录！</h4></td></td>    </tr>
                        <tr><td>用户名（邮箱）：</td>           <td><input type='text'  name='user_uuid' ID='user_uuid'></input></td></tr>
                        <tr><td>密码：</td>             <td><input type='password'  name='password' ID='password'></input> </td></tr>
                        <tr><td colspan='2' style='text-align:right'><button>提交</button></td>    </tr>         
                    </table>    
                </form>
            </div>
            <div  id='user_register_div' <?php echo $user_login_div_show;?> >
                
                <table>
                    <tr><td colspan='2'><h4>注册</h4></td></td>    </tr>
                    <tr><td>姓名拼音：</td>           <td><input type='text'  name='register_user_name' ID='register_user_name'  placeholder="例：zhangsan"></input></td></tr>
                    <tr><td>邮箱：</td>           <td><input type='text'  name='register_email' ID='register_email'></input></td></tr>
                    <tr><td>密码：</td>             <td><input type='password'  name='register_password' ID='register_password' ></input> </td></tr>
                    <tr><td colspan='2' style='text-align:right'><button onclick='register_click()'>注册</button></td>    </tr>         
                </table>    
                <div style='font-size:xx-small;color:grey;'>为方便管理，请使用真实姓名和邮箱，谢谢！</div>
            </div>            
            
            <div id='system_div' <?php echo $user_function_show;?> style='font-size:small;margin-top:50px' >
                <span id="server_info1"></span>
                <div id="server_info2" style='display: inline-block;'></div><br>
            </div>
            
            <div id='project_div' <?php echo $user_function_show;?> >
                <div class='part_head'>
                    功能入口
                    <div class='part_head_dropdown' style=' white-space: nowrap;  '>
                        文件目录：传输文件，整理目录<br>
                        命令脚本：生物信息学软件命令，python等语言脚本<br>
                        线性流程：串联多个命令脚本，顺序执行<br>
                        网络结构：用节点连接多个命令脚本，有依赖执行<br>
                        项目执行：配置输入，生成slurm脚本，提交任务
                        作业进度：管理slurm作业
                    </div>
                </div>                
                <div class='function_div'>
                    <a  href='function_file.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_file.svg">
                            文件目录
                        </div>
                    </a>
                    <a  href='function_script.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_script.svg">
                            命令脚本
                        </div>
                    </a>
                    <a  href='function_stream.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_stream.svg">
                            线性流程
                        </div>
                    </a>
                    <a  href='function_structure.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_structure.svg">
                            网络结构
                        </div>
                    </a>                    
                    <a  href='function_project.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_project.svg">
                            项目执行
                        </div>
                    </a>   
                    <a  href='function_progress.php'>
                        <div class='function_div_one'>
                            <img style='width:50px;height:50px' src="000_image/svg_function_progress.svg">
                            作业进度
                        </div>
                    </a>                       
                   
                </div>           
            </div>
            
            <div id='slurm_div' <?php echo $user_function_show;?> >
                <div class='part_head'>
                    任务队列
                    <div class='part_head_dropdown' style=' white-space: nowrap;  '>
                        squeue -o '%20i    %.9P    %60j     %20u    %.2t    %.10M    %.6D    %.4C    %.11R ' 
                    </div>
                </div> 
                <div class='part_table'>
                    <div id="slurm_info1"></div>
                    <div id="slurm_info2"></div>
                </div>
            </div>            
        </div>
    </div>   


<script>
    // 全局配置
    const CONFIG = {
        sysPollInterval: 5000,
        slurmPollInterval: 3000,
        inactivityThreshold: 60000,
        maxRetries: 3,
        retryDelay: 1000
    };
    
    // 全局状态
    let state = {
        pollingSys: null,
        pollingSlurm: null,
        mouseActivityTimer: null,
        retryCounts: { sys: 0, slurm: 0 },
        isPageVisible: true
    };
    
    // 工具函数
    function generateRandomString(length = 8) {
        const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    }
    
    // 更新系统信息（前端渲染）
    async function updateContent_sys() {
        if (!state.isPageVisible) return;
    
        try {
            const response = await fetch(`/index_get_server_info.php?nocache=${generateRandomString()}`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            
            const data = await response.json();
            const serverInfoDiv = document.getElementById('server_info2');
            
            // 清空并重新构建 DOM
            serverInfoDiv.innerHTML = '';
            
            // 系统时间
            const timeSpan = document.createElement('span');
            timeSpan.textContent = `[${data.current_time}]`;
            timeSpan.style.color = '#336699';
            timeSpan.style.fontSize = 'xx-small';
            timeSpan.style.margin = '0 10px 0 2px';
            serverInfoDiv.appendChild(document.createTextNode('系统时间'));
            serverInfoDiv.appendChild(timeSpan);
    
            // 运行时长
            const uptimeSpan = document.createElement('span');
            uptimeSpan.textContent = `[${data.uptime}]`;
            uptimeSpan.style.color = '#336699';
            uptimeSpan.style.fontSize = 'xx-small';
            uptimeSpan.style.margin = '0 10px 0 2px';
            serverInfoDiv.appendChild(document.createTextNode('运行时长'));
            serverInfoDiv.appendChild(uptimeSpan);
    
            // CPU 负载
            const cpuSpan = document.createElement('span');
            cpuSpan.textContent = `[${data.load_1min}/${data.cpu_cores}]`;
            cpuSpan.style.color = '#336699';
            cpuSpan.style.fontSize = 'xx-small';
            cpuSpan.style.margin = '0 10px 0 2px';
            serverInfoDiv.appendChild(document.createTextNode('CPU'));
            serverInfoDiv.appendChild(cpuSpan);
            
            // 内存
            const memSpan = document.createElement('span');
            memSpan.textContent = `[${data.used_memory}/${data.total_memory}G]`;
            memSpan.style.color = '#336699';
            memSpan.style.fontSize = 'xx-small';
            memSpan.style.margin = '0 10px 0 2px';
            serverInfoDiv.appendChild(document.createTextNode('内存'));
            serverInfoDiv.appendChild(memSpan);
    
            state.retryCounts.sys = 0; // 重置重试计数器
        } catch (error) {
            console.error('Fetch error (sys):', error);
            state.retryCounts.sys++;
            if (state.retryCounts.sys <= CONFIG.maxRetries) {
                setTimeout(updateContent_sys, CONFIG.retryDelay);
            }
        }
    }
    
    // 更新 Slurm 信息（前端渲染表格）
    async function updateContent_slurm() {
        if (!state.isPageVisible) return;
    
        try {
            const response = await fetch(`/index_get_slurm_info.php?nocache=${generateRandomString()}`);
             // 检查响应状态并解析错误信息
            if (!response.ok) {
                const errorData = await response.json().catch(() => null); // 尝试解析 JSON
                const errorMsg = errorData?.error || `HTTP 错误! 状态码: ${response.status}`;
                
                // 如果是权限/配置错误，停止轮询（否则继续重试）
                if (response.status === 403 || response.status === 500 && errorData?.error) {
                    console.warn('Slurm 接口不可用，停止轮询:', errorMsg);
                    stopPolling('slurm'); // 关键修改：停止轮询
                }
                
                throw new Error(errorMsg);
            }
            
            // 假设返回 JSON
            const jobs = await response.json();
            const slurmDiv = document.getElementById('slurm_info2');
            
            // 清空并重新构建表格
            slurmDiv.innerHTML = '';
            const table = document.createElement('table');
            
            // 表头
            const headerRow = document.createElement('tr');
            const headers = ['', '任务ID', '名字', '用户', '状态', 'NODEs', 'CPUs', '运行时间', '备注'];
            headers.forEach((text, index) => {
                const th = document.createElement('th');
                if (index === 0) {
                    th.style.backgroundColor = 'transparent';
                    th.style.border = 'none';
                } else {
                    th.textContent = text;
                }
                headerRow.appendChild(th);
            });
            table.appendChild(headerRow);
    
            // 表格内容
            jobs.forEach((job, rowIndex) => {
                const row = document.createElement('tr');
                
                // 行号
                const indexCell = document.createElement('td');
                indexCell.textContent = rowIndex + 1;
                indexCell.style.backgroundColor = 'rgba(255, 153, 204, 0.1)';
                indexCell.style.border = 'solid 1px grey';
                row.appendChild(indexCell);
    
                // 任务数据
                [job.jobid, job.name, job.user, job.status, job.nodes, job.cpus, job.runtime, job.reason]
                    .forEach(text => {
                        const td = document.createElement('td');
                        td.textContent = text;
                        row.appendChild(td);
                    });
    
                table.appendChild(row);
            });
    
            slurmDiv.appendChild(table);
            state.retryCounts.slurm = 0;
        } catch (error) {
            console.error('Fetch error (slurm):', error);
            showAndFadeOut('error', 2000, 3,error);
            state.retryCounts.slurm++;
            if (state.retryCounts.slurm <= CONFIG.maxRetries) {
                setTimeout(updateContent_slurm, CONFIG.retryDelay);
            }
        }
    }
    
    // 轮询控制
    function startPolling(type) {
        stopPolling(type); // 先停止现有轮询，避免重复
        if (type === 'sys') {
            console.log('启动 sys 轮询，间隔:', CONFIG.sysPollInterval);
            state.pollingSys = setInterval(updateContent_sys, CONFIG.sysPollInterval);
        } else if (type === 'slurm') {
            console.log('启动 slurm 轮询，间隔:', CONFIG.slurmPollInterval);
            state.pollingSlurm = setInterval(updateContent_slurm, CONFIG.slurmPollInterval);
        }
    }
    
    function stopPolling(type) {
        if (type === 'sys' && state.pollingSys) {
            clearInterval(state.pollingSys);
            state.pollingSys = null;
            console.log('已停止 sys 轮询');
        } else if (type === 'slurm' && state.pollingSlurm) {
            clearInterval(state.pollingSlurm);
            state.pollingSlurm = null;
            console.log('已停止 slurm 轮询');
        }
    }
    
    // 鼠标活动检测
    // 鼠标活动检测（优化：避免重复启动轮询）
    function resetMouseTimer() {
        if (state.mouseActivityTimer) clearTimeout(state.mouseActivityTimer);
        if (state.isPageVisible && !state.pollingSys) startPolling('sys');
        if (state.isPageVisible && !state.pollingSlurm) startPolling('slurm');
        state.mouseActivityTimer = setTimeout(() => {
            if (state.isPageVisible) {
                console.log('用户无操作，暂停轮询');
                stopPolling('sys');
                stopPolling('slurm');
            }
        }, CONFIG.inactivityThreshold);
    }
    
    // 事件监听
    function setupEventListeners() {
        document.addEventListener('visibilitychange', () => {
            state.isPageVisible = document.visibilityState === 'visible';
            if (state.isPageVisible) {
                resetMouseTimer();
            } else {
                stopPolling('sys');
                stopPolling('slurm');
                if (state.mouseActivityTimer) clearTimeout(state.mouseActivityTimer);
            }
        });
    
        const activityEvents = ['mousemove', 'mousedown', 'keydown', 'touchstart'];
        activityEvents.forEach(event => {
            document.addEventListener(event, resetMouseTimer, { passive: true });
        });
    }
    
    // 初始化
    // 初始化
    document.addEventListener('DOMContentLoaded', () => {
        setupEventListeners();
        if (document.visibilityState === 'visible') {
            startPolling('sys');
            startPolling('slurm');
            resetMouseTimer();
        }
    });
</script>
<script>
    function register_click(){
        console.log('register_click');
        let register_user_name  = document.getElementById('register_user_name').value;
        let register_email      = document.getElementById('register_email').value;
        let register_password   = document.getElementById('register_password').value;
        let register_user_uuid       = 'user_'+generateRandomString(7);
        let register_user_dirname = register_user_name+"_"+generateRandomString(10);
        //
        if(!register_user_name){showAndFadeOut('error', 2000, 3,'用户名不能为空');return false;}
        if(!register_email){showAndFadeOut('error', 2000, 3,'邮箱不能为空');return false;}
        if(!register_password){showAndFadeOut('error', 2000, 3,'密码不能为空');return false;}
        //
        // 定义长度限制
        const MIN_USERNAME_LENGTH = 2;
        const MAX_USERNAME_LENGTH = 20;
        const MIN_EMAIL_LENGTH = 5;
        const MAX_EMAIL_LENGTH = 100;
        const MIN_PASSWORD_LENGTH = 6;
        const MAX_PASSWORD_LENGTH = 32;
    
        // 验证用户名（仅允许字母、数字、下划线）
        if (register_user_name.length < MIN_USERNAME_LENGTH || register_user_name.length > MAX_USERNAME_LENGTH) {
            showAndFadeOut('error', 2000, 3,`用户名长度必须在 ${MIN_USERNAME_LENGTH}-${MAX_USERNAME_LENGTH} 个字符之间`);return false;
            return false;
        }
        if (register_email.length < MIN_EMAIL_LENGTH || register_email.length > MAX_EMAIL_LENGTH) {
            showAndFadeOut('error', 2000, 3,`邮箱长度必须在 ${MIN_EMAIL_LENGTH}-${MAX_EMAIL_LENGTH} 个字符之间`);return false;
            return false;
        }            
        if (register_password.length < MIN_PASSWORD_LENGTH || register_password.length > MAX_PASSWORD_LENGTH) {
            showAndFadeOut('error', 2000, 3,`密码长度必须在 ${MIN_PASSWORD_LENGTH}-${MAX_PASSWORD_LENGTH} 个字符之间`);return false;
            return false;
        }
        // 正则表达式：只允许26个英文字母（大小写均可）
        const regex = /^[a-zA-Z]+$/;
        if (!regex.test(register_user_name)) {
            showAndFadeOut('error', 2000, 3,'用户名仅支持26个英文字母');return false;
        } else {
            register_user_name = register_user_name.toLowerCase();// 转换为小写
            console.log("用户名有效:", register_user_name);
        }
        //
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if(emailRegex.test(register_email)==false){showAndFadeOut('error', 2000, 3,'邮箱格式错误！');return false;}
        //
        fetch('register.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'register_user_uuid':register_user_uuid,
                'register_user_name':register_user_name,
                'register_email':register_email,
                'register_password':register_password,
                'register_user_dirname':register_user_dirname,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            console.log(111111111111111111111111);
            let raw_result=data.result;
            //let current_time=getCurrentTime();
            console.log(raw_result);
            if(data.status=='success'){
                //this_object.classList.remove('green_background_out');  
                showAndFadeOut('success', 2000, 3,'注册成功！');return false;
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    
    
    
    
    
    
     // 渐显并渐隐函数
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        // 创建新的消息元素
        var div = document.createElement("div");
        div.className = "message-box"; // 应用样式类
    
        let message_text_new = '';
        
        // 根据消息类型设置背景颜色和内容
        if (message_type == "error") {
            div.style.backgroundColor = "rgb(255, 255, 153)";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> " + message_text;
        } else if (message_type == "success") {
            div.style.backgroundColor = "#e5ffe5";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> " + message_text;
        } else {
            div.style.backgroundColor = "gray";
            message_text_new = message_text;
        }
    
        div.innerHTML = message_text_new;
        div.style.transition = `opacity ${fadeDuration}s ease-in-out`; // 动态设置渐隐时长
    
        // 将新的消息元素添加到 body
        document.body.appendChild(div);
    
        // 动态调整所有消息的 vertical 位置，防止重叠
        adjustMessagesPosition();
    
        // 延时后开始渐隐
        setTimeout(function() {
            div.style.opacity = 0; // 开始渐隐
            
            // 渐隐完成后移除元素
            setTimeout(function() {
                document.body.removeChild(div);
                adjustMessagesPosition(); // 调整剩余消息的位置
            }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
        }, delayBeforeFade);
    }
    // 动态调整所有消息的位置，防止重叠
    function adjustMessagesPosition() {
        const messages = document.querySelectorAll('.message-box'); // 选择所有消息元素
        let currentTop = 0; // 从顶部开始，预留一些空间
    
        messages.forEach(message => {
            message.style.top = `${currentTop}px`;
            currentTop += message.offsetHeight + 2; // 累加消息高度和间距
        });
    }
</script>    
    
</body>
</html>       
        
        
        
        
    
        
        
<?php

    if (isset($_SESSION["user_uuid"])==false){die();}
    
    //服务器IP
    $server_info1 = "服务器<span style='color:#336699;font-size:xx-small;margin:0 10px 0 2px'>[{$_SERVER['SERVER_ADDR']}]</span>"; 
    echo "<script>document.getElementById('server_info1').innerHTML=\"$server_info1\";</script>";
    

    //集群
    // 假设$output是`scontrol show nodes`命令的输出  
    $output = shell_exec("scontrol show nodes");  
    preg_match_all('/CfgTRES=cpu=(\d+),mem=(\d+)M/', $output, $matches);  
    // 遍历匹配结果  
    for ($i = 0; $i < count($matches[1]); $i++) {  
        $slurm_max_cpu = $matches[1][$i];  
        $slurm_max_mem = intval($matches[2][$i]/1024);  
    }  
    $slurm_info1="<span style='color:#336699;font-size:xx-small;margin:0 10px 0 2px'>线程限制[{$slurm_max_cpu} by slurm]</span>"; 
    $slurm_info1.="<span style='color:#336699;font-size:xx-small;margin:0 10px 0 2px'>内存限制[{$slurm_max_mem} by slurm]</span>"; 
    echo "<script>document.getElementById('slurm_info1').innerHTML=\"$slurm_info1\";</script>";
    
    
    
        
?>        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        






