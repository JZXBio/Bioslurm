<?php  

    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    //链接数据库
    include 'database_connect.php';
    
    $action = $input['action'];
    $userid = $input['userid'];
    $taskid = $input['taskid'];
    /*
    if ($action=='ClearENDs'){
        # $sql = "DELETE FROM 执行3_作业列表 WHERE 拥有者=? and 任务编号=? and 状态='end'";  
        $sql = "UPDATE 执行3_作业列表 SET 系统备注 ='删除' WHERE 拥有者 = ? AND 任务编号 = ? AND 状态 = 'end'";
        $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $taskid]]; // 's' 表示字符串类型
        $rows = database_query($conn, $sql, $params); 
        // 成功响应
        echo json_encode([
            'success' => true,
            'result' => $rows
        ]);
    }*/
    if ($action=='StopAll' || $action=='ClearALL' ){
        //查找要终止的jobid
        $sql = "select 作业slurm编号 from 执行3_作业列表 WHERE 拥有者 = ? AND 任务编号 = ? and 状态<>'end' ";  
        $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $taskid]];
        $rows = database_query($conn, $sql, $params); 
        $onejobid_arr = array_column($rows, '作业slurm编号'); // 提取为一维数组
        
        //本用户的实际运行中的jobid
        $running_jobids=[];
        $squeue  = shell_exec("squeue -h -o '%20i    %60j     %.2t' ");
        if(empty($squeue)){}
        else{
            $lines = array_filter(explode("\n", trim($squeue)));
            foreach ($lines as $line) {
                // 用正则分割字段（处理多个空格）
                $fields = preg_split('/\s+/', trim($line), 3); // 最多分成 3 部分
                if (count($fields) >= 3) {
                    $jobId = $fields[0];    // 第一个字段：作业 ID
                    $jobName = $fields[1];  // 第二个字段：作业名称
                    $status = $fields[2];   // 第三个字段：状态（可能不需要）
                    // 检查作业 ID 是否匹配，且作业名称以 $userid 结尾
                    if (str_ends_with($jobName, $userid)) {$running_jobids[]=$jobId;}
                }
            }
        }    
        //交集
        $output_all='';
        $common_jobs = array_intersect($onejobid_arr, $running_jobids);
        foreach($common_jobs as $onejobid){
            $command = "scancel " . escapeshellarg($onejobid);
            $output = shell_exec($command);
            $output_all.=$output;
            //
        }    
        //批量打上删除标记
        // 拼接任务编号到 SQL（直接值，非参数化）
        if (empty($common_jobs)) {}
        else{
            $closing_jobIds = implode(',', array_map(fn($id) => "'" . intval($id) . "'", $common_jobs)); // 强制转为整数
    
            $sql = "UPDATE 执行3_作业列表 SET 状态 = 'die' WHERE 拥有者 = ? AND 作业slurm编号 IN ($closing_jobIds)";
            #$sql = "UPDATE 执行3_作业列表 SET 系统备注 ='删除' WHERE 拥有者 = ? AND 任务编号 = ?";  
            $params =[ ['type' => 's', 'value' => $userid]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params); 
        }   
        //
        if ($action=='ClearALL') {
            $sql = "UPDATE 执行3_作业列表 SET 系统备注 ='删除' WHERE 拥有者 = ? AND 任务编号 = ?";  
            $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $taskid]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params); 
        }
        // 成功响应
        echo json_encode([
            'success' => true,
            'result' => $sql,
            'logs' => $output_all
        ]);
    }

    
   



?>


























