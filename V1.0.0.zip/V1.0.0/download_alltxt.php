<?php
require 'vendor/autoload.php';
 
/*
###安装插件，使可以下载所有的数据库表格
修改php.ini,   
extension=fileinfo的注释去掉使其生效，，，

############################################安装fileinfo，下载一个同版本的php，然后只编译安装fileinfo部分
##查找config在哪里
sudo find / -name "php-config" 2>/dev/null   #，发现在/www/server/php/82/bin/php-config
——————————————————————————————————————
cd /usr/local/src/
wget https://www.php.net/distributions/php-8.2.28.tar.gz
tar -xzvf php-8.2.28.tar.gz
cd php-8.2.28/ext/fileinfo
phpize
./configure --with-php-config=/www/server/php/82/bin/php-config
make
sudo make install
————————————————————————————————————————————————
确保安装来了composer：composer --version

cd /www/wwwroot/bioslurm/
composer init          #初始化，此时网站文件夹内多了个json文件composer.json
composer require phpoffice/phpspreadsheet         #安装phpspreadsheet，此时网站文件夹内多了个vendor文件夹
*/

 
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
 
// 设置默认字符集为UTF-8
\PhpOffice\PhpSpreadsheet\Settings::setLocale('zh_CN');
 
// 创建Excel对象
$excel = new Spreadsheet();
 
// 数据库连接信息
include 'database_connect.php';


 
// 检查数据库连接
if ($conn->connect_error) {
    die("连接数据库失败: " . $conn->connect_error);
}
$conn->set_charset("utf8");
 

 
// 循环创建工作表并填充数据
foreach ($tables as $tableName) {
    createWorksheetWithData($excel, $conn, $tableName);
}
// 定义一个目录来保存文本文件
$txtDir = 'txt_files';
if (!file_exists($txtDir)) {
    mkdir($txtDir, 0777, true);
}


$sheetNames =["用户信息", "预设1_命令脚本", "预设2_线性流程", "预设3_网络结构", "执行1_项目列表", "执行2_任务列表", "执行3_作业列表"];
// 准备八个SQL查询语句，分别查询八个子表格的数据
// 使用array_map生成SQL查询语句数组
$sqls = array_map(function($sheetName) {
    return "SELECT * FROM " . $sheetName;
}, $sheetNames);
/*
$sqls = [
    "SELECT * FROM 重要信息",
    "SELECT * FROM 人员信息",
    "SELECT * FROM 文章信息",
    "SELECT * FROM 事件信息",
    "SELECT * FROM 图片信息",
    "SELECT * FROM 文件信息",
    "SELECT * FROM 宣传内容",
    "SELECT * FROM 网站记事",
    "SELECT * FROM 网站记事",
    "SELECT * FROM 网站记事",
    "SELECT * FROM 网站记事",
    "SELECT * FROM 网站记事",
];*/



// 保存每个子表格的数据为txt文件
for ($i = 0; $i < count($sqls); $i++) {
    $sql = $sqls[$i];
    $sheetName = $sheetNames[$i];

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $filename = $txtDir . '/' . $sheetName . '.txt';
        $file = fopen($filename, 'w');

        // 写入表头
        $row_data = $result->fetch_assoc();
        $headers = array_keys($row_data);
        fwrite($file, implode("\t", $headers) . PHP_EOL);

        // 写入数据
        mysqli_data_seek($result, 0);
        while ($row_data = $result->fetch_assoc()) {
            fwrite($file, implode("\t", $row_data) . PHP_EOL);
        }

        fclose($file);
    }
}

// 关闭数据库连接
$conn->close();

// 创建一个ZipArchive对象
$zip = new ZipArchive();
$current_time = date("YmdHis") . rand(0, 9) . rand(0, 9) . rand(0, 9);
$zipFilename = 'bioslurm_info_txt_'.$current_time.'.zip';

// 打开zip文件，如果不存在则创建
if ($zip->open($zipFilename, ZipArchive::CREATE) === TRUE) {
    // 将每个txt文件添加到zip文件中
    foreach ($sheetNames as $sheetName) {
        $filename = $txtDir . '/' . $sheetName . '.txt';
        $zip->addFile($filename, $sheetName . '.txt');
    }

    // 关闭zip文件
    $zip->close();
}

// 提供下载链接
header('Content-Type: application/zip');
header('Content-Disposition: attachment;filename="' . $zipFilename . '"');
header('Cache-Control: max-age=0');

// 读取zip文件内容并输出给浏览器
readfile($zipFilename);

// 删除临时文件和目录
unlink($zipFilename);
foreach ($sheetNames as $sheetName) {
    $filename = $txtDir . '/' . $sheetName . '.txt';
    unlink($filename);
}
rmdir($txtDir);
?>