<?php
$uploadDir = 'data_transfer/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$response = array('success' => false);

if (!empty($_FILES['file']['name'][0])) {
    foreach ($_FILES['file']['name'] as $key => $name) {
        $filePath = $uploadDir . basename($name);
        if (move_uploaded_file($_FILES['file']['tmp_name'][$key], $filePath)) {
            $response['success'] = true;
        } else {
            $response['success'] = false;
            break;
        }
    }
}

echo json_encode($response);
?>
