<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    function generateRandomString($length) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomIndex = rand(0, $charactersLength - 1);
            $randomString .= $characters[$randomIndex];
        }
        return $randomString;
    }
    if (isset($input["action"]) && isset($input["item_id"]) && isset($input["userid"])){

        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $action                     =$input["action"];       //action为 向外分享 或 向内拷贝
        $item_id                    =$input["item_id"];  
        $userid                     =$input["userid"];  
        $new_item_id0 = 'script_' . generateRandomString(10);
        $new_item_id1 = $new_item_id0;
 
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
         
        //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
        if($action=="向外分享"){
            $sql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备)  
                SELECT '$current_time','$new_item_id0','$new_item_id1',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'公开','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备
                FROM 预设1_命令脚本 WHERE 唯一识别码 = ?";  }
        elseif($action=="向内拷贝"){
            $sql = "INSERT INTO 预设1_命令脚本 (创建时间,识别码,唯一识别码,名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,拥有者,共享权限,更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备)  
                SELECT '$current_time','$new_item_id0','$new_item_id1',名称,分类1,分类2,分类3,描述1,描述2,描述3,创建者,?,'个人','$current_time',环境类型,环境预备,运行模式,线程分配,命令类型,命令名称,命令地址,参数预设,模板预设,结果预设,变量预设,备注信息,脚本内容,完成整备
                FROM 预设1_命令脚本 WHERE 唯一识别码 = ?";  }
        $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $item_id]]; // 's' 表示字符串类型
        $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
        //$structure_content=$rows[0]['网络内容'];
  
          
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
        ]);
        


        
        
        die();
    }

?>























