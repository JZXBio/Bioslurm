src="./min/vs/loader.js"

// 创建编辑器主容器
function createEditorElements() {
    // 创建主编辑器容器
    const editorContainer = document.createElement('div');
    editorContainer.className = 'editor_contenter';
    editorContainer.id = 'editor_contenter';
    editorContainer.style.display = 'none';
    editorContainer.style.position = 'fixed'; // 固定定位，脱离文档流
    editorContainer.style.top = '50px';
    editorContainer.style.left = '50px';
    editorContainer.style.zIndex = '2147483647'; // 确保在最上层

    // 创建8个调整大小的手柄
    const handlePositions = ['top', 'right', 'bottom', 'left', 'top-left', 'top-right', 'bottom-left', 'bottom-right'];
    handlePositions.forEach(pos => {
        const handle = document.createElement('div');
        handle.className = `editor_resize_handle ${pos}`;
        handle.id = `editor_resize${pos.replace(/-/g, '').replace('top', 'Top').replace('right', 'Right').replace('bottom', 'Bottom').replace('left', 'Left')}`;
        editorContainer.appendChild(handle);
    });

    // 创建标题栏
    const titleBar = document.createElement('div');
    titleBar.className = 'editor_titleBar';
    titleBar.id = 'editor_titleBar';
    
    const titleText = document.createElement('div');
    titleText.className = 'editor_title_text';
    titleText.textContent = '文本编辑器';
    titleText.style.display = 'flex';
    titleText.style.alignItems = 'center';     // 垂直居中
    titleText.style.height = '100%';           // 需要高度才能垂直居中
    
    // 创建保存按钮
    const saveBtn = document.createElement('div');
    saveBtn.className = 'editor_window_control editor_save_btn';
    saveBtn.id = 'editor_saveBtn';
    saveBtn.setAttribute('onclick', 'save_current_file()');
    saveBtn.title = '保存';
    saveBtn.style.float = 'right';
    saveBtn.style.marginLeft = '20px';
    saveBtn.style.width = '70px';
    
    const saveSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    saveSvg.setAttribute('viewBox', '0 0 24 24');
    saveSvg.setAttribute('width', '16');
    saveSvg.setAttribute('height', '16');
    saveSvg.setAttribute('fill', 'white');
    
    const savePath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    savePath.setAttribute('d', 'M17 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7l-4-4zm-5 16h-2v-4h2v4zm4-9h-6V5h6v5z');
    saveSvg.appendChild(savePath);
    
    const saveText = document.createElement('div');
    saveText.style.float = 'right';
    saveText.textContent = '保存';
    
    saveBtn.appendChild(saveSvg);
    saveBtn.appendChild(saveText);
    titleText.appendChild(saveBtn);
    titleBar.appendChild(titleText);
    
    // 创建刷新按钮
    const refreshBtn = document.createElement('div');
    refreshBtn.className = 'editor_window_control editor_refresh_btn';
    refreshBtn.id = 'editor_refreshBtn';
    refreshBtn.setAttribute('onclick', 'refresh_current_file()'); // 假设的刷新函数
    refreshBtn.title = '刷新';
    refreshBtn.style.float = 'right';
    refreshBtn.style.marginLeft = '2px';
    refreshBtn.style.width = '70px';
    
    // 创建SVG图标（使用Material Icons的刷新图标）
    const refreshSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    refreshSvg.setAttribute('viewBox', '0 0 24 24');
    refreshSvg.setAttribute('width', '16');
    refreshSvg.setAttribute('height', '16');
    refreshSvg.setAttribute('fill', 'white');
    
    // 刷新图标的路径数据（Material Design的刷新图标）
    const refreshPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    refreshPath.setAttribute('d', 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z');
    refreshSvg.appendChild(refreshPath);
    
    // 创建按钮文本
    const refreshText = document.createElement('div');
    refreshText.style.float = 'right';
    refreshText.textContent = '刷新';
    
    // 组装按钮
    refreshBtn.appendChild(refreshSvg);
    refreshBtn.appendChild(refreshText);
    
    // 假设titleText是已存在的父容器（和你的保存按钮示例一致）
    titleText.appendChild(refreshBtn);

    // 创建窗口控制按钮
    const windowControls = document.createElement('div');
    windowControls.className = 'editor_window_controls';
    
    // 最小化按钮
    const minBtn = createControlButton('editor_minimizeBtn', 'editor_minimize()', 
        `M65.23884 456.152041 958.760137 456.152041l0 111.695918L65.23884 567.847959 65.23884 456.152041z`);
    
    // 最大化按钮
    const maxBtn = createControlButton('editor_maximizeBtn', 'editor_maximize()', 
        `M972.8 0H665.6a51.2 51.2 0 0 0 0 102.4h183.6032L629.41184 322.19136a51.2 51.2 0 0 0 72.3968 72.3968L921.6 174.7968V358.4a51.2 51.2 0 0 0 102.4 0V51.2a51.2 51.2 0 0 0-51.2-51.2zM409.6 51.2a51.2 51.2 0 0 0-51.2-51.2H51.2A51.44576 51.44576 0 0 0 0 51.2v307.2a51.2 51.2 0 0 0 102.4 0V174.7968l219.79136 219.81184a51.2 51.2 0 0 0 72.3968-72.3968L174.7968 102.4H358.4a51.2 51.2 0 0 0 51.2-51.2zM1024 665.6a51.2 51.2 0 0 0-102.4 0v183.6032L701.80864 629.41184a51.2 51.2 0 0 0-72.3968 72.3968L849.2032 921.6H665.6a51.2 51.2 0 0 0 0 102.4h307.2a51.44576 51.44576 0 0 0 51.2-51.2zM358.4 921.6H174.7968l219.81184-219.79136a51.2 51.2 0 0 0-72.3968-72.3968L102.4 849.2032V665.6a51.2 51.2 0 0 0-102.4 0v307.2a51.2 51.2 0 0 0 51.2 51.2h307.2a51.2 51.2 0 0 0 0-102.4z`);
    
    // 关闭按钮
    const closeBtn = createControlButton('editor_closeBtn1', 'editor_close()', 
        `M940.8 83.2c25.6 25.6 25.6 64 0 83.2L595.2 512l345.6 345.6c25.6 25.6 25.6 64 0 83.2-25.6 25.6-64 25.6-83.2 0L512 595.2l-345.6 345.6c-25.6 25.6-64 25.6-83.2 0-25.6-25.6-25.6-64 0-83.2L428.8 512 83.2 166.4c-25.6-25.6-25.6-64 0-83.2s64-25.6 83.2 0L512 428.8l345.6-345.6C876.8 57.6 921.6 57.6 940.8 83.2z`);
    
    windowControls.appendChild(minBtn);
    windowControls.appendChild(maxBtn);
    windowControls.appendChild(closeBtn);
    titleBar.appendChild(windowControls);
    editorContainer.appendChild(titleBar);

    // 创建标签页栏
    const nameBar = document.createElement('div');
    nameBar.id = 'editor_name_bar';
    editorContainer.appendChild(nameBar);

    // 创建底部内容区域
    const bottomContent = document.createElement('div');
    bottomContent.id = 'editor_bottom_content';
    editorContainer.appendChild(bottomContent);

    // 创建小窗口编辑器
    const smallEditor = document.createElement('div');
    smallEditor.className = 'editor_contenter_small';
    smallEditor.id = 'editor_contenter_small';
    smallEditor.style.width = '185px';
    smallEditor.style.left = '50%';
    smallEditor.style.top = '10px';
    smallEditor.style.position = 'fixed';
    smallEditor.style.zIndex = '2147483647'; // 确保在最上层
    smallEditor.hidden = true;

    const smallTitleBar = document.createElement('div');
    smallTitleBar.id = 'editor_small_titleBar';

    const smallTitleText = document.createElement('div');
    smallTitleText.className = 'editor_title_text';
    smallTitleText.textContent = '文本编辑器';
    
    const smallControls = document.createElement('div');
    smallControls.className = 'editor_window_controls';
    
    // 小窗口控制按钮
    const smallMinBtn = createControlButton('editor_minimizeBtn_small', 'editor_small_zoom()', 
        `M914 86.9H641c-28.5 0-42.8 34.4-22.7 54.6l110.3 110.6-138.4 138c-14.3 14.2-14.3 37.3-0.1 51.6 14.2 14.3 37.3 14.3 51.6 0.1l138.4-138 110.3 110.6c20.1 20.2 54.6 6 54.7-22.5l0.8-273c0.2-17.6-14.2-32-31.9-32zM450.2 531.9l-138.4 138-110.3-110.6c-20.1-20.2-54.6-6-54.7 22.5l-0.8 273c-0.1 17.7 14.3 32.1 32 32.1h273c28.5 0 42.8-34.4 22.7-54.6L363.3 721.6l138.4-138c14.3-14.2 14.3-37.3 0.1-51.6s-37.3-14.3-51.6-0.1z`);
    
    const smallMaxBtn = createControlButton('editor_maximizeBtn_small', 'editor_small_maximize()', 
        `M972.8 0H665.6a51.2 51.2 0 0 0 0 102.4h183.6032L629.41184 322.19136a51.2 51.2 0 0 0 72.3968 72.3968L921.6 174.7968V358.4a51.2 51.2 0 0 0 102.4 0V51.2a51.2 51.2 0 0 0-51.2-51.2zM409.6 51.2a51.2 51.2 0 0 0-51.2-51.2H51.2A51.44576 51.44576 0 0 0 0 51.2v307.2a51.2 51.2 0 0 0 102.4 0V174.7968l219.79136 219.81184a51.2 51.2 0 0 0 72.3968-72.3968L174.7968 102.4H358.4a51.2 51.2 0 0 0 51.2-51.2zM1024 665.6a51.2 51.2 0 0 0-102.4 0v183.6032L701.80864 629.41184a51.2 51.2 0 0 0-72.3968 72.3968L849.2032 921.6H665.6a51.2 51.2 0 0 0 0 102.4h307.2a51.44576 51.44576 0 0 0 51.2-51.2zM358.4 921.6H174.7968l219.81184-219.79136a51.2 51.2 0 0 0-72.3968-72.3968L102.4 849.2032V665.6a51.2 51.2 0 0 0-102.4 0v307.2a51.2 51.2 0 0 0 51.2 51.2h307.2a51.2 51.2 0 0 0 0-102.4z`);
    
    const smallCloseBtn = createControlButton('editor_closeBtn_small', 'editor_close()', 
        `M940.8 83.2c25.6 25.6 25.6 64 0 83.2L595.2 512l345.6 345.6c25.6 25.6 25.6 64 0 83.2-25.6 25.6-64 25.6-83.2 0L512 595.2l-345.6 345.6c-25.6 25.6-64 25.6-83.2 0-25.6-25.6-25.6-64 0-83.2L428.8 512 83.2 166.4c-25.6-25.6-25.6-64 0-83.2s64-25.6 83.2 0L512 428.8l345.6-345.6C876.8 57.6 921.6 57.6 940.8 83.2z`);
    
    smallControls.appendChild(smallMinBtn);
    smallControls.appendChild(smallMaxBtn);
    smallControls.appendChild(smallCloseBtn);
    smallTitleBar.appendChild(smallTitleText);
    smallTitleBar.appendChild(smallControls);
    smallEditor.appendChild(smallTitleBar);

    // 添加到body
    document.body.appendChild(editorContainer);
    document.body.appendChild(smallEditor);
}
// 辅助函数：创建控制按钮
function createControlButton(id, onclick, pathData) {
    const btn = document.createElement('div');
    btn.className = 'editor_window_control';
    btn.id = id;
    btn.setAttribute('onclick', onclick);
    
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute('class', 'icon');
    svg.setAttribute('viewBox', '0 0 1024 1024');
    svg.setAttribute('width', '17');
    svg.setAttribute('height', '17');
    
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute('d', pathData);
    path.setAttribute('fill', 'white');
    
    svg.appendChild(path);
    btn.appendChild(svg);
    return btn;
}

// 初始化编辑器
document.addEventListener('DOMContentLoaded', createEditorElements);
//createEditorElements();
    
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 计算路径的哈希值
function getPathHash(path) {
    // 简单哈希函数，保持与Python版本类似的MD5风格（实际使用更简单的字符串哈希）
    let hash = 0;
    for (let i = 0; i < path.length; i++) {
        const char = path.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString();
}

// 唯一数据源：路径 -> 标签页数据
const tabs = {}; // 格式: { "/path/file.txt": { div, contentDiv, closed: false } }
let activePath = null; // 当前激活的标签路径

function editor_start(file_dir, file_name,theme_set='vs',wordWrap_set='on') {
    const fullPath = `${file_dir}/${file_name}`;
    const pathHash = getPathHash(fullPath);
    
    // 如果标签已存在且未关闭，直接激活
    if (tabs[pathHash] && !tabs[pathHash].closed) {
        set_active_tab(pathHash);
        return;
    }

    // 创建新标签页
    const divA = document.getElementById('editor_name_bar');
    const newDiv = document.createElement('div');
    newDiv.className = 'editor_name_bar_one';
    newDiv.id = pathHash + '_tab'; // 添加ID：hash_tab
    
    // 文件名
    const fileNameSpan = document.createElement('span');
    fileNameSpan.textContent = file_name;
    newDiv.appendChild(fileNameSpan);

    // 感叹号（常隐）
    const exclamationDiv = document.createElement('div');
    exclamationDiv.className = 'editor_tab_exclamation';
    exclamationDiv.textContent = '!';
    newDiv.appendChild(exclamationDiv);

    // 叉号（关闭按钮）
    const closeDiv = document.createElement('div');
    closeDiv.className = 'tab-close';
    closeDiv.textContent = '×';
    closeDiv.addEventListener('click', (e) => {
        e.stopPropagation();
        close_tab(pathHash);
    });
    newDiv.appendChild(closeDiv);

    divA.appendChild(newDiv);

    // 创建内容区域
    const bottomContent = document.getElementById('editor_bottom_content');
    const contentDiv = document.createElement('div');
    contentDiv.className = 'editor-content';
    contentDiv.style.width = '100%';
    contentDiv.style.height = '100%';
    contentDiv.style.display = 'none';
    contentDiv.id = pathHash + '_obj'; // 添加ID：hash_obj
    //contentDiv.textContent = `Content for ${file_name}`;
    bottomContent.appendChild(contentDiv);

    // 存储标签数据（使用路径哈希作为键，同时保存原始路径）
    tabs[pathHash] = {
        path: fullPath,
        div: newDiv,
        contentDiv: contentDiv,
        closed: false,
        originalContent: null, // 保存原始文件内容
        isModified: false     // 标记是否被修改
    };

    // 点击标签切换
    newDiv.addEventListener('click', () => set_active_tab(pathHash));
    
    // 激活新标签
    set_active_tab(pathHash);
    initMonacoEditor(pathHash,theme_set,wordWrap_set);
}

// 初始化Monaco编辑器的函数
function initMonacoEditor(pathHash,theme_set,wordWrap_set) {
    const tabData = tabs[pathHash];
    if (!tabData || tabData.editor) return;
    
    // 确保内容区域可见（Monaco需要可见的容器）
    const wasHidden = tabData.contentDiv.style.display === 'none';
    if (wasHidden) {
        tabData.contentDiv.style.display = 'block';
    }
    
    // 根据文件扩展名设置语言模式
    const extension = tabData.path.split('.').pop().toLowerCase();
    const languageMap = {
          'abap': 'abap',
          'cls': 'apex',
          'azcli': 'azcli',
          'bat': 'bat',
          'bicep': 'bicep',
          'mligo': 'cameligo',
          'clj': 'clojure',
          'coffee': 'coffee',
          'cpp': 'cpp',
          'cs': 'csharp',
          'csp': 'csp',
          'css': 'css',
          'cyp': 'cypher',
          'dart': 'dart',
          'dockerfile': 'dockerfile',
          'ecl': 'ecl',
          'ex': 'elixir',
          'js': 'javascript',
          'jsx': 'javascriptreact',
          'ts': 'typescript',
          'tsx': 'typescriptreact',
          'flow9': 'javascript',
          'freemarker2': 'freemarker',
          'fsharp': 'fsharp',
          'go': 'go',
          'graphql': 'graphql',
          'handlebars': 'handlebars',
          'hcl': 'hcl',
          'html': 'html',
          'ini': 'ini',
          'java': 'java',
          'julia': 'julia',
          'kt': 'kotlin',
          'less': 'less',
          'lexon': 'lexon',
          'liquid': 'liquid',
          'lua': 'lua',
          'm3': 'm3',
          'md': 'markdown',
          'mdx': 'mdx',
          'mips': 'mips',
          'msdax': 'msdax',
          'mysql': 'mysql',
          'm': 'objective-c',
          'pas': 'pascal',
          'pascaligo': 'pascaligo',
          'pl': 'perl',
          'pgsql': 'pgsql',
          'php': 'php',
          'pla': 'pla',
          'postiats': 'postiats',
          'pq': 'powerquery',
          'ps1': 'powershell',
          'proto': 'protobuf',
          'pug': 'pug',
          'py': 'python',
          'qs': 'qsharp',
          'r': 'r',
          'razor': 'razor',
          'redis': 'redis',
          'redshift': 'redshift',
          'rst': 'restructuredtext',
          'rb': 'ruby',
          'rs': 'rust',
          'sb': 'sb',
          'scala': 'scala',
          'scm': 'scheme',
          'scss': 'scss',
          'sh': 'shell',
          'sol': 'solidity',
          'sophia': 'sophia',
          'rq': 'sparql',
          'sql': 'sql',
          'st': 'st',
          'swift': 'swift',
          'sv': 'systemverilog',
          'tcl': 'tcl',
          'twig': 'twig',
          'vb': 'vb',
          'wgsl': 'wgsl',
          'xml': 'xml',
          'yaml': 'yaml',
          'yml': 'yaml'
    };
    
    const language = languageMap[extension] || 'plaintext';
    
    // 1. 先显示标签页
    set_active_tab(pathHash);
    
    // 2. 从后端获取文件内容
    fetch('plug/monaco_editor/DIY/editor_load.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: tabData.path })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorData => {
                // 抛出错误以便在 catch 中捕获
                throw new Error(errorData.error);
            });
        }
        return response.json();
    })
    .then(data => {
        if (!data || data.error) throw new Error(data?.error || '无效的响应');
        
        // 加载Monaco编辑器
        require.config({ paths: { vs: '/plug/monaco_editor/min/vs' }});   //使用绝对目录
        require(['vs/editor/editor.main'], () => {
            // 创建编辑器实例
            tabData.editor = monaco.editor.create(tabData.contentDiv, {
                value: data.content || '// 文件为空\n', // 使用从后端获取的内容
                language: language,
                theme: theme_set,/*'vs-dark'*/ /*似乎需要删除cookie生效*/
                wordWrap: wordWrap_set,
                automaticLayout: true,
                minimap: { enabled: true },
                readOnly: data.readOnly || false // 如果后端指定只读
            });
            
            // 添加保存快捷键 (Ctrl+S)
            tabData.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
                save_current_file();
            });
            
            // 监听内容变化、、可以在这里标记文件为已修改
            tabData.editor.onDidChangeModelContent(() => {
                const currentContent = tabData.editor.getValue();
                const isNowModified = currentContent !== tabData.originalContent;
                
                // 更新感叹号显示
                const exclamation = tabData.div.querySelector('.editor_tab_exclamation');
                if (exclamation) {
                    exclamation.style.visibility = isNowModified ? 'visible' : 'hidden';
                }
                
                // 只检测第一次的修改状态变化
                if (!tabData.wasEverModified && isNowModified) {
                    console.log(`文件 ${tabData.path} 已被首次修改`);
                    tabData.wasEverModified = true; // 标记为已经历过修改
                    // 可选：触发回调或事件，通知其他组件
                }
                
                // 更新当前修改状态
                tabData.isModified = isNowModified;
            });
        });
    })
    .catch(error => {
        console.error("加载文件内容出错:", error);
        tabData.contentDiv.textContent = `加载文件失败: ${error.message}`;
        tabData.contentDiv.style.color = 'red';
    });
}

//
// 保存当前活动标签页的内容到原文件
function save_current_file() {
    if (!activePathHash || !tabs[activePathHash]) {
        showAndFadeOut('error', 2000, 3,"没有活动的标签页！");return false;
        //alert("没有活动的标签页！");return;
        
    }

    const tabData = tabs[activePathHash];
    if (!tabData.editor) {
        //alert("当前标签页没有编辑器实例！");return;
        showAndFadeOut('error', 2000, 3,"当前标签页没有编辑器实例！");return false;
        
    }

    // 获取编辑器内容
    const content = tabData.editor.getValue();
    const filePath = tabData.path; // 原文件路径（如 "./min/vs/loader.js"）

    // 调用后端 API 保存（推荐）**
    fetch('plug/monaco_editor/DIY/editor_save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            path: filePath,
            content: content
        })
    })
    .then(response => {
        if (response.ok) {
            // 保存成功，恢复未修改状态
            tabData.isModified = false;
            

            // 隐藏感叹号
            const exclamation = tabData.div.querySelector('.editor_tab_exclamation');
            if (exclamation) {
                exclamation.style.visibility = 'hidden';
            }
            //alert("保存成功！");
            showAndFadeOut('success', 2000, 3,'保存成功');
        } else {
            //alert("保存失败！");
            showAndFadeOut('error', 2000, 3,"保存失败");return false;
        }
    })
    .catch(err => {
        console.error("保存出错:", err);
        //alert("保存出错！");
        showAndFadeOut('error', 2000, 3,"保存出错");return false;
    });
}


//刷新当前活动标签页的文件内容（丢弃未保存的修改）
function refresh_current_file() {
    if (!activePathHash || !tabs[activePathHash]) {
        showAndFadeOut('error', 2000, 3, "没有活动的标签页！");
        return false;
    }

    const tabData = tabs[activePathHash];
    if (!tabData.editor) {
        showAndFadeOut('error', 2000, 3, "当前标签页没有编辑器实例！");
        return false;
    }

    // 显示加载状态（可选）
    const originalContent = tabData.editor.getValue();
    tabData.editor.setValue("// 正在刷新文件内容...\n");

    // 重新请求文件内容
    fetch('plug/monaco_editor/DIY/editor_load.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: tabData.path })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('刷新失败，服务器返回错误');
        }
        return response.json();
    })
    .then(data => {
        if (!data || data.error) {
            throw new Error(data?.error || '无效的响应');
        }

        // 更新编辑器内容
        tabData.editor.setValue(data.content || '// 文件为空\n');
        tabData.originalContent = data.content; // 重置原始内容基准
        
        // 隐藏感叹号（因为内容与服务器同步了）
        const exclamation = tabData.div.querySelector('.editor_tab_exclamation');
        if (exclamation) {
            exclamation.style.visibility = 'hidden';
        }

        // 标记为未修改状态
        tabData.isModified = false;
        tabData.wasEverModified = false;

        showAndFadeOut('success', 2000, 3, '文件已刷新');
    })
    .catch(error => {
        console.error("刷新文件内容出错:", error);
        // 恢复原始内容（因为刷新失败）
        tabData.editor.setValue(originalContent);
        showAndFadeOut('error', 2000, 3, `刷新失败: ${error.message}`);
    });
}

function close_tab(pathHash) {
    if (!tabs[pathHash] || tabs[pathHash].closed) return;

    const tabData = tabs[pathHash];
    
    // 1. 销毁 Monaco 编辑器实例（如果存在）
    if (tabData.editor) {
        tabData.editor.dispose();
        tabData.editor = null;
    }
    
    // 2. 从 DOM 中移除元素
    if (tabData.div && tabData.div.parentNode) {
        tabData.div.parentNode.removeChild(tabData.div);
    }
    if (tabData.contentDiv && tabData.contentDiv.parentNode) {
        tabData.contentDiv.parentNode.removeChild(tabData.contentDiv);
    }
    
    // 3. 从 tabs 对象中删除
    delete tabs[pathHash];
    
    // 如果关闭的是当前激活标签，切换到下一个可用标签
    if (pathHash === activePathHash) {
        const allTabHashes = Object.keys(tabs);
        const nextTabHash = allTabHashes.find(h => tabs[h] && !tabs[h].closed);
        
        if (nextTabHash) {
            set_active_tab(nextTabHash);
        } else {
            activePathHash = null;
            document.getElementById('editor_contenter').style.display = 'none';
        }
    }
}

function set_active_tab(pathHash) {
    if (!tabs[pathHash] || tabs[pathHash].closed) return;

    // 隐藏所有标签页
    Object.values(tabs).forEach(tab => {
        if (!tab.closed) {
            tab.div.classList.remove('active');
            tab.contentDiv.style.display = 'none';
        }
    });

    // 激活目标标签页
    const targetTab = tabs[pathHash];
    targetTab.div.classList.add('active');
    targetTab.contentDiv.style.display = 'block';
    activePathHash = pathHash;
    document.getElementById('editor_contenter').style.display = 'flex';
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    

// 存储编辑器上次的位置和大小（初始值为默认值）
let lastEditorStyle = {width: '600px',height: '400px',left: '50px',top: '50px'};
let editor_isnormal =true;  //非最大最小化

document.addEventListener('DOMContentLoaded', function() {
    // 使窗口可拖动
    const editor = document.getElementById('editor_contenter');
    const editor_titleBar = document.getElementById('editor_titleBar');
    
    
    let editor_isDragging = false;
    let editor_isResizing = false;
 
    let editor_resizeDirection = '';
    let editor_startX, editor_startY, editor_startWidth, editor_startHeight, editor_startLeft, editor_startTop;
    
    
    // 拖动标题栏移动窗口
    editor_titleBar.addEventListener('mousedown', (e) => {
        // 如果是双击，直接返回
    
        
        // 确保没有点击到控制按钮
        if (e.target.closest('.editor_window_control')) return;
    
        // 记录初始位置
        const startX = e.clientX;
        const startY = e.clientY;
        const rect = editor.getBoundingClientRect();
        const offsetX = startX - rect.left;
        const offsetY = startY - rect.top;
    
        // 标记是否已开始拖动（避免误触发）
        let hasDragged = false;
    
        function handleMouseMove(e) {
            // 检查是否移动了足够距离（例如 5px）
            if (!hasDragged && (Math.abs(e.clientX - startX) > 5 || Math.abs(e.clientY - startY) > 5)) {
                hasDragged = true;
                editor_isDragging = true;
            }
    
            // 如果已开始拖动，则移动窗口
            if (editor_isDragging) {
                editor.style.left = (e.clientX - offsetX) + 'px';
                editor.style.top = (e.clientY - offsetY) + 'px';
            }
        }
    
        function handleMouseUp() {
            // 如果没有拖动，可能是单击（可以在这里处理单击逻辑）
            if (!hasDragged) {
                console.log('单击事件');
            }
    
            // 清理事件监听和状态
            editor_isDragging = false;
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        }
    
        // 监听 mousemove 和 mouseup
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    });
    
    // 调整大小的功能
    const resizeHandles = {editor_resizeTop: 'top',editor_resizeRight: 'right',editor_resizeBottom: 'bottom',editor_resizeLeft: 'left',editor_resizeTopLeft: 'top-left',editor_resizeTopRight: 'top-right',editor_resizeBottomLeft: 'bottom-left',editor_resizeBottomRight: 'bottom-right'};
    Object.entries(resizeHandles).forEach(([id, direction]) => {
        const handle = document.getElementById(id);
        
        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            editor_isResizing = true;
            editor_resizeDirection = direction;
            
            const rect = editor.getBoundingClientRect();
            editor_startX = e.clientX;
            editor_startY = e.clientY;
            editor_startWidth = rect.width;
            editor_startHeight = rect.height;
            editor_startLeft = rect.left;
            editor_startTop = rect.top;
            
            function resizeWindow(e) {
                const dx = e.clientX - editor_startX;
                const dy = e.clientY - editor_startY;
                
                switch (editor_resizeDirection) {
                    case 'top':
                        editor.style.height = (editor_startHeight - dy) + 'px';
                        editor.style.top = (editor_startTop + dy) + 'px';
                        break;
                    case 'right':
                        editor.style.width = (editor_startWidth + dx) + 'px';
                        break;
                    case 'bottom':
                        editor.style.height = (editor_startHeight + dy) + 'px';
                        break;
                    case 'left':
                        editor.style.width = (editor_startWidth - dx) + 'px';
                        editor.style.left = (editor_startLeft + dx) + 'px';
                        break;
                    case 'top-left':
                        editor.style.width = (editor_startWidth - dx) + 'px';
                        editor.style.height = (editor_startHeight - dy) + 'px';
                        editor.style.left = (editor_startLeft + dx) + 'px';
                        editor.style.top = (editor_startTop + dy) + 'px';
                        break;
                    case 'top-right':
                        editor.style.width = (editor_startWidth + dx) + 'px';
                        editor.style.height = (editor_startHeight - dy) + 'px';
                        editor.style.top = (editor_startTop + dy) + 'px';
                        break;
                    case 'bottom-left':
                        editor.style.width = (editor_startWidth - dx) + 'px';
                        editor.style.height = (editor_startHeight + dy) + 'px';
                        editor.style.left = (editor_startLeft + dx) + 'px';
                        break;
                    case 'bottom-right':
                        editor.style.width = (editor_startWidth + dx) + 'px';
                        editor.style.height = (editor_startHeight + dy) + 'px';
                        break;
                }
            }
            
            function endResize() {
                editor_isResizing = false;
                document.removeEventListener('mousemove', resizeWindow);
                document.removeEventListener('mouseup', endResize);
            }
            
            document.addEventListener('mousemove', resizeWindow);
            document.addEventListener('mouseup', endResize);
        });
    });
    
    

    
    // 拖动结束时更新 lastEditorStyle
    editor_titleBar.addEventListener('mouseup', () => {
        if (!editor_isDragging) return;
        if (editor_isnormal) {
            lastEditorStyle = {
                width: editor.style.width,
                height: editor.style.height,
                left: editor.style.left,
                top: editor.style.top
            };
        }
        else{
            editor_isnormal=true;
            //const editor = document.getElementById('editor_contenter');
            editor.style.width = lastEditorStyle.width;
            editor.style.height = lastEditorStyle.height;
            lastEditorStyle = {
                width: editor.style.width,
                height: editor.style.height,
                left: editor.style.left,
                top: editor.style.top
            };
        }
    });
    
    // 调整大小结束时更新 lastEditorStyle
    Object.entries(resizeHandles).forEach(([id, direction]) => {
        const handle = document.getElementById(id);
        handle.addEventListener('mouseup', () => {
            if (!editor_isResizing) return;
            lastEditorStyle = {
                width: editor.style.width,
                height: editor.style.height,
                left: editor.style.left,
                top: editor.style.top
            };
        });
    });
    
    
    //标题栏双击
    editor_titleBar.addEventListener('dblclick', (e) => {
        console.log('双击');
        // 确保没有点击到控制按钮
        if (e.target.closest('.editor_window_control')) return;
        
        // 阻止默认行为（避免可能的文本选中或拖动）
        e.preventDefault();
        
        // 切换最大化状态
        editor_maximize();
    
    });
});

// 最小化按钮点击
function editor_minimize(){
    document.getElementById('editor_contenter').style.display = 'none';
    document.getElementById('editor_contenter_small').style.display = 'block';
    // 恢复浏览器的滚动条
    document.documentElement.style.overflow = 'auto'; // 或 'scroll'
}
// 最大化按钮点击
function editor_small_zoom(){
    document.getElementById('editor_contenter').style.display = 'flex';
    document.getElementById('editor_contenter_small').style.display = 'none';
}
// 最大化按钮点击
function editor_maximize(){
    console.log('最大化');
    const editor = document.getElementById('editor_contenter');
    editor.classList.add('resizing');    //加transition，然后0.3s后去掉，要不drag时也应用会卡
    if (editor_isnormal) {
        editor_isnormal=false;
        editor.style.width = '100vw';
        editor.style.height = '100vh';
        editor.style.left = '0';
        editor.style.top = '0';
        // 隐藏整个浏览器的滚动条
        document.documentElement.style.overflow = 'hidden'; // 适用于 <html>
    } else {
        editor_isnormal=true;// 恢复上次的位置和大小
        if (
            lastEditorStyle.width === '100vw' || 
            lastEditorStyle.height === '100vh' ||
            lastEditorStyle.width === '' || 
            lastEditorStyle.height === ''
        ) {
            // 如果 lastEditorStyle 无效或也是全屏，恢复默认值
            editor.style.width = '600px';
            editor.style.height = '400px';
            editor.style.left = '50px';
            editor.style.top = '50px';
        } else {
            // 否则恢复 lastEditorStyle
            editor.style.width = lastEditorStyle.width;
            editor.style.height = lastEditorStyle.height;
            editor.style.left = lastEditorStyle.left;
            editor.style.top = lastEditorStyle.top;
        }
        // 恢复浏览器的滚动条
        document.documentElement.style.overflow = 'auto'; // 或 'scroll'
    }
    setTimeout(() => { editor.classList.remove('resizing'); }, 100); 
    
    // 绑定按钮事件
    document.getElementById('editor_minimize_btn')?.addEventListener('click', editor_minimize);
    document.getElementById('editor_maximize_btn')?.addEventListener('click', editor_maximize);
    document.getElementById('editor_close_btn')?.addEventListener('click', editor_close);
    document.getElementById('editor_small_zoom_btn')?.addEventListener('click', editor_small_zoom);
    document.getElementById('editor_small_maximize_btn')?.addEventListener('click', editor_small_maximize);
}
// 最大化按钮点击
function editor_small_maximize(){
    document.getElementById('editor_contenter').style.display = 'flex';
    document.getElementById('editor_contenter_small').style.display = 'none';
    editor_isnormal=false;
    const editor = document.getElementById('editor_contenter');
    editor.style.width = '100vw';
    editor.style.height = '100vh';
    editor.style.left = '0';
    editor.style.top = '0';
    // 隐藏整个浏览器的滚动条
    document.documentElement.style.overflow = 'hidden'; // 适用于 <html>
}



// 关闭所有标签页并隐藏编辑器
function editor_close() {
    // 1. 关闭所有标签页
    console.log('关闭所有标签页');
    Object.keys(tabs).forEach(pathHash => {
        if (tabs[pathHash] && !tabs[pathHash].closed) {
            close_tab(pathHash); // 调用现有的 close_tab 函数
        }
    });

    // 2. 隐藏编辑器窗口（包括小窗口）
    document.getElementById('editor_contenter').style.display = 'none';
    document.getElementById('editor_contenter_small').style.display = 'none';

    // 3. 恢复浏览器滚动条
    document.documentElement.style.overflow = 'auto';

    // 4. 重置激活状态
    activePathHash = null;
}













