<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["item_id"]) && isset($input["delete_type"]) && isset($input["userid"])  ){
        //链接数据库
        include 'database_connect.php';
        //http_response_code(500);echo json_encode(['error' => '执行中-内部-Gene']);die();
        $delete_type           =$input["delete_type"];  
        $item_id               =$input["item_id"];  
        $userid                 =$input["userid"];  
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
        
        if ($delete_type=='delete_one'){
            //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
            $updateSql = "UPDATE 执行2_任务列表 SET 更新时间 = '$current_time',系统备注1='删除'  WHERE 唯一识别码=?";  
            $updateStmt = mysqli_prepare($conn, $updateSql);  
            if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}  
          
            mysqli_stmt_bind_param($updateStmt, 's',$item_id); 
                
            if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}
        }
        else if ($delete_type=='delete_all'){
            //echo json_encode(['result' => '执行中-内部-Gene:'.$input_value]);die();
            $updateSql = "UPDATE 执行2_任务列表 SET 更新时间 = '$current_time',系统备注1='删除'  WHERE 所属项目编号=? and 拥有者=?";  
            //http_response_code(500);  echo json_encode(['error' => '无法完成参数准备'.$updateSql.$item_id.$userid]);die();
            $updateStmt = mysqli_prepare($conn, $updateSql);  
            if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备'.$updateSql.$item_id.$userid]);die();}  
          
            mysqli_stmt_bind_param($updateStmt, 'ss',$item_id,$userid); 
                
            if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}            
        }
        mysqli_stmt_close($updateStmt);  
        mysqli_close($conn);       
          
  
          
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
        ]);
        


        
        
        die();
    }

?>























