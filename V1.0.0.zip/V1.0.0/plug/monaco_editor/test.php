<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>可拖动文本编辑器</title>
    
    <!--<script src="./plug/monaco_editor/min/vs/loader.js"></script><!注意更改路径-->
    <script src="min/vs/loader.js"></script><!--注意更改路径-->
    <link rel="stylesheet" href="DIY/editor.css">
    
</head>    
    
<body>
    <div><button onclick="editor_start('plug/monaco_editor/DIY','testA.txt')">A</button></div>
    <div><button onclick="editor_start('plug/monaco_editor','readme.txt')">readme.txt</button></div>

    <script src="DIY/editor.js"></script>
</body>
</html>

