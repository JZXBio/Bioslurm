<?php
    header('Content-Type: application/json');
    
    // 最大允许文件大小（1MB）
    define('MAX_FILE_SIZE', 10*1024 * 1024); 

    
    try {
        
        // 获取并验证输入
        $input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            http_response_code(400);echo json_encode(['error' => '无效的json']);die();
        }
        //$baseDir = dirname(__DIR__, 3); //向上回溯三级目录  DIY————monaco_editor————plug————网站根目录
        //$path = $baseDir.'/'.$input['path'] ?? '';
        $path = $input['path'] ?? '';
        $path=$_SERVER['DOCUMENT_ROOT'].'/'.ltrim($path, '/');
        if (empty($path)) {
           http_response_code(400);echo json_encode(['error' => '文件路径不能为空']);die();
        }
   
        /* 安全验证（重要！）
        $allowedDirs = ['/var/www/my_site/editable_files/']; // 明确允许的目录
        $validPath = false;
        
        // 检查路径是否在允许的目录内
        foreach ($allowedDirs as $dir) {
            $fullDir = realpath($dir);
            $fullPath = realpath($path);
            
            if ($fullPath && $fullDir && strpos($fullPath, $fullDir) === 0) {
                $validPath = true;
                break;
            }
        }
    
        if (!$validPath) {
            throw new Exception('无权限访问该文件');
        }
        */
        
        // 检查文件是否存在和大小
        if (!file_exists($path)) {
            //throw new Exception($path.'文件不存在'.$currentDir);
            http_response_code(400);echo json_encode(['error' => '文件不存在：'.$path]);die();
        }
    
        $fileSize = filesize($path);
        if ($fileSize === false) {
            http_response_code(400);echo json_encode(['error' => '无法获得文件大小']);die();
        }
    
        if ($fileSize > MAX_FILE_SIZE) {
            throw new Exception('文件过大（最大允许 ' . (MAX_FILE_SIZE / 1024) . 'KB）');
        }
    
        // 读取文件内容
        $content = file_get_contents($path);
        if ($content === false) {
            throw new Exception('无法读取文件内容');
        }
    
        // ==== 新增：检测文件是否是二进制或非文本 ====
        if (!empty($content)) {
            // 检测是否包含 NULL 字节（二进制文件常见特征）
            if (strpos($content, "\x00") !== false) {
                http_response_code(400);echo json_encode(['error' => '无法编辑二进制文件']);die();
            } else {
                // 进一步检测：如果大部分字符是非可打印 ASCII（如图片、压缩包）
                $nonPrintable = preg_match('/[^\x20-\x7E\x0A\x0D]/', $content);
                if ($nonPrintable && strlen($content) > 0) {
                    $ratio = $nonPrintable / strlen($content);
                    if ($ratio > 0.3) { // 如果超过 30% 是非可打印字符，判定为二进制
                        http_response_code(400);echo json_encode(['error' => '无法编辑二进制文件']);die();
                    }
                }
            }
        }
        // 成功响应
        echo json_encode([
            'success' => true,
            'content' => $content,
            'fileSize' => $fileSize,
            'readOnly' => !is_writable($path),
            'maxSize' => MAX_FILE_SIZE
        ]);
    
    } catch (Exception $e) {
        // 错误响应
        http_response_code(400);
        echo json_encode([
            'error' => $e->getMessage()
        ]);
    }
?>