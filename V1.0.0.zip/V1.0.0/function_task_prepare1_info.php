<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    
    //echo json_encode(['result' =>$input]);;die();echo json_encode(['result' => '执行中-内部-Gene']);die();
    
    
    if (isset($input["new_item_id0"])  && 
        isset($input["new_item_id1"]) &&
        isset($input["project_id"])  && 
        isset($input["project_dir"])  && 
        isset($input["task_module_id"])  && 
        isset($input["task_module_name"])  && 
        isset($input["task_start_template_sum"])  && 
        isset($input["task_start_parameter_sum"]) && 
        isset($input["dict_variablename_value"]) &&         
        isset($input["good_node_list"])  && 
        isset($input["real_node_replyARR_dict"]) &&
        isset($input["dict_node_templaterevise"])  && 
        isset($input["dict_node_parameterrevise"])) 
    {
       
        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $new_item_id0               =$input["new_item_id0"];  
        $new_item_id1               =$input["new_item_id1"];   
        $userid                     =$input["userid"];   
        $project_id                                    =$input["project_id"];  
        $project_dir                                   =$input["project_dir"];  
        $task_module_id                             =$input["task_module_id"];  
        $task_module_name                           =$input["task_module_name"];  
        if (isset($input["task_start_thread_sum"])){  $task_start_thread_sum                             =$input["task_start_thread_sum"];  }
        if($task_start_thread_sum){$task_start_thread_sum_value=$task_start_thread_sum;  }
        else{$task_start_thread_sum_value='1';}
        
        $task_start_template_sum                    =$input["task_start_template_sum"];   
        $task_start_parameter_sum                   =$input["task_start_parameter_sum"];
        $dict_variablename_value                    =$input["dict_variablename_value"];     $dict_variablename_value_str=json_encode($dict_variablename_value,JSON_UNESCAPED_UNICODE);
        $good_node_list                             =$input["good_node_list"];              $good_node_list_str=json_encode($good_node_list);
        $real_node_replyARR_dict                    =$input["real_node_replyARR_dict"];     $real_node_replyARR_dict_str=json_encode($real_node_replyARR_dict);
        $dict_node_templaterevise                   =$input["dict_node_templaterevise"];    $dict_node_templaterevise_str=json_encode($dict_node_templaterevise);
        $dict_node_parameterrevise                  =$input["dict_node_parameterrevise"];   $dict_node_parameterrevise_str=json_encode($dict_node_parameterrevise); 
        

        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
        //http_response_code(500);  echo json_encode(['error' => '无法完成参数准111111111111111备'.$task_module_name]);die();
        
        $updateSql = "INSERT INTO 执行2_任务列表 (创建时间,识别码,唯一识别码,创建者,拥有者,更新时间,共享权限,状态,所属项目编号,所属项目目录,线程分配,使用模块,模块名称,模板修订,参数修订,变量设置,作业运行列表,作业依赖,作业模板修订,作业参数修订) VALUES ('{$current_time}',?,?,?,?,'{$current_time}','个人','prepare1',?,?,?,?,?,?,?,?,?,?,?,?)";  
        $updateStmt = mysqli_prepare($conn, $updateSql);

        if (!$updateStmt) {  http_response_code(500); echo json_encode(['error' => 'SQL 准备失败: ' . mysqli_error($conn)]);;die();}  
      
        mysqli_stmt_bind_param($updateStmt, 'ssssssssssssssss',$new_item_id0,$new_item_id1,$userid,$userid,$project_id,$project_dir,$task_start_thread_sum_value,$task_module_id,$task_module_name,$task_start_template_sum,$task_start_parameter_sum,$dict_variablename_value_str,$good_node_list_str,$real_node_replyARR_dict_str,$dict_node_templaterevise_str,$dict_node_parameterrevise_str); 
            
        if (!mysqli_stmt_execute($updateStmt)) {  http_response_code(500);  echo json_encode(['error' => '无法完成数据库更新']);die();}
            
        mysqli_stmt_close($updateStmt);  
        mysqli_close($conn);       
        
  
          
    
        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
        ]);
        


        
        
        die();
    }

?>























