<?php    
    session_start(); // 开始会话
    //var_dump($_SESSION['user_name_id']);die();
    if (isset($_SESSION["user_uuid"])  &&  isset($_SESSION["user_email"]) &&  isset($_SESSION["user_name"])  &&  isset($_SESSION["user_name_id"])) {
        $navi_user_state= "
            <span style='font-size:xx-small;margin-left:50px'>欢迎, </span>{$_SESSION['user_name']}<span style='font-size:xx-small'> [{$_SESSION['user_email']}] </span> 
            <div style='display:inline-block'>
                <form  action='index.php' method='post'>
                    <input type='hidden'  name='action' ID='action' value='logout'></input><button id='logout'>[退出]</button>
                </form>    
            </div> ";
        
    }
    else{
        header("Location: index.php");  
        exit; // 确保重定向后停止脚本执行  
    }    
   
    $user_name_id=$_SESSION['user_name_id'];
    $base_path = "/www/wwwroot/bioslurm/user/{$user_name_id}";  
    if (is_dir($base_path)==false)  {  echo "用户未初始化，用户文件夹不存在。";  die();} 
    
    $searchword='';
    if (isset($_GET["searchword"]) && $_GET["searchword"] !== ''){
        //if(strpos($_GET["searchword"], "script_") === 0){
            $searchword=$_GET["searchword"];//var_dump($_GET["searchword"] );
            //echo "searchword".$searchword; 
        //}
    }    
    else{$searchword='';}

    $current_time = date('Y-m-d H:i:s');
    
    
        
    //链接数据库，获取用户的设置
    include 'database_connect.php'; 
    $sql = "SELECT * FROM 用户信息 WHERE 用户名自动生成 = ?";
    $params =[ ['type' => 's', 'value' => $user_name_id]]; // 's' 表示字符串类型
    $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
    $select_theme_TXT=$rows[0]['设置_文本编辑器'];
    $select_wrap_TXT=$rows[0]['设置_文本编辑器_自动换行'];
?>


<!DOCTYPE  html>
<html  lang="en">
<head>
    <meta  charset="UTF-8">
    <meta  name="viewport"  content="width=device-width,  initial-scale=1.0">
    <title>BioSlurm生信服务器</title>
    <meta name="keywords" content="BioSlurm生信服务器">
    <meta name="description" content="BioSlurm生信服务器" >
    <link rel="icon" href="000_image/favicon.png" type="image/png">     
    
    
    <link rel="stylesheet" href="plug/monaco_editor/DIY/editor.css">
    
    <style>

        * {box-sizing: border-box;margin:0;padding:0;}
        body {font-family: sans-serif;min-width:300px;background-color: rgba(0,0,0,0.06);}/*background-color: rgba(0,0,0,0.03);*/
        div {user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; }
        .flex_div{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;}
        #top_navigator {position:fixed;top:0;width: 100%;background-color:#005580;padding:4px;margin:0 0 auto 0;height:30px;color:white;z-index:111111}
        #top_navigator a{color:white; text-decoration:none; margin:0 10px;font-size:17px;}
        #top_navigator a:hover{color:#ffff99}
        #top_navigator_title_name{font-weight:500;text-shadow: 0 0 1px black, 1px 1px 5px black;}
        #top_navigator_current_time{font-size:xx-small}
        #logout{background: none;border:none;padding: 0;font: inherit;cursor: pointer; color: rgb(200,200,200);outline: none;display:inline-block; font-size:xx-small; }
        #logout:hover{color:red}
        
        

        #easylink_div{position:fixed;left:0;top:0;height:100%;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;background-color:rgba(0, 0, 0,0.1);padding:70PX 0 20px 0;z-index:1}
        .function_link_div{display:block;width:40px;height:40px;margin:5px 10px;border:solid 0px grey;border-radius:5px;background-color:#e6e6e6;cursor:pointer;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;position: relative; 
        }
        .function_link_div:hover{background-color:white;}
        .function_link_div_dropdown{position: absolute;top:100%;left:1px;font-size:10px;opacity:0;width:100px;color:grey;z-index:100;transition: opacity 1s cubic-bezier(0.68, -0.55, 0.27, 1.55);}
        .function_link_div:hover .function_link_div_dropdown{opacity:1}
        .select_div{background-color:#fafafa;position: relative; }
        .select_div:after{
            content: '';  
            position: absolute;  
            right: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-left: 8px solid #fafafa; }
        .select_div:hover:after{border-left: 8px solid white}
        
        #main_content{margin:50px 25px 20px 75px;border:solid 0px red;transition:1s;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:flex-start}
        #main_content_part1{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s;flex:none;transition:1s}

        #file_manager{position:relative}
        #file_manager_head{color:#cc0066;font-size:20px;font-weight:bold;margin-bottom:20px;}
        #projectdir_mark_div{position:absolute;left:90px;top:1px}
        #projectdir_mark_div2{display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:left;align-items:top}
        #projectdir_mark_div_icon{position:relative;top:2px;left:7px}
        #projectdir_mark_div_icon_dropdown{display:none;position:absolute;top:23px;left:3px;font-size:xx-small;transition:0.3s;width:400px;color:#d81e06}
        #projectdir_mark_div_icon:hover #projectdir_mark_div_icon_dropdown{display:block}
        #projectdir_mark_div_right{display:none}
        #projectdir_mark_div_content{display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:left;align-items:center;padding:0px 6px 0px 6px;}
        #projectdir_mark_div_content>div{height:25px;color:#d81e06;padding:5px 7px;font-size:xx-small;cursor:pointer;border-radius:5px;margin:0 2px}

        #projectdir_mark_div_content:hover #projectdir_mark_div_close{display:block}
        #projectdir_mark_div_txt{max-width:400px;min-width;100px;;}        #projectdir_mark_div_txt:hover{background-color:#d81e06;color:white}
        #projectdir_mark_div_close {display:none;width;100px;}             #projectdir_mark_div_close:hover{background-color:#d81e06;color:white}
        
        
        #file_manager_path_all{position:relative}
        .file_manager_path{border:solid 0px blue;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:flex-start;;align-items:flex-start;}
        .file_manager_path_button{width:25px;height:25px;border:solid 1px #e6e6e6;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;user-select: none;cursor:pointer;}
        .file_manager_path_button:hover{background-color:#e5f2ff}
        .file_manager_path_button:active{background-color:#cc99ff}
        /**/
        .file_manager_path_classpath{display:flex;display:-webkit-flex;justify-content:flex-start;align-items:flex-start;;font-size:small;;user-select:none ;max-width:400px;min-width:400px;white-space: nowrap;flex-wrap: nowrap;position:relative;}
        
        .file_manager_blocks_click_region{min-width:400px;max-width:400px;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:flex-start;align-items:flex-start;;}

        .file_manager_path_classpath_each{height:25px;border:solid 0px red;display:inline-flex;;flex-wrap:nowrap;justify-content:center;align-items:center;cursor:pointer;}
        .file_manager_path_classpath_each_1{height:25px;transition:0.9s;padding:3px 5px 0 5px;border-left:solid 1px rgba(150, 150, 150,0)}
        .file_manager_path_classpath_each_2{height:25px;transition:0.9s;padding-top:3px;text-align:center;width:12px;border-left:solid 1px rgba(150, 150, 150,0);border-right:solid 1px rgba(150, 150, 150,0);position:relative}
        .file_manager_path_classpath_each:hover  .file_manager_path_classpath_each_1{background-color:#669999;transition:0.2s;border-left:solid 1px rgba(150, 150, 150,0.2)}
        .file_manager_path_classpath_each:hover  .file_manager_path_classpath_each_2{background-color:#d1e0e0;transition:0.2s;border-left:solid 1px rgba(150, 150, 150,0.2);border-right:solid 1px rgba(150, 150, 150,0.2)}
        .file_manager_path_classpath_each_2_dropdown{position:absolute;top:25px;left:0;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;;display:none;background: #e5f2ff;box-shadow: 2px 2px 7px 1px rgba(0,0,0,0.5);z-index:9999;}
        .file_manager_path_classpath_each_2:hover .file_manager_path_classpath_each_2_dropdown{display:block}
        .file_manager_path_classpath_each_2_dropdown div{cursor:pointer;padding:2px 5px; margin: 0;font: x-small;;border:solid 1px #d9e6f2}
        .file_manager_path_classpath_each_2_dropdown div:hover{background-color:rgba(51, 102, 153,0.5);}
        .file_manager_path_classpath_each_2_dropdown div:active{background-color:rgba(204, 153, 255,0.5);}
        
        
        #file_manager_content{min-height:500px}
        #file_manager_path2{position:absolute;left:0;top:0;height:23px;width:100%;background-color:white;z-index:-1;}
        #file_manager_path2_input{width:100%;background: none;border: none;padding: 0 15px 0 0; margin: 0;font: inherit;color: inherit;text-decoration: none;cursor: text;outline: none;position:relative;top:0px;line-height:1;height:24px}
        #file_manager_center_front{position:absolute;left:0;top:0;height:25px;width:400px;border-top:solid 1px #e6e6e6;;;border-bottom:solid 1px #e6e6e6;;z-index:9999;pointer-events: none;}
        #file_manager_center_back{position:absolute;left:0;top:0;height:25px;width:400px;background-color:	 #f3f7f7;z-index:-9999;pointer-events: none;}
        .table_top_function{float:right;}
        .table_top_function>div{display:inline-block}
        
        .table_top_button{height:22px;width:22px;display:inline-block}
        .file_table{margin:30px 0;border-collapse: collapse;background-color:white;font-size:small;z-index:1;min-width:490px;max-width:490px;width:490px}
        .file_table th{background-color:rgba(51, 102, 153,0.3);user-select: none;font-size:normal}
        .file_table th, .file_table td {
            padding: 2px 4px;
            border-bottom: 1px solid #ddd;
            text-align: left;white-space: nowrap;
        }
        .file_table tr:nth-child(even) {background-color: rgba(0, 0, 0,0.03);}
        #new_folder_tr,#new_file_tr{;display:none}
        #new_folder_tr td,#new_file_tr td{background-color: rgba(0, 153, 153,0.3);}
        #new_folder_tr input,#new_file_tr input{background:transparent;border: none;padding: 2px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;width:100%}
        .file_table tr:not(:first-child):hover {background-color:rgba(0, 102, 102,0.2)}
        .file_table td{color:grey}
        .file_name{cursor:pointer;padding-right:20px;color:black}
        .file_name:hover{color:#ff0066}
        .file_name_rename{display:none}
        .file_name_td{max-width:200px;overflow:hidden;;white-space: nowrap}
        .file_name_td:hover{overflow:auto;} 
        .refresh_time {  color: red; animation: fadeToBlack 1s forwards;}  
        @keyframes fadeToBlack {  from { color: red;}  to {  color: black;}  }
        
        .file_filesize_td{max-width:100px;overflow:hidden;;white-space: nowrap}
        .file_filesize_td:hover{overflow:auto;} 
        .file_updateTime_td{max-width:150px;overflow:hidden;;white-space: nowrap}        
        .file_updateTime_td:hover{overflow:auto;} 
        .link_setting{position:relative;display:inline-block;text-align:center}
        .link_setting_editor{text-decoration:none;display:inline-block;}
        .link_setting_editor_img{visibility: hidden;}
        .file_table tr:hover .link_setting_editor_img{visibility: visible;} 
        
        .link_setting_a{text-decoration:none}
        .link_setting_dropdown{position:absolute;left:100%;top:0;display:none;z-index:99999}
        .link_setting:hover .link_setting_dropdown{display:block}
        .link_setting_dropdown_div{display: grid;grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));gap: 0px;justify-content: start; align-items: center; border: solid 1px rgba(0,0,0,0.1);color:black}
        .link_setting_dropdown_button{background: #f2f2f2;border: none;padding: 2px 5px; margin: 0;font: inherit;color: inherit;text-decoration: none;cursor: pointer;outline: none; white-space: nowrap;z-index:99999;font-size:xx-small}
        .link_setting_dropdown_button:hover{background: #99ccff;color:#cc0066}
        .file_name_rename_div{position:relative}
        .file_name_rename_div:hover .file_name_rename_input{display:block}
        .file_name_rename_input{display:none;position:absolute;left:70px;top:0;width:300px}  
        
        .colored_mark td{background-color:rgba(51, 153, 102,0.1);}
        .colored_mark td:nth-child(3){color:red}
        
        #drop_area {border: 2px dashed #ccc;width: 400px;height: 50px;line-height: 50px;text-align: center;font-size: 20px;color: #ccc;display:none;position:absolute;bottom:30px;right:0px;background-color:rgba(255,255,255,0.9)}  
        #drop_area2 {border: 2px dashed #f2f2f2;width: 100%;height: 150px;line-height: 50px;text-align: center;font-size: 20px;color: #f2f2f2;;background-color:rgba(255,255,255,0.9)}  
        
        
        
        
        #main_content_part2{margin:5px;transition:1s;flex:1;position:relative;min-width:400px;width:100%;transition:1s}  
        .project_top_right div{display: inline-block;;transition:0.5s}
        .project_top_right:hover div{background-color:#e0ebeb;;transition:0.1s}
        .project_top_right #task_refresh{display:none}
        .project_top_right:hover #task_refresh{display:inline-block}
        #main_content_part3{margin:5px;transition:1s;flex:1;position:relative;min-width:200px;width:100%;transition:1s;display:none}  
        #file_preview_div{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;position:relative;padding-top:12px;width:100%;}
        #file_preview_close{position:absolute;top:5px;right:5px;display:block;height:36px;width:36px;cursor:pointer;display:none;padding:3px;border-radius:8px}
        #file_preview_close:hover{background-color:#f0f5f5}

        #file_preview{border:solid 0px red;margin-left:0 50px;;height:100%;padding:0;width:100%;max-width:100%}
        #file_preview_head{color:#009999;font-size:15px;font-weight:bold;margin-bottom:7px; user-select: text;max-width:95%;white-space:break-all;word-break: break-all; }/*word-break: break-all; 字符单词断开*/
        #file_preview_inner{background-color:white;overflow-wrap: break-word;white-space: pre-wrap;user-select: text;max-width: 99%;box-sizing: border-box;font-family: 'Courier New', Courier, monospace;;border:solid 0px blue;font-size:xx-small;}
        
        
        /*#top_message{padding:5px 10px;border:solid 1px grey;border-radius:10px;position:fixed;top:30px;left:50%;transform: translateX(-50%);font-size:small;display:none;opacity: 0; }*/
        .message-box {padding: 5px 10px;border: solid 1px grey;border-radius: 10px;position: fixed;left: 50%;transform: translateX(-50%);font-size: small;display: block;opacity: 1; z-index: 9999;background-color: white;transition: opacity ease-in-out; margin-top: 40px; }
    </style> 

    <style>

        
        /*table的上方信息*/
        #table_top{width:100%;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center}
        #table_top_1{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;}
        #table_top_2{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-end;align-items:center;width:100%}
        .table_top_2_function{margin:0 50px}
        .table_top_2_function_button{background:rgba(51, 102, 153,0.1);border:solid 1px grey;padding: 1px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;border-radius:2px;cursor:pointer;line-height:1}
        .table_top_2_function_button:hover{background-color:rgba(51, 102, 153,0.9);color:white}
        .table_top_2_function_button:active{background-color:black;color:white}
        

        .refresh_time {  color: red; animation: fadeToBlack 1s forwards;}  
        @keyframes fadeToBlack {  from { color: red;}  to {  color: black;}  }
        .refresh_time2 {  color: red; animation: fadeToBlack2 1s forwards;}  
        @keyframes fadeToBlack2 {  from { color:#004c4d;}  to {  color: #009999;}  }
        /**table信息*/
        .info_table{width:100%}
        .info_table{margin:0px 0 15px 0;border-collapse: collapse;background-color:white;font-size:small;z-index:1;min-width:300px}
        .info_table th{background-color:rgba(51, 102, 153,0.3);user-select: none;font-size:normal;transition:0s;}
        .info_table th:not(:first-child):not(:last-child):hover{background-color:rgba(51, 102, 153,0.6);cursor:pointer}
        .info_table th:not(:first-child):not(:last-child):active{background-color:rgba(151, 102, 153,1);}
        .info_table th {padding: 1px 5px;text-align: left;height:24px;white-space:nowrap;overflow:hidden;transition:1s}
        .info_table td {padding: 1px 0px;border-bottom: 1px solid #ddd;text-align: left;height:24px;white-space:nowrap;overflow:hidden;transition:1s}
        .info_table tr:nth-child(even) {background-color: rgba(0, 0, 0,0.03);}
        .info_table tr:not(:first-child):hover {background-color:rgba(0, 102, 102,0.2)}
        /*table的最后一列*/
        .table_link_col>div {display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;}
        .link_svg{cursor:pointer;}      
        
        /*table内部的input*/
        .edited_info {width:100%;height:24px;margin:0;box-sizing:border-box;border:none;border-radius:5px;background-color:transparent;padding:0 5px;outline:none;border:solid 1px transparent;transition:0.3s}
        .edited_info:focus{border:solid 1px #3366ff;}
        .edited_info:hover{border:solid 1px #3366ff;} 
        .slight_border{border:solid 1px rgba(0,0,0,0.1);background-color:rgba(255,255,255,0.3)}
        
        /*新建数据*/
        #new_folder_tr2,#new_file_tr2{;display:none}
        #new_folder_tr2 td,#new_file_tr2 td{background-color: rgba(0, 153, 153,0.3);}
        #new_folder_tr2 input,#new_file_tr2 input{background:transparent;border: none;padding: 2px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;width:100%}
        .colored_row td{background-color:rgba(255, 102, 153,0.3);transition:1s;}/*background-color:rgba(51, 102, 204,0.2)*/
        .marked_taskid{border:solid 2px red}
        
        .table_dirurl_link{background-color:rgba(255,255,255,0.5);border:solid 1px rgba(229, 247, 255,0.1);border-radius:5px;cursor:pointer;transition:0.5s;color:#336699;padding:2px 5px 1px 5px;;font-weight:bold;}
        .table_dirurl_link:hover{transition:0s;background-color:white;overflow:auto;height:auto;transition:0.3s}
        .table_dirurl_link:active{transition:0s;background-color:#cc99ff;}
        
        .table_set_td_div{background-color:rgba(255,255,255,0.1);border:solid 1px rgba(229, 247, 255,0.1);border-radius:5px;;transition:0.5s;color:#336699;padding:2px 5px 1px 5px;;font-weight:bold;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;width:100%}
        .table_set_td_div:hover{transition:0s;background-color:white;}
        .table_button_div{cursor:pointer;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;height:20px;width:20px;margin:0 5px}
        .task2dir_div{position:relative;float:right;margin-right:30px;cursor:pointer}
        .task2dir_div_dropdown{position:absolute;bottom:-3px;right:20px;display:none;font-size:xx-small;;line-height:25px;padding-left:10px}
        .task2dir_div:hover .task2dir_div_dropdown{display:block;}
        /*其他*/
        .green_background{background-color: rgba(0, 204, 0,0.4); /* 立刻变成绿色底纹 */}/*transition: background-color 6s linear;  */
        
        /*点击某个时高亮一行*/
        .marked_row td{background-color:rgba(255, 102, 153,0.3);transition:0s;}
        .marked_row:hover td{background-color:rgba(255, 102, 153,0.5);transition:0s;}
        
        .marked_projectid{border:solid 2px red}
        
        /**/
         #new_section_all{font-family: 'Microsoft YaHei', '微软雅黑', sans-serif;margin:auto;padding:auto}
    </style>
    
    <style>

        #progress_manager_content_div{padding:0px 30px;border:solid 0px blue;;margin-bottom:10px}
        #progress_manager_content_div_head{}
        #progress_refresh{height:40px;width:150px;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;flex-direction: column;border-radius:2px;background-color:#b3cccc;color:white;padding:4px;2px;border-radius:5px;font-weight:bold;font-size:small;margin-bottom:5px}
        #progress_refresh:hover{background-color:#a3c2c2}
        #progress_refresh:active{background-color:#85adad;color:white}
        #progress_refresh_time{font-size:xx-small}
       
        .progress_one_task{width:100%;border:solid 0px blue;font-size:xx-small}
        .progress_one_task_button{padding:2px 5px;background-color:#8cb2d9;color:white;margin-right:2px}
        .progress_one_task_button:hover{background-color:#79a5d3}
        .progress_one_task_button:active{background-color:#d98ca7}
        .progress_one_task_table1{border-collapse: collapse;}
        .progress_one_task_table1 td {padding: 2px 4px;border: 1px solid #ddd;text-align: left;white-space:nowrap}
        .progress_one_task_table1 td:first-child {background-color:#527a7a;color:white}
        .progress_one_task_table1 td:last-child {background-color:#e3e8e8;}
        .progress_one_task_table1_dir{cursor:pointer;}
        .progress_one_task_table1_dir:hover{color:#336699}
        .progress_one_task_table1_dir:active{color:#80007f}
        .progress_one_task_table2{margin:0px 10px 20px 40px;position:relative}
        /* 单个作业组 */
        .progress_job_group {display: flex;justify-content:left;align-items:center;border: 1px solid #ddd;border-radius: 6px;padding:3px 10px;background: #f9f9f9;position: relative;}
        .progress_job_group::before {content: "";position: absolute;left: -20px;top: 50%;width: 20px;height: 1px;background: #999;}/* 作业组左侧的横线 */
        .progress_job_group::after {content: "";position: absolute;left: -20px;top: -51%; /* 从上一个节点延伸下来 */bottom: 50%; /* 连接到当前横线的中点 */width: 1px;background: #999;}/* 作业组上方的竖直线（连接到根节点） */
        .progress_job_group:first-child::after {top: 0%;}/* 第一个作业组不需要上方的竖直线 */
        .job_status_container{position:relative;white-space: nowrap}
        .job_status_container_dropdown{position:absolute;display:none;padding:4px 7px;color:#336699;left:100%;border:solid 1px grey;border-radius:10px;background-color:#d1d1e0;width:195px;z-index:999}
        .job_status_container:hover .job_status_container_dropdown{display:block}

        /**/
        .jobid_label{background-color:#9cb0b0;color:white;border:solid 1px grey;padding:1px 5px;white-space:nowrap;}/*高度16px*/
        .midstate_container{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;border:solid 0px red;height:20px}
        .midstate_container_shortline{background-color: grey;width:20px;height:1px;margin-right:4px}
        .midState_one{cursor:pointer;height:15px;width:15px;border:solid 1px grey;margin:0 2px;background-color:#9fbfdf;position:relative}
        .midState_one_active{cursor:pointer;height:15px;width:15px;border:solid 1px grey;margin:0 2px;background-color:green;animation: heartbeat 1.5s infinite ease-in-out;;position:relative}
        .midState_one_die{cursor:pointer;height:15px;width:15px;border:solid 1px grey;margin:0 2px;background-color:#595959;position:relative}
        .midState_one_blank{cursor:pointer;height:15px;width:15px;border:solid 1px grey;margin:0 2px;background-color:white}
        .midState_one_dropdown{position:absolute;display:none;padding:4px 7px;color:#336699;left:100%;border:solid 1px grey;border-radius:4px;background-color:#e1e1ea;width:195px;z-index:999}
        .midState_one_dropdown span{color:black}
        .midState_one:hover .midState_one_dropdown{display:block}
        .midState_one_die:hover .midState_one_dropdown{display:block}
        .midState_one_active:hover .midState_one_dropdown{display:block}
        @keyframes heartbeat {0% { background-color: #006400; }  /* 深绿 */50% { background-color: #00b300; } /* 亮绿 */100% { background-color: #006400; } /* 恢复深绿 */}}
        
        .slurm_control_container{}
        .slurm_real_state{flex:1;background-color:#e0e0eb;padding:0px 5px;margin-right:20px;border:solid 1px grey;white-space:nowrap;vertical-align:middle}
        .slurm_real_controls{flex:1;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;}
        .slurm_real_controls_one{cursor:pointer;display:flex;display:-webkit-flex;justify-content:center;;;align-items:center;;background-color:#e0e0eb;border-radius:3px;transition:0.2s;margin:0 2px}
        .slurm_real_controls_one img{height:16px;width:16px}
        .slurm_real_controls_one:hover{background-color:#ddd1e1;transition:0s}
    </style>    
</head>
<body>
    <div id='top_navigator'>
        <a id='top_navigator_title_name' href='index.php'>Bioslurm</a>
        <span id="top_navigator_current_time"></span>
        <span id="user_state"><?php echo $navi_user_state;?></span>
    </div> 
    <div  id='easylink_div'>
        <a href='index.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_home.svg">
            </div>
        </a>
        
        <a href='function_file.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_file.svg">
                <div class='function_link_div_dropdown'>文件目录</div>
            </div>
        </a>
        
        <a href='function_script.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_script.svg">
                <div class='function_link_div_dropdown'>命令脚本</div>
            </div>
        </a>

        <a href='function_stream.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_stream.svg">
                <div class='function_link_div_dropdown'>线性流程</div>
            </div>
        </a>
        
        <a href='function_structure.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_structure.svg">
                <div class='function_link_div_dropdown'>网络结构</div>
            </div>
        </a>
        
        <a href='function_project.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_project.svg">
                <div class='function_link_div_dropdown'>项目执行</div>
            </div>
        </a>     

        <a href='function_progress.php' >
            <div class='function_link_div select_div' ><img style='width:30px;height:30px' src="000_image/svg_function_progress.svg">
                <div class='function_link_div_dropdown'>作业进度</div>
            </div>
        </a>   
        
        <a href='function_zoom.php' style='margin-top: auto;margin-bottom:50px'>
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_gear.svg">
            </div>
        </a>                 
    </div>
    <div id='all_sum'>
        <div id='main_content'>
            <div id='main_content_part1'>
                <div id="file_manager"> 
                    <div id='file_manager_head'>
                        <span style="cursor:pointer;color:#009999 " onclick="path_refresh_click()">作业进度</span>
                    </div>
                    
                    <div id="file_manager_path_all">
                        <div  class="file_manager_path">
                            <div class="file_manager_path_button" onclick='path_back_click()'><img src="000_image/svg_leftarrow.svg"></div>
                            <div class="file_manager_path_button" style='margin-left:-1px' onclick='path_forword_click()'><img src="000_image/svg_leftarrow.svg" style="transform: rotate(180deg);"></div>
                            <div class="file_manager_path_classpath">
                                <!--上层左边，里面一块块的路径，可以换行-->
                                <div class='file_manager_blocks_click_region' id="file_manager_blocks_click_region">
                                </div>
                                
                                <!--底层可以输入的input，absolute-->
                                <div id="file_manager_path2">   
                                    <input id='file_manager_path2_input' type="text" value='/home/'>
                                </div> 
                                
                                <!--底层一个固定边框-->
                                <div id="file_manager_center_front">   </div> 
                                <div id="file_manager_center_back">   </div> 
                                
                            </div>
                            <div class="file_manager_path_button" onclick="path_change_click()" id='path_change_click_button'><img src="000_image/svg_urlwrite.svg"></div>
                            <div class="file_manager_path_button" style='margin-left:-1px' onclick="path_refresh_click()"><img src="000_image/svg_refresh.svg"></div>
                        </div>    
                        <div style='position:absolute;top:40px;right:70px;font-size:xx-small;color:#336699' id='collect_num_show'></div>
                    </div>
                    <!-- 动态生成文件和文件夹 -->  
                    <div id="file_manager_content" >
                    </div>   
                </div>  
            </div>                       
            <div id='main_content_part2'>
                <div id="progress_manager_content_div">
                    <div id ='progress_manager_content_div_head' style=''>
                        <div id='progress_refresh' onclick='progress_refresh_click()'>
                            <div>Refresh</div>
                            <div id='progress_refresh_time'><?php echo $current_time;?></div>
                        </div>

                    </div>
                    <div id ='progress_manager_content_div_inner'>
                    </div> 
                </div >     
           
            </div>   
            
            <div id='main_content_part3'>
                <div id="file_preview_div">
                    <div id='file_preview_close' onclick='file_preview_close_click()'><img style='width:30px;height:30px' src="000_image/svg_close.svg"></div>
                    <div id="file_preview">
                        <div id="file_preview_head" style='white-space:break-all;'></div>
                        <div id="file_preview_inner" style='min-height: calc(100vh - 150px);'></div>
                    </div> 
                </div> 
            </div> 
        </div> 
        
        <div id='top_message'></div>
        

        
        

        
        <!--file-->
        <input type='hidden' id='local_path' value='/'>
        <input type='hidden' id='local_path_bak' value='/'>
        <input type='hidden' id='all_checkbox_value' name='all_checkbox_value' value=''  />
        <input type='hidden' id='all_checkbox_value_localpath' name='all_checkbox_value_localpath' value=''  />
        
        
    </div> 
        </div>
    </div> 

    <script src="/plug/monaco_editor/min/vs/loader.js"></script><!--注意更改路径-->   
    <script src="plug/monaco_editor/DIY/editor.js"></script>
</body>      
</html>

<script>
    function getCurrentTime() {
        var now = new Date();
    
        // 获取小时、分钟和秒
        var hours = now.getHours();
        var minutes = now.getMinutes();
        var seconds = now.getSeconds();
    
        // 格式化时间（例如：09:05:03）
        var formattedTime = [
            String(hours).padStart(2, '0'),
            String(minutes).padStart(2, '0'),  //String(hours).padStart(2, '0') 是将 hours 转换为字符串，并且如果 hours 的长度小于 2，就在其前面填充 '0'，确保输出始终是两位数的格式
            String(seconds).padStart(2, '0')
        ].join(':');
    
        return formattedTime;
    }
   
    function getCurrentTime2() {
        var now = new Date();
        var year = now.getFullYear();
        var month = String(now.getMonth() + 1).padStart(2, '0'); // 月份从 0 开始，需要加 1
        var day = String(now.getDate()).padStart(2, '0');
        var hours = String(now.getHours()).padStart(2, '0');
        var minutes = String(now.getMinutes()).padStart(2, '0');
        var seconds = String(now.getSeconds()).padStart(2, '0');
        // 格式化年月日和时间
        var formattedTime = [year, month, day].join('') + [hours, minutes, seconds].join('');
        return formattedTime;
    }
    
    function generateRandomString(length) {  
        var characters = 'abcdefghijklmnopqrstuvwxyz0123456789';  
        let result = '';  
        for (let i = 0; i < length; i++) {  
            var randomIndex = Math.floor(Math.random() * characters.length);  
            result += characters[randomIndex];  
        }  
        return result;  
    }  
    
    const dict_node2name = {};
    const checkboxValuesSet = new Set();  //外部声明一个set，虽然是const定义的的，由于是set仍然可以编辑
    // 上传文件
    function uploadFiles(files, uploadPath) {
        // 创建 FormData 对象
        var formData = new FormData();
        formData.append('upload_path', uploadPath); // 将目录路径添加到 FormData
        // 将文件添加到 FormData 对象中
        for (let file of files) {formData.append('files[]', file); }
        // 使用 Fetch API 上传文件
        fetch('/function_file_upload.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json()) // 解析 JSON 响应
        .then(data => {
            console.log('Upload successful:', data);
            // 打印 filelist
            if (data.status === 'success') {
                console.log('Uploaded files:', data.result.filelist);
                path_refresh_click(data.result.filelist); // 刷新路径
                //alert('Files uploaded successfully.');
                let innerHTML='文件上传成功';
                showAndFadeOut('success', 2000, 3,innerHTML);
            } else {
                console.log('Errors:', data.result.errors);
                alert('Error uploading files.');
            }
        })
        .catch(error => {
            console.error('Error uploading files:', error);
            showAndFadeOut('error', 2000, 3,error)
            alert('Error uploading files.');
        });
    }
    //拖拽的
    function preventDefaults(e) {e.preventDefault();e.stopPropagation(); }
    function handleDrop(e) {
        preventDefaults(e);
        var files = e.dataTransfer.files;
        var uploadPath = (base_path + document.getElementById('local_path').value);
        console.log("uploadPath:", uploadPath);
        uploadFiles(files, uploadPath);
    }
    function handleDragOver(e) {preventDefaults(e);e.dataTransfer.dropEffect = 'copy';}
    //选择的文件
    // 监听文件选择器的 change 事件，选择文件后自动上传
    function triggerFileSelection() {document.getElementById('fileInput').click(); }  // 点击按钮时，触发隐藏的文件选择器    
   
    const local_path_history =  ['/'];
    const local_path_history2 = [];
    function ajax_get_filelist(base_path, local_path, colored_list,is_backforward,callback) {
        //console.log("ajax_get_filelist开始：","base_path:",base_path, "local_path:",local_path, "colored_list:",colored_list);
        let complete_path=base_path+local_path;
        fetch('function_file_get_filelist.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'action':'get_all',
                'base_path': base_path ,
                'local_path': local_path,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            //console.log(data.result);
            //console.log(data.error);

            let query_type=data.url_type;
            
            //清空复选框
            checkboxValuesSet.clear();
            // 你可以根据 data 内容生成 HTML 片段
            
            let current_time=getCurrentTime();
            let table1=`    <table class="file_table">
                                <tr class=''>
                                    <td colspan='6' style='vertical-align:bottom'>
                                        <span class='refresh_time' style='position:relative;top:5px;cursor:pointer' onclick="path_refresh_click()">刷新时间: ${current_time}</span> 
                                        <div class='table_top_function'>
                                            
                                            <div>
                                                新建<button class='table_top_button' onclick='create_dir_click()'><img src='/000_image/svg_link_create_dir.svg'></button><button  onclick='create_txt_click()' class='table_top_button' style='margin-left:1px' ><img src='/000_image/svg_link_create_txt.svg'></button>
                                            </div>                                                 
                                            
                                            <div class='toggle-btn' style='position:relative'>
                                                上传<input type="file" id="fileInput" multiple style="display: none;" /><button class='table_top_button' id="uploadButton" onclick="triggerFileSelection()"><img src='/000_image/svg_link_upload.svg'></button><button  onclick="show_and_hide('drop_area')" class='table_top_button' style='margin-left:1px' ><img src='/000_image/svg_link_drag.svg'></button><div id="drop_area">Drag and drop files here</div>
                                            </div>  
 
                                            <div >
                                                移动<button class='table_top_button' onclick='collect_checkboxs()'><img src='/000_image/svg_link_cut.svg'></button><button class='table_top_button' style='margin-left:1px' onclick='collect_checkboxs_mvfile()'><img src='/000_image/svg_link_paste.svg' ></button>
                                            </div>
                                            
                                            <div class='link_setting'>
                                                处理<button class='table_top_button'><img src='/000_image/svg_link_gears.svg'></button>
                                                <div class='link_setting_dropdown'>
                                                     <div class='link_setting_dropdown_div'>
                                                        <button class='link_setting_dropdown_button' onclick="file_operate_multi('批量删除')">批量删除</button>
                                                        <button class='link_setting_dropdown_button' onclick="file_operate_multi('批量压缩')">批量压缩</button>
                                                    </div>   
                                                </div>    
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th colspan='2' style='width:20px'><input  type='checkbox' id='all_checkbox' name='all_checkbox' value='all_checkbox' onclick='all_checkbox_click()' style='position:relative;top:2px'>
                                        <input type='hidden' id='all_checkbox_state' name='all_checkbox_state' value='0'  />
                                        <span id='checkbox_selected_num' style='font-size:10px;color:darkblue'></span>
                                    </th>
                                    <th>Name</th>
                                    <th>文件大小</th>
                                    <th>更新时间</th>
                                    <th style='text-align:center'>操作</th>
                                </tr>
                                <tr id='new_folder_tr' >
                                    <td></td>
                                    <td><img style='position:relative;top:3px' src='/000_image/svg_filetype_folder.svg'></td>
                                    <td colspan='4'><input type='text' id='new_folder_tr_input' value='新建文件夹'></td>
                                </tr>
                                <tr id='new_file_tr' >
                                    <td></td>
                                    <td><img style='position:relative;top:3px' src='/000_image/svg_filetype_normal.svg'></td>
                                    <td colspan='4'><input type='text' id='new_file_tr_input' value='新建文件'></td>
                                </tr>                                
                                `;
            let table2=``;
            let dir_list=[];let dir_file_num=0;let normal_file_num=0;
            raw_result.forEach((item) => {
                let fileType_icon_name="";let file_type='';let file_name_click_str='';
                let file_name=item.fileName.split('/').pop();;  
                let filesize=item.size;
                let file_pointer_events='';
                let complete_path_real=complete_path.substring(21);
                let download_file=complete_path_real+"/"+file_name;
                //有颜色闪烁的一行
                let colored_mark='';
                //
                
                if (typeof colored_list !== 'undefined'){
                    //console.log('有colored_list');
                    if(colored_list.includes(file_name)){colored_mark='colored_mark';console.log('高亮的行：',file_name);}
                }
                //
                let file_size_show=filesize;
                let code_editor_str='';
                if(item.fileType=="d"){     fileType_icon_name='svg_filetype_folder.svg';file_type='文件夹';file_name_click_str='file_jumpinto';
                                            dir_list.push(file_name);dir_file_num+=1;file_pointer_events=" style='pointer-events: none;visibility: hidden;'";file_size_show=`<button style='all: unset;color:#009999' onclick ="cal_dir_size('${file_name}')">计算</button>`;}
                else{                       fileType_icon_name='svg_filetype_normal.svg';file_type='文件';file_name_click_str='file_open';normal_file_num+=1;
                    file_size_show=formatBytes(filesize);
                    if (filesize<10485760){ //10M
                        //如果是预定的一些扩展名，尽量显示他们
                        const extensions = ['.abap','.cls','.azcli','.bat','.bicep','.mligo','.clj','.coffee','.cpp','.cs','.csp','.css','.cyp','.dart','.dockerfile','.ecl','.ex','.js','.jsx','.ts','.tsx','.flow9','.freemarker2','.fsharp','.go','.graphql','.handlebars','.hcl','.html','.ini','.java','.julia','.kt','.less','.lexon','.liquid','.lua','.m3','.md','.mdx','.mips','.msdax','.mysql','.m','.pas','.pascaligo','.pl','.pgsql','.php','.pla','.postiats','.pq','.ps1','.proto','.pug','.py','.qs','.r','.razor','.redis','.redshift','.rst','.rb','.rs','.sb','.scala','.scm','.scss','.sh','.sol','.sophia','.rq','.sql','.st','.swift','.sv','.tcl','.twig','.vb','.wgsl','.xml','.yaml','.yml','.log','.err','.fai','.txt','.slm','.vcf','.bed','.fasta','.fas','.fa'];
                        const regex = new RegExp(`\\.(${extensions.map(ext => ext.slice(1)).join('|')})$`, 'i');// 生成正则表达式（如：/\.(abap|cls|azcli|...)$/i）
                        let good_extension_str=``;
                        if(regex.test(file_name)){good_extension_str=`visibility:visible`;}
                        //
                        code_editor_str=`
                                <div class='link_setting_editor'>
                                    <img style='position:relative;top:3px;${good_extension_str}' src='/000_image/svg_link_editor.svg' class='link_setting_editor_img'  onclick="code_editor_generate('${complete_path_real}','${file_name}')">
                                </div>`;}
                }
                let BioSlurm_share_checkbox='';let select_checkbox_class='select_checkbox';let link_setting_hidden='';
                if (file_name=='BioSlurm_share'){BioSlurm_share_checkbox='disabled';select_checkbox_class='';link_setting_hidden='display:none';}
                table2+=`       <tr class='${colored_mark}'>
                                    <td style='width:10px'>
                                        <input  type='checkbox' class='${select_checkbox_class}' style='position:relative;top:3px' name='selected_files' onclick='one_checkbox_click(this)' value='${file_name}_||_${file_type}'  ${BioSlurm_share_checkbox}>
                                    </td>
                                    <td style='width:12px'><img style='position:relative;top:3px' src='/000_image/${fileType_icon_name}' onclick="copy_str('${file_name}')"></td>
                                    <td class="file_name_td">
                                        <div class='file_name' onclick="${file_name_click_str}('${file_name}','${filesize}')" >${file_name}</div>
                                    </td>
                                    <td>${file_size_show}</td>
                                    <td style='width:120px'>${item.updateTime}</td>
                                    <td style='text-align:right;width:75px'>
                                        ${code_editor_str}
                                        <a href="${download_file}" download class='link_setting_a'  ${file_pointer_events}><div class='link_setting'>
                                            <img style='position:relative;top:3px' src='/000_image/svg_link_download.svg'>
                                             </div>   
                                        </a>
                                        <div class='link_setting' style='${link_setting_hidden}'>
                                            <img style='position:relative;top:3px' src='/000_image/svg_link_gear.svg'>
                                            <div class='link_setting_dropdown'>
                                                 <div class='link_setting_dropdown_div'>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('删除','${file_type}','${file_name}')">删除</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('复制','${file_type}','${file_name}')">复制</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('压缩','${file_type}','${file_name}')">压缩</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('解压','${file_type}','${file_name}')">解压</button>
                                                    <div class='link_setting_dropdown_button file_name_rename_div' >
                                                        重命名
                                                        <input type='text' class='file_name_rename_input' onchange="file_operate('重命名','${file_type}','${file_name}',this)" value='${file_name}'>
                                                    </div>
                                                    
                                                </div>   
                                            </div>    
                                        </div>
                                    </td>
                                </tr>`;
            });
            let table3=`        <tr>
                                    <td colspan='6' style='font-size:15px;color:grey;font-size:xx-small'>
                                        文件夹数量${dir_file_num}个，文件数量${normal_file_num}个。点击图标复制名称。
                                    </td>
                                </tr>
                                <tr style='background-color:transparent;'>
                                    <td colspan='6' style='font-size:15px;color:grey;font-size:xx-small;background-color:transparent;border:none'>
                                        <div id="drop_area2">Drag and drop files here</div>
                                    </td>
                                </tr>
                            <table>`;
            let table_sum=table1+table2+table3;
            let contentHtml = `${table_sum}`.trim();

            //改表头
            let new_local_path=document.getElementById('local_path_bak').value;
            document.getElementById('local_path').value=new_local_path;
            let path2_url=("/home/"+new_local_path).replace(/\/{2,}/g, '/');   //去掉连续的
            let new_local_path_arr = new_local_path.split('/');
            
            if (query_type=="文件"){
                new_local_path_arr.pop();
                path2_url = path2_url.replace(/\/[^\/]*\/?$/, '')+"/";       //如果是文件，去掉最后一个非边界/之后的内容
                let truncted_local_path=path2_url.replace(/^(\/?home\/)/, '/');
                console.log("文件，truncted_local_path:",truncted_local_path);
                document.getElementById('local_path').value=truncted_local_path;
                document.getElementById('local_path_bak').value=truncted_local_path;
            }
            //console.log(query_type);
            //console.log("path2_url",path2_url);
            document.getElementById('file_manager_path2_input').value=path2_url.replace(/\/{2,}/g, '/');
            //console.log("new_local_path_arr",new_local_path_arr);
            let file_manager_blocks_click_region=`<div class="file_manager_path_classpath_each">   
                                        <span class="file_manager_path_classpath_each_1" onclick="dirurl_jumpinto('/')">home</span>     
                                        <span class="file_manager_path_classpath_each_2" id='dir_expand_1' onclick="dir_expand_click('dir_expand_1','/')">><div class="file_manager_path_classpath_each_2_dropdown" id='dir_expand_1_dropdown'></div></span>     
                                    </div>`;
            let dir_url="/";
            let dir_expand_num=1;
            let part_local_path='/';
            new_local_path_arr.forEach((item) => {
                if (item != "") { 
                    dir_url+=item+"/";
                    dir_expand_num+=1;  part_local_path+="/"+item;
                    file_manager_blocks_click_region+=    `<div class="file_manager_path_classpath_each">   
                                                    <span class="file_manager_path_classpath_each_1" onclick="dirurl_jumpinto('${dir_url}')">${item}</span>     
                                                    <span class="file_manager_path_classpath_each_2" id='dir_expand_${dir_expand_num}' onclick="dir_expand_click('dir_expand_${dir_expand_num}','${part_local_path}')">><div id='dir_expand_${dir_expand_num}_dropdown'  class="file_manager_path_classpath_each_2_dropdown" ></div></span>     
                                                </div>`;
                }
            });
            //console.log("file_manager_blocks_click_region",file_manager_blocks_click_region);
            document.getElementById('file_manager_blocks_click_region').innerHTML=file_manager_blocks_click_region;;
            
            //改内容
            var fileManagerContentDiv = document.getElementById('file_manager_content');;
            fileManagerContentDiv.innerHTML = contentHtml;
            
            //非历史左右键则考虑更新
            if(is_backforward=="is_backforward"){}else{
                if(local_path_history[local_path_history.length - 1] == local_path) {}                                                //重复请求
                else{
                    local_path_history.push(local_path);
                    //是否前进
                    if(local_path_history2.length > 0){
                        if (local_path_history2[0] !== local_path) {local_path_history2.length = 0; }       //清空path2
                        else{local_path_history2.shift(); }                                                 // 移除第一个元素
                    }
                }
                //console.log(local_path_history,local_path_history2);
            }
            // 拖拽上传, 给div加上监听
            var dropArea = document.getElementById('drop_area');
            dropArea.addEventListener('dragenter', preventDefaults, false);
            dropArea.addEventListener('dragover', handleDragOver, false);
            dropArea.addEventListener('drop', handleDrop, false);
            // 使 drop_area2 拥有相同的行为
            var dropArea2 = document.getElementById('drop_area2');
            dropArea2.addEventListener('dragenter', preventDefaults, false);
            dropArea2.addEventListener('dragover', handleDragOver, false);
            dropArea2.addEventListener('drop', function(e) {
                // 模拟 drop_area1 的 handleDrop 行为
                handleDrop.call(dropArea, e);
            }, false);   
            
            
            //点击上传
            document.getElementById('fileInput').addEventListener('change', function() {// 监听文件选择器的 change 事件，选择文件后自动上传
                var files = document.getElementById('fileInput').files;
                var uploadPath = base_path + document.getElementById('local_path').value;
            
                if (files.length > 0) {
                    // 自动上传文件
                    uploadFiles(files, uploadPath);
                } else {
                    alert('请先选择文件。');
                }
            });
            
            if(callback){
                callback();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            if (error.message == "没有那个文件或目录") {
                document.getElementById('file_manager_path2_input').value = "/home/" + document.getElementById('local_path').value;
                let innerHTML = '没有那个文件或目录，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else if (error.message == "错误的路径格式") {
                document.getElementById('file_manager_path2_input').value = "/home/" + document.getElementById('local_path').value;
                let innerHTML = '错误的路径格式，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else{
                // 处理其他未知错误
                let innerHTML = '发生未知错误，请稍后再试';
                showAndFadeOut('error', 2000, 3,innerHTML);
            }
        });
    }
    
    //页面初始化时的操作
    const base_path = <?php echo json_encode($base_path); ?>;
    const local_path =document.getElementById('local_path').value;;
    ajax_get_filelist(base_path, local_path);
    
    //路径输入
    let isPathInputActive = false; // 标志变量，用于跟踪路径输入是否激活  
    function path_change_click() {  
        console.log('path_change_click');  
          
        // 设置路径输入激活状态  
        isPathInputActive = true;  
        document.getElementById('file_manager_path2').style.zIndex = '9999';
        document.getElementById('file_manager_blocks_click_region').style.display='none';
        let inputElement = document.getElementById('file_manager_path2_input');
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
       // 添加点击事件监听器  
        document.addEventListener('click', handleClickOutsideInput);  
          
        // 添加键盘事件监听器  
        document.addEventListener('keydown', handleKeydown);  
    }  
      
    function handleClickOutsideInput(event) {  
        // 检查点击是否发生在输入框之外，且不是特定按钮  
        const inputElement = document.getElementById('file_manager_path2_input');  
        const buttonElement = document.querySelector('#path_change_click_button');  
        if (isPathInputActive &&  
            !inputElement.contains(event.target) &&  
            (buttonElement === null || !buttonElement.contains(event.target))) {  
              
            // 点击发生在输入框和特定按钮之外，执行相应操作  
            document.getElementById('file_manager_path2').style.zIndex = '-1';  
            document.getElementById('file_manager_blocks_click_region').style.display = 'flex';  
              
            // 路径输入处理完成，移除监听器  
            removeListeners();  
        }  
    }  
      
    function handleKeydown(event) {  
        if (isPathInputActive && (event.key === 'Enter' || event.keyCode === 13)) {  
            // 按下了回车键，执行相应操作  
              
            // 还原z-index和显示区域  
            document.getElementById('file_manager_path2').style.zIndex = '-1';  
            document.getElementById('file_manager_blocks_click_region').style.display = 'flex';  
              
            // 路径输入处理完成，移除监听器  
            removeListeners();  
        }  
    }  
      
    function removeListeners() {  
        // 移除点击和键盘事件监听器  
        document.removeEventListener('click', handleClickOutsideInput);  
        document.removeEventListener('keydown', handleKeydown);  
          
        // 重置路径输入激活状态  
        isPathInputActive = false;  
    }  
    
    //单击文件的操作
    function file_jumpinto(file_name,filesize){
        let old_local_path    =document.getElementById('local_path').value;
        let new_local_path    =old_local_path+"/"+file_name+"/";
        new_local_path = new_local_path.replace(/\/{2,}/g, '/');
        //console.log("js将进入新文件夹：",new_local_path);
        document.getElementById('local_path_bak').value=new_local_path;
        ajax_get_filelist(base_path, new_local_path);
    }
    
    //url to link
    function dirurl_jumpinto(dirurl,is_backforward,callback){
        new_local_path = (dirurl+"/").replace(/\/{2,}/g, '/');
        //console.log("js将进入新url：",new_local_path);
        document.getElementById('local_path_bak').value=new_local_path;
        ajax_get_filelist(base_path, new_local_path,"",is_backforward,function(){if(callback){callback();}});
    }
    
    //path_back_click
    /*function path_back_click(){
        /* 只是删除最后一个层级，没啥意义，还是回溯和前进历史比较好
        let old_local_path    =document.getElementById('local_path').value;
        let lastSlashIndex = old_local_path.lastIndexOf('/');
        // 如果路径中有斜杠
        if (lastSlashIndex !== -1) {
            let new_local_path=old_local_path.substring(0, lastSlashIndex); 
            document.getElementById('local_path').value=new_local_path;
            document.getElementById('local_path_bak').value=new_local_path;
            ajax_get_filelist(base_path, new_local_path);
        }
    }*/
    
    function path_back_click() {
        let old_local_path = document.getElementById('local_path').value;let new_local_path = '';
        if (local_path_history.length > 1) {
            let lastPath = local_path_history.pop();    local_path_history2.unshift(lastPath);     // 移除local_path_history最后个元素并添加到 local_path_history2的开头
            new_local_path = local_path_history[local_path_history.length-1]; } 
        else { new_local_path = old_local_path;}
        document.getElementById('local_path').value=new_local_path;
        dirurl_jumpinto(new_local_path,"is_backforward");
        console.log(local_path_history,local_path_history2);
        //console.log("local_path_history1/2:",local_path_history,local_path_history2);
        //console.log("新地址：",new_local_path);
    }

    function path_forword_click(){
        let old_local_path = document.getElementById('local_path').value;let new_local_path = '';
        if(local_path_history2.length > 0){
            let firstPath = local_path_history2.shift();        local_path_history.push(firstPath);      // 移除local_path_history2第一个元素并添加到 local_path_history
            new_local_path = firstPath; }  
        else{new_local_path = old_local_path;}
        document.getElementById('local_path').value=new_local_path;
        dirurl_jumpinto(new_local_path,"is_backforward");
        console.log(local_path_history,local_path_history2);
        //console.log("local_path_history1/2:",local_path_history,local_path_history2);
        //console.log("新地址：",new_local_path);
    }
    
    function path_refresh_click(colored_list,callback){
        let old_local_path    =document.getElementById('local_path').value;
        ajax_get_filelist(base_path, old_local_path,colored_list,'',function(){
            if(callback){callback();}
        });//function ajax_get_filelist(base_path, local_path, colored_list,is_backforward,callback)
        
    }
    
    //url按回车 或 监听失去焦点事件
    document.getElementById('file_manager_path2_input').addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // 阻止默认的提交行为
            handlePathUpdate(); // 处理路径更新
        }
    });
    document.getElementById('file_manager_path2_input').addEventListener('blur', function() {
        handlePathUpdate(); // 处理路径更新
    });
    function handlePathUpdate() {
        var inputElement = document.getElementById('file_manager_path2_input');
        var inputValue = inputElement.value; // 获取输入框的值
        console.log("用户输入的路径是:", inputValue);
        // 处理路径
        let new_local_path = inputValue.replace(/^\/?home\//, '/').replace(/\/{2,}/g, '/'); // 去掉以 "/home/" 或 "home/" 开头的部分
        // 更新隐藏字段值
        document.getElementById('local_path_bak').value = new_local_path;
        // 调用 ajax_get_filelist 函数
        ajax_get_filelist(base_path, new_local_path);
    }    
    
    
    //url的>扩展
    function dir_expand_click(dir_expand_num,new_local_path){
        console.log("dir_expand_num,new_local_path:",dir_expand_num,new_local_path);
        fetch('function_file_get_filelist.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'action':'get_dir',
                'base_path': base_path ,
                'local_path': new_local_path,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            let dropdown_html='';
            raw_result.forEach((item) => {
                if (item != "") { 
                    let part_local_path=new_local_path+"/"+item;
                    dropdown_html+= `   <div onclick="dirurl_jumpinto('${part_local_path}')">   
                                            ${item}
                                        </div>`;
                }
            });
            //改写
            let dir_expand_num_dropdown=document.getElementById(dir_expand_num+"_dropdown");
            dir_expand_num_dropdown.innerHTML=dropdown_html;
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            if (error.message == "没有那个文件或目录") {
                document.getElementById('file_manager_path2_input').value = "/home" + document.getElementById('local_path').value;
                let innerHTML = '没有下级目录了';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else if (error.message == "错误的路径格式") {
                document.getElementById('file_manager_path2_input').value = "/home" + document.getElementById('local_path').value;
                let innerHTML = '错误的路径格式，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else{
                // 处理其他未知错误
                let innerHTML = '发生未知错误，请稍后再试';
                showAndFadeOut('error', 2000, 3,innerHTML);
            }
        });
    }
    
    
    function create_dir_click() {  
        console.log("操作: create_dir_click");  
        const newFolderTr = document.getElementById('new_folder_tr');  
        const inputElement = document.getElementById('new_folder_tr_input');  
          
        // 显示新文件夹输入行  
        newFolderTr.style.display = "table-row";  
          
        // 聚焦到输入框并移动光标到末尾  
        inputElement.focus();  
        let value = inputElement.value;  
        inputElement.value = ''; // 清空内容以重置光标位置（这一步可能是多余的，除非有特定需求）  
        inputElement.value = value; // 重新设置内容  
          
        //
        let submitted = false; // 标志位：是否已提交
        function handleSubmit(){
            if(submitted){return false;}
            new_value=inputElement.value;
            file_operate("新建", "文件夹", new_value);  
            event.preventDefault(); 
            submitted=true;
        }
        // 监听失去焦点
        // 监听失去焦点事件
         inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            handleSubmit();
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                handleSubmit();
            }
        });  
    }  
    
    //create_txt_click
    function create_txt_click(){
        console.log("操作: create_txt_click");
        document.getElementById('new_file_tr').style.display = "table-row";
        // 将光标移到文本末尾
        let inputElement = document.getElementById('new_file_tr_input');
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
        
        let new_value= inputElement.value;
        //
        let submitted = false; // 标志位：是否已提交
        function handleSubmit(){
            if(submitted){return false;}
            new_value=inputElement.value;
            file_operate("新建","文件",new_value);
            event.preventDefault(); 
            submitted=true;
        }
        // 监听失去焦点
        // 监听失去焦点事件
         inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            handleSubmit();
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                handleSubmit();
            }
        });
    }
    function formatBytes(bytes, decimalPlaces = 2) {
        if (bytes == 0) return '0 ';
        if (isNaN(bytes) || !isFinite(bytes)) return 'Invalid Bytes';
    
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        // 确保不超过GB单位（根据需求可扩展TB）
        const clampedIndex = Math.min(i, sizes.length - 1);
        
        // 计算转换后的值（保留指定位小数）
        const formattedValue = parseFloat(
            (bytes / Math.pow(k, clampedIndex)).toFixed(decimalPlaces)
        );
        
        return `${formattedValue} ${sizes[clampedIndex]}`;
    }
    function cal_dir_size(file_name){
        console.log('cal_dir_size');
        let local_path= document.getElementById('local_path').value;
        let file_complete_path=base_path + local_path + "/" + file_name;
        // 发起请求
        fetch('function_file_get_dirsize.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                dir_complete_path: file_complete_path,
            }),
        })
        .then(response => {
            if (!response.ok) {
                // 尝试解析错误响应（假设后端返回JSON错误）
                return response.json().then(err => {
                    throw new Error(err.message || 'Unknown server error');
                });
            }
            return response.json();
        })
        .then(data => {
            // 验证响应数据结构
            if (!data || data.status === undefined) {
                throw new Error('Invalid response format');
            }
    
            if (data.status === 'success') {
                console.log('Directory size:', data);
                let formatsize=formatBytes(data.bytes);
                showAndFadeOut('success', 2000, 3, formatsize || 'No size data');
            } else {
                throw new Error(data.message || 'Operation failed');
            }
        })
        .catch(error => {
            console.error('Error:', error.message);
            showAndFadeOut('error', 3000, 3, `Error: ${error.message}`);
        });
    }
    
    
    function file_open(file_name, filesize) {
        let local_path= document.getElementById('local_path').value;
        let file_complete_path=base_path + local_path + "/" + file_name;
        let file_web_path = file_complete_path.substring(21);
        console.log("file_web_path", file_web_path);
        //显示一个题目，路径
        document.getElementById('main_content_part3').style.display="flex";

        document.getElementById('file_preview_head').innerHTML=("/home/"+local_path+'/'+file_name).replace(/\/+/g, '/')+`<img style='position:relative;left:10px;cursor:pointer;top:3px' src='/000_image/svg_refresh.svg' onclick="file_open2('${file_name}','${local_path}')">`;;
        document.getElementById('file_preview_close').style.display="block";
        //
        var ext = file_name.split('.').pop().toLowerCase();
        //console.log("ext:",ext);
        var file_preview_inner = document.getElementById('file_preview_inner');
        file_preview_inner.innerHTML = ''; // 清空之前的内容
        if (['png', 'jpeg', 'jpg', 'tif', 'svg'].includes(ext)) {
            // 处理图片或 SVG 文件
            var img = document.createElement('img');
            img.src = file_web_path; // 使用完整的文件路径
            img.style.maxWidth = '100%';
            file_preview_inner.appendChild(img);
        } 
        else if (ext === 'pdf') {
            // 处理 PDF 文件
            var pdfEmbed = document.createElement('embed');
            pdfEmbed.src = file_web_path; // 使用完整的文件路径
            pdfEmbed.type = 'application/pdf';
            pdfEmbed.style.width = '100%';
            
            // 动态计算高度
            var viewportHeight = window.innerHeight;
            var offsetHeight = 150; // 需要减去的像素值
            var newHeight = viewportHeight - offsetHeight;
            pdfEmbed.style.height = `${newHeight}px`;
            
            file_preview_inner.appendChild(pdfEmbed);
        } 
        else if (ext === 'html') {
            console.log('展示html');
            fetch(file_web_path)
                .then(response => response.text())
                .then(html => {
                    const blob = new Blob([html], { type: 'text/html' });
                    const blobUrl = URL.createObjectURL(blob);
                    
                    const iframe = document.createElement('iframe');
                    iframe.src = blobUrl;
                    iframe.style.width = '100%';
                    iframe.style.height = `${window.innerHeight - 150}px`;
                    iframe.style.border = 'none';
                    
                    // 可选：页面卸载时释放 blob URL，避免内存泄漏
                    iframe.onload = () => URL.revokeObjectURL(blobUrl);
                    
                    file_preview_inner.appendChild(iframe);
                })
                .catch(error => {
                    console.error('Error loading HTML:', error);
                    file_preview_inner.innerHTML = 'HTML 文件加载失败。';
                });
        }
        else {
            // 处理任何类型的文件
            fetch(`/function_file_preview.php?filename=${encodeURIComponent(file_complete_path)}`)
                .then(response => response.text()) // 直接获取文本内容
                .then(text => {
                    //file_preview_inner.innerHTML = `${text}`;//
                    file_preview_inner.innerHTML = `<pre style="white-space: pre-wrap; text-align: left;">${text}</pre>`;
                    if (text.length >= 104857) {  // 如果内容接近1MB，提示用户1048576
                        file_preview_inner.innerHTML += `<br>文件内容过大，仅显示前 0.1MB 内容。`;
                    }
                })
                .catch(error => {
                    console.error('Error loading file:', error);
                    file_preview_inner.innerHTML = '文件加载失败。';
                });
        }   
    }
    //file_open2刷新用
    function file_open2(file_name,local_path){
        let file_complete_path=base_path + local_path + "/" + file_name;
        let file_web_path = file_complete_path.substring(21);
        console.log("file_web_path", file_web_path);
        //显示一个题目，路径
        document.getElementById('file_preview_head').innerHTML=("/home/"+local_path+'/'+file_name).replace(/\/+/g, '/')+`<img style='position:relative;left:10px;cursor:pointer;top:3px' src='/000_image/svg_refresh.svg' onclick="file_open2('${file_name}','${local_path}')">`;;
        document.getElementById('file_preview_close').style.display="block";
        //
        const ext = file_name.split('.').pop().toLowerCase();
        console.log("ext:",ext);
        const file_preview_inner = document.getElementById('file_preview_inner');
        file_preview_inner.innerHTML = ''; // 清空之前的内容
        if (['png', 'jpeg', 'jpg', 'tif', 'svg'].includes(ext)) {
            // 处理图片或 SVG 文件
            const img = document.createElement('img');
            img.src = file_web_path; // 使用完整的文件路径
            img.style.maxWidth = '100%';
            file_preview_inner.appendChild(img);
        } 
        else if (ext === 'pdf') {
            // 处理 PDF 文件
            const pdfEmbed = document.createElement('embed');
            pdfEmbed.src = file_web_path; // 使用完整的文件路径
            pdfEmbed.type = 'application/pdf';
            pdfEmbed.style.width = '100%';
            
            // 动态计算高度
            const viewportHeight = window.innerHeight;
            const offsetHeight = 150; // 需要减去的像素值
            const newHeight = viewportHeight - offsetHeight;
            pdfEmbed.style.height = `${newHeight}px`;
            
            file_preview_inner.appendChild(pdfEmbed);
        } 
        else if (ext === 'html') {
            console.log('展示html');
            fetch(file_web_path)
                .then(response => response.text())
                .then(html => {
                    const blob = new Blob([html], { type: 'text/html' });
                    const blobUrl = URL.createObjectURL(blob);
                    
                    const iframe = document.createElement('iframe');
                    iframe.src = blobUrl;
                    iframe.style.width = '100%';
                    iframe.style.height = `${window.innerHeight - 150}px`;
                    iframe.style.border = 'none';
                    
                    // 可选：页面卸载时释放 blob URL，避免内存泄漏
                    iframe.onload = () => URL.revokeObjectURL(blobUrl);
                    
                    file_preview_inner.appendChild(iframe);
                })
                .catch(error => {
                    console.error('Error loading HTML:', error);
                    file_preview_inner.innerHTML = 'HTML 文件加载失败。';
                });
        }
        else {
            // 处理任何类型的文件
            fetch(`/function_file_preview.php?filename=${encodeURIComponent(file_complete_path)}`)
                .then(response => response.text()) // 直接获取文本内容
                .then(text => {
                    //file_preview_inner.innerHTML = `${text}`;//
                    file_preview_inner.innerHTML = `<pre style="white-space: pre-wrap; text-align: left;">${text}</pre>`;
                    if (text.length >= 104857) {  // 如果内容接近1MB，提示用户1048576
                        file_preview_inner.innerHTML += `<br>文件内容过大，仅显示前 0.1MB 内容。`;
                    }
                })
                .catch(error => {
                    console.error('Error loading file:', error);
                    file_preview_inner.innerHTML = '文件加载失败。';
                });
        }           
        
    }
    
    function file_preview_close_click(){
        document.getElementById('main_content_part3').style.display="none";
        document.getElementById('file_preview_head').innerHTML='';
        document.getElementById('file_preview_inner').innerHTML = ''; // 清空之前的内容
        document.getElementById('file_preview_close').style.display="none";
    }
    
    // 添加点击事件监听器
    document.querySelectorAll('.file_name').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            var file_name = e.target.dataset.filename;
            var filesize = parseInt(e.target.dataset.filesize, 10); // 获取文件大小
            file_open(file_name, filesize);
        });
    });

    
    function file_operate(operate,file_type,file_name,file_name_new_object){
        console.log(operate,file_type,file_name);
        if(operate=="新建文件"||operate=="新建文件夹"){}
        
        if(operate=="删除"||operate=="复制"||operate=="压缩"){
            if(confirm("你确定要执行 " + operate + " 操作吗？")==false){
                return false;
            }; 
        }
        
       
        let file_name_new='';
        if(operate=="重命名"){
            if(file_name_new_object.value==''){
                file_name_new_object.value=file_name;
                showAndFadeOut('error', 2000, 3,"重命名不能为空"); 
                return false;
            }
            else{
                file_name_new=file_name_new_object.value;
            }
        }
        
        let local_path=document.getElementById('local_path').value;
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'file_type':file_type,
                'file_name':file_name,
                'file_name_new':file_name_new,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });       
    };
    
    function copy_str(text) {
        // 创建一个不可见的 textarea 元素
        const textArea = document.createElement("textarea");
        textArea.value = text;
    
        // 使 textarea 不可见，但依然可以选择文本
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
    
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
    
        try {
            // 执行复制命令
            const successful = document.execCommand('copy');
            const msg = successful ? '成功' : '失败';
            console.log('文本复制' + msg);
            showAndFadeOut('success', 2000, 3,"已经将文字复制到剪切板，使用ctrl+V进行粘贴");
            //alert('已复制到剪贴板: ' + text);
        } catch (err) {
            console.error('复制文本失败', err);
            showAndFadeOut('error', 2000, 5,error);
        }
    
        // 移除 textarea 元素
        document.body.removeChild(textArea);
    }
    function code_editor_generate(file_path,file_name){
        console.log(file_path,file_name);
        
        editor_start(file_path,file_name,"<?php echo $select_theme_TXT;?>","<?php echo $select_wrap_TXT;?>");
    }
    function file_operate_multi(operate){    /*用于批量删除和批量压缩*/
        console.log(operate);
        let all_checkbox_value=Array.from(checkboxValuesSet).join('_;;;_');
        let local_path=document.getElementById('local_path').value;
        if(all_checkbox_value==""){
            showAndFadeOut('error', 2000, 3,"需要选中至少一个文件/文件夹");return false;
        }
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'all_checkbox_value':all_checkbox_value,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });  
    }
    function file_operate_multi_mv(operate){    /*仅用于剪切功能*/
        console.log(operate);
        let all_checkbox_value=document.getElementById('all_checkbox_value').value;
        let all_checkbox_value_localpath=document.getElementById('all_checkbox_value_localpath').value;
        let local_path=document.getElementById('local_path').value;
        if(all_checkbox_value==""){
            showAndFadeOut('error', 2000, 3,"需要选中至少一个文件/文件夹");return false;
        }
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'all_checkbox_value':all_checkbox_value,
                'all_checkbox_value_localpath':all_checkbox_value_localpath,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });  
    }
    
    //处理错误/成功/tip信息
    // 渐显并渐隐函数
    /*
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        var div = document.getElementById("top_message");
        let message_text_new='';
        if (message_type == "error") {      
                div.style.backgroundColor = "rgb(255, 255, 153)";  message_text_new="<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> "+message_text;  } 
        else if (message_type == "success") {
                div.style.backgroundColor = "#e5ffe5"; message_text_new="<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> "+message_text;}
        else {div.style.backgroundColor = "gray"; }
        div.innerHTML = message_text_new;
        if (div) {
            div.style.display = 'block'; // 使div可见
            div.style.opacity = 1; // 将透明度设为 1 (完全可见)
            
            // 延时后开始渐隐
            setTimeout(function() {
                div.style.transition = `opacity ${fadeDuration}s ease-in-out`;
                div.style.opacity = 0; // 开始渐隐
                
                // 渐隐完成后隐藏元素
                setTimeout(function() {
                    div.style.display = 'none';
                }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
            }, delayBeforeFade);
        }
    }*/
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        // 创建新的消息元素
        var div = document.createElement("div");
        div.className = "message-box"; // 应用样式类
    
        let message_text_new = '';
        
        // 根据消息类型设置背景颜色和内容
        if (message_type == "error") {
            div.style.backgroundColor = "rgb(255, 255, 153)";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> " + message_text;
        } else if (message_type == "success") {
            div.style.backgroundColor = "#e5ffe5";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> " + message_text;
        } else if (message_type == "warn") {
            div.style.backgroundColor = "#ffff99";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_warn.svg'> " + message_text;            
        } else {
            div.style.backgroundColor = "gray";
            message_text_new = message_text;
        }
    
        div.innerHTML = message_text_new;
        div.style.transition = `opacity ${fadeDuration}s ease-in-out`; // 动态设置渐隐时长
    
        // 将新的消息元素添加到 body
        document.body.appendChild(div);
    
        // 动态调整所有消息的 vertical 位置，防止重叠
        adjustMessagesPosition();
    
        // 延时后开始渐隐
        setTimeout(function() {
            div.style.opacity = 0; // 开始渐隐
            
            // 渐隐完成后移除元素
            setTimeout(function() {
                document.body.removeChild(div);
                adjustMessagesPosition(); // 调整剩余消息的位置
            }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
        }, delayBeforeFade);
    }
    // 动态调整所有消息的位置，防止重叠
    function adjustMessagesPosition() {
        var messages = document.querySelectorAll('.message-box'); // 选择所有消息元素
        let currentTop = 0; // 从顶部开始，预留一些空间
    
        messages.forEach(message => {
            message.style.top = `${currentTop}px`;
            currentTop += message.offsetHeight + 2; // 累加消息高度和间距
        });
    }
    
    //显示与隐藏
        let currentObjectId = null;

        function show_and_hide(object_id) {
            var dropArea = document.getElementById(object_id);
            var isVisible = dropArea.style.display === 'block';

            // Update currentObjectId
            currentObjectId = object_id;

            dropArea.style.display = isVisible ? 'none' : 'block';
        }

        document.addEventListener('click', function(event) {
            // Ensure currentObjectId is valid
            if (currentObjectId) {
                var dropArea = document.getElementById(currentObjectId);

                // Check if the click was outside the drop area
                if (!dropArea.contains(event.target) && event.target.closest('.toggle-btn') === null) {
                    dropArea.style.display = 'none';
                    currentObjectId = null; // Reset currentObjectId
                }
            }
        });
    
    
    
    
    //复选框
    function all_checkbox_click(){
        let all_checkbox_state_old = document.getElementById("all_checkbox_state").value;
        let all_checkbox_state_new='';
        if (all_checkbox_state_old==0){     all_checkbox_state_new=1;}
        else{                               all_checkbox_state_new=0;}
        document.getElementById("all_checkbox_state").value=all_checkbox_state_new;
        console.log("所有复选框state:",all_checkbox_state_old,"变为",all_checkbox_state_new);
        let select_checkboxes = document.querySelectorAll('.select_checkbox');
        if (all_checkbox_state_new==1){
            select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = true;
                checkboxValuesSet.add(checkbox.value);  // 将值添加到 Set 中
            });
        }
        else{
             select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = false;
            });
            checkboxValuesSet.clear();  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}

    }
    
    function one_checkbox_click(this_checkbox) {
        // 检查当前复选框的状态
        if (this_checkbox.checked) {
            checkboxValuesSet.add(this_checkbox.value);  // 将值添加到 Set 中
        }
        else{
            // 如果当前复选框不是选中的状态，则将 all_checkbox_state 设为 0
            document.querySelector('#all_checkbox_state').value=0;
            document.querySelector('#all_checkbox').checked = false;
            checkboxValuesSet.delete(this_checkbox.value);  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}
    }
    

     
    /*批量剪接功能*/
    function collect_checkboxs(){
        console.log("collect_checkboxs");
        console.log(checkboxValuesSet);
        let checkboxValuesSet_num=checkboxValuesSet.size;
        // 初始化计数器  
        let fileCount = 0;  let folderCount = 0;  
        checkboxValuesSet.forEach(item => {  
            let [name, type] = item.split('_||_');  
            if (type === '文件') {  fileCount++;  } 
            else if (type === '文件夹') {  folderCount++;  }  
        });  
        if(checkboxValuesSet_num==0){
            document.getElementById("all_checkbox_value").value='';
            document.getElementById("all_checkbox_value_localpath").value= '';           
            document.getElementById("collect_num_show").innerText=``;
            showAndFadeOut('error', 2000, 3,"请至少选择一个复选框");return false;
        }
        else{
            showAndFadeOut('success', 2000, 3,`选择了${folderCount}文件夹，选择了${fileCount}个文件`);
        }
        //SET转str
        let checkboxValuesSet_str = Array.from(checkboxValuesSet).join('_;;;_');
        document.getElementById("all_checkbox_value").value=checkboxValuesSet_str;
        document.getElementById("all_checkbox_value_localpath").value=document.getElementById('local_path').value;
        document.getElementById("collect_num_show").innerText=`选中${checkboxValuesSet_num}`;
        checkboxValuesSet.clear();
    }
    function collect_checkboxs_mvfile(){
        console.log("collect_checkboxs_mvfile");
        let all_checkbox_value=document.getElementById("all_checkbox_value").value;
        let all_checkbox_value_localpath=document.getElementById("all_checkbox_value_localpath").value;
        let local_path=document.getElementById("local_path").value;
        console.log(all_checkbox_value,all_checkbox_value_localpath,local_path);
        if(all_checkbox_value==''){showAndFadeOut('error', 2000, 3,"尚未剪切文件，请勾选复选框后点击剪刀图标");return false;}
        if(all_checkbox_value_localpath==local_path){showAndFadeOut('error', 2000, 3,"剪切文件后，需要粘贴至新目录");return false;}
        //判断父文件夹剪切后，自己下级粘贴的情况
        let all_checkbox_arr = all_checkbox_value.split('_;;;_');  
        for (let item of all_checkbox_arr) {
            let [name, type] = item.split('_||_');  
            console.log(local_path, all_checkbox_value_localpath + name);
            if (type === "文件夹" && local_path.startsWith(all_checkbox_value_localpath + name)) {
                showAndFadeOut('error', 2000, 3, "无法将文件夹剪切至其自身内部");
                return false;  // 退出函数，阻止后续代码执行
            }
        }
        //
        file_operate_multi_mv('批量移动');
        document.getElementById("collect_num_show").innerText=``;
    }
</script>


<script>
    const userid='<?php echo $user_name_id;?>';
    function get_job_state(){
        console.log('get_job_state');
        fetch('function_progress_getinfo.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            show_jobs();
            //showAndFadeOut('success', 2000, 5,raw_result);
            //console.log('function_progress_getinfo存入数据库的内容：',raw_result);
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
        
    }

    
    function getCurrentTime() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需+1
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
    function progress_refresh_click(){
        let current_time=getCurrentTime();
        document.getElementById('progress_refresh_time').innerText=current_time;
        get_job_state();
    }
    
    function show_jobs(){
        console.log('show_jobs');
        fetch('function_progress_getmysql.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log('function_progress_getmysql：',raw_result);
            let result_json=raw2json(raw_result);
            visual_result_json(result_json);
            
            //showAndFadeOut('success', 2000, 5,raw_result);
            
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
    //将后端的字符串转化为task——信息|作业内容———信息的三层格式（json）
    function raw2json(raw_array){
        const result = {};
        raw_array.forEach(one => {
            // 解构赋值
            const {
                '作业层级': jobLayer,
                '作业编号': jobId,
                '作业slurm编号': slurmId,
                '创建时间': createTime,
                '开始时间': startTime,
                '中间状态': mid_state, // 正确解构中文属性名
                '结束时间': endTime,
                '更新时间': updateTime,
                '使用时间': usedTime,
                '状态': status,
                '拥有者': owner,
                '文件目录': FileDir,
                '项目编号': projectId,
                '任务编号': taskId,
                '模块编号': moduleId,
                '模块名称': moduleName,
                '样本名称':sampleName,
                '步骤数量': stepCount,
            } = one;
            let jobId_belong= jobId.split("_")[0];
            if (!result[taskId]) {
              result[taskId] = {};
              result[taskId]['总创建时间']=createTime;
              result[taskId]['文件目录']=FileDir;
              result[taskId]['项目编号']=projectId;
              result[taskId]['模块编号']=moduleId;
              result[taskId]['模块名称']=moduleName;
              result[taskId]['作业内容']={};
            }
            if (!result[taskId]['作业内容'][jobId_belong]){
                result[taskId]['作业内容'][jobId_belong]={}
            }
            if (!result[taskId]['作业内容'][jobId_belong][jobId]){
                result[taskId]['作业内容'][jobId_belong][jobId]={}
            }

            result[taskId]['作业内容'][jobId_belong][jobId]['作业slurm编号']=slurmId;
            result[taskId]['作业内容'][jobId_belong][jobId]['创建时间']=createTime;
            result[taskId]['作业内容'][jobId_belong][jobId]['开始时间']=startTime;
            result[taskId]['作业内容'][jobId_belong][jobId]['中间状态']=mid_state;
            result[taskId]['作业内容'][jobId_belong][jobId]['结束时间']=endTime;
            result[taskId]['作业内容'][jobId_belong][jobId]['更新时间']=updateTime;
            result[taskId]['作业内容'][jobId_belong][jobId]['状态']=status;
            result[taskId]['作业内容'][jobId_belong][jobId]['步骤数量']=stepCount;
            result[taskId]['作业内容'][jobId_belong][jobId]['使用时间']=usedTime;
        });
        //console.log('raw2json',result);
        return result;
    }
    //将json对象可视化
    function visual_result_json(result_json) {
        const container = document.getElementById('progress_manager_content_div_inner');container.innerHTML = '';
        
        Object.entries(result_json).forEach(([taskId, taskData]) => {
            const {
                '总创建时间':task_create_time,
                '文件目录': FileDir,
                '项目编号': projectId,
                '模块编号': moduleId,
                '模块名称': moduleName,
                '作业内容': jobContents,
            } = taskData;
            let project_dir=FileDir+'/log_'+projectId;
            let task_dir=project_dir+'/'+taskId;
            //回到网站目录，
            let website_path="user/<?php echo $user_name_id;?>/"+task_dir;   //去掉前三级目录，即去掉去掉/www/wwwroot/bioslurm/
            
            //创建一个hide input到dom，先检测是否有同id存在
            let hiddenInput = document.getElementById('end_state_hidden_'+taskId);
            if (!hiddenInput) {
              // 如果不存在，则创建并添加到 DOM（例如添加到 <body> 或某个容器）
              hiddenInput = document.createElement("input");
              hiddenInput.type = "hidden";
              hiddenInput.id = 'end_state_hidden_'+taskId;
              hiddenInput.value = "inshow";
              document.body.appendChild(hiddenInput);
            }
            
            //检测当前的hide input状态
            let change_ends_state_label='';
            if (hiddenInput.value=='inhide'){change_ends_state_label='ShowENDs';}
            else{change_ends_state_label='HideENDs';}
            
            // 创建任务主容器
            const taskElement = document.createElement('div');
            taskElement.classList.add('progress_one_task');
            taskElement.innerHTML = `
                <div>
                    <div style='display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;'>
                        <div style='border:solid 0px grey;padding:2px 5px;width:310px;background-color:#336699;color:white'>
                            <span onclick="dirurl_jumpinto('${project_dir}','is_backforward');">${projectId}</span> ➡︎ <span onclick="dirurl_jumpinto('${task_dir}','is_backforward');">${taskId}</span>
                        </div> 
                        <div style='background-color: grey;width:100px;height:1px'></div>
                        <div class='progress_one_task_button' onclick="Clear_onetask('StopAll','${taskId}');">StopAll</div>
                        <div class='progress_one_task_button' onclick="change_ends_state('${taskId}');" id="ends_state_button_${taskId}">${change_ends_state_label}</div>
                        
                        <div class='progress_one_task_button' onclick="Clear_onetask('ClearALL','${taskId}');">ClearALL</div>
                    </div>    
                    <div>
                        <table class='progress_one_task_table1'>
                            <tr><td>创建时间</td><td>${task_create_time}</td></tr>
                            <tr><td>文件目录</td><td onclick="dirurl_jumpinto('${FileDir}','is_backforward');" class='progress_one_task_table1_dir'>${FileDir}</td></tr>
                            <tr><td>使用模块</td><td ><span style='font-weight:bold;color:#cc0066'>${moduleName}</span> <span style='color:#336699'>[${moduleId}]</span></td></tr>    
                        </table>
                    </div>
                    <div class='progress_one_task_table2' id='job_${taskId}'>
                        <!-- 子作业表格将在这里添加 -->
                    </div>
                </div>
            `;
            container.appendChild(taskElement);
            
            
    
            let HideENDs_state=document.getElementById('end_state_hidden_'+taskId).value;
            let system_mark_style='';
            if (HideENDs_state=='inshow'){system_mark_style='table-row';}
            else if (HideENDs_state=='inhide'){system_mark_style='none';}
           
            
            // 遍历作业内容（按 jobId_belong 分组）
            const jobContainer = document.getElementById(`job_${taskId}`);jobContainer.innerHTML = '';
            Object.entries(jobContents).forEach(([jobIdBelong, jobs]) => {
                // 创建作业组容器
                const jobGroupElement = document.createElement('div');
                jobGroupElement.className = 'progress_job_group';
                jobGroupElement.innerHTML = `
                    <div style='font-weight:bold;padding:5px'>${jobIdBelong}</div>
                    <div>
                        <table id="job_group_${taskId}_${jobIdBelong}">
                            
                        </table>
                    </div>
                `;
                jobContainer.appendChild(jobGroupElement);
    
                // 遍历该组下的所有作业
                let no_ENDs_num=0;
                const jobGroupContent = document.getElementById(`job_group_${taskId}_${jobIdBelong}`);jobGroupContent.innerHTML = '';
                Object.entries(jobs).forEach(([jobId, jobData]) => {
                    const {
                        '作业slurm编号': slurmId,
                        '状态': status,
                        '创建时间': createTime,
                        '开始时间': startTime,
                        '结束时间': endTime,
                        '更新时间': updateTime,
                        '中间状态': midState,
                        '步骤数量':stepCount,
                        '使用时间':usedTime
                    } = jobData;
                    //解析中间状态
                    let mid_html='';
                    if (jobId.includes("_")) {
                        mid_html=`<div style='background-color: grey;width:20px;height:1px'></div>`;
                        if(midState && midState!='.'){
                            let midState_arr=midState.split('_;;;_');let midState_arr_num=midState_arr.length;
                            midState_arr.forEach((element, index) => {
                                //console.log(`元素 ${index + 1}:`, element);
                                let element_arr=element.split('||');
                                let element_time=element_arr[0];
                                let element_name=element_arr[1];
                                if (status=='mid' && midState_arr_num==index + 1){      mid_html+=` <div class='midState_one_active'><div class='midState_one_dropdown'>${element_time}<br><span>${element_name}</span></div></div>`;}
                                else if (status=='die' && midState_arr_num==index + 1){      mid_html+=` <div class='midState_one_die'><div class='midState_one_dropdown'>${element_time}<br><span>${element_name}</span></div></div>`;}                                
                                else{                                                   mid_html+=` <div class='midState_one'><div class='midState_one_dropdown'>${element_time}<br><span>${element_name}</span></div></div>`;}
                                
                            });
                            let blank_step_num=stepCount-midState_arr_num;
                            if (blank_step_num!=0){
                                //console.log(stepCount,midState_arr_num);
                                for (let i = 0; i < blank_step_num; i++) {
                                    mid_html+=`<div class='midState_one_blank'></div>`;
                                }
                            }
                        } 
                        else{mid_html+=`<div class='midState_one_blank'></div>`;}
                    }    
                    // 创建作业行
                    const jobRow = document.createElement('tr');
                    let usedTime_show='';
                    if (status=='end'){jobRow.style.display = system_mark_style;usedTime_show=" ("+usedTime+")"; }
                    else{no_ENDs_num++;}
                    jobRow.classList.add(taskId);
                    jobRow.classList.add(status);
                    jobRow.innerHTML = `
                            <td class='jobid_label' onclick="code_editor_generate('${website_path}','${jobId}.sh')" style='width:90px;min-width:90px'>${jobId} <span style='font-size:9px'>[${slurmId}]</span></td> 
                            <td> <img  style='height:15px;width:15px' src='/000_image/svg_button_log1.svg'  onclick="code_editor_generate('${website_path}','${jobId}.log')"> </td> 
                            <td><img  style='height:15px;width:15px' src='/000_image/svg_button_log2.svg'  onclick="code_editor_generate('${website_path}','${jobId}.err')"> </td> 
                            <td class='midstate_container'>
                                ${mid_html}
                                <div class='midstate_container_shortline'></div>
                                <div class='job_status_container'>${status}${usedTime_show}
                                    <div class='job_status_container_dropdown'>
                                        <b style='color:black'>当前状态: ${status}</b><br>
                                        创建时间: ${createTime}<br>
                                        开始时间: ${startTime}<br>
                                        结束时间: ${endTime}<br>
                                        更新时间: ${updateTime}
                                    </div>
                                </div>
                            </td> 
                            <td><div class='slurm_control_container' style='display:flex;display:-webkit-flex;justify-content:flex-start;flex-wrap: nowrap;align-items:center;max-height:20px;height:20px;margin-left:20px;' id='slurm_control_${slurmId}'></div></td>
                            
                    `;
                    jobGroupContent.appendChild(jobRow);
                });
                
                //
                if(no_ENDs_num==0 && HideENDs_state=='inhide'){jobGroupElement.style.display='none';}
            });
        });
        
        bind_slurm_switch();
    }
    function change_ends_state(taskId){
        console.log('change_ends_state');
        let hiden_input=document.getElementById("end_state_hidden_"+taskId);
        let old_state= hiden_input.value;
        if (old_state=='inshow')    {       hiden_input.value='inhide'; }
        else if (old_state=='inhide'){      hiden_input.value='inshow'; }
        progress_refresh_click();
    }
    
    function Clear_onetask(action,taskid){
        console.log('ClearENDs/ShowENDs/StopAll');
        fetch('function_progress_clear.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':action,
                'userid':userid,
                'taskid':taskid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log('function_progress_clear：',data);
            progress_refresh_click();
            if(action=='ClearENDs'){showAndFadeOut('success', 2000, 5,`清空${taskid}已结束jobs`);}
            if(action=='StopAll'){showAndFadeOut('success', 2000, 5,`清空${taskid}所有jobs`);}
            //console.log('function_progress_getmysql：',raw_result);
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
    
    function bind_slurm_switch(){
        console.log('bind_slurm_switch');
        fetch('function_progress_getslurm.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log('bind_slurm_switch：',raw_result);
            let raw_result_arr=raw_result.split('\n');
            raw_result_arr.forEach((one_result, index) => {
                if (index === 0) return; // 跳过第一行（索引 0）
                if (!one_result) return;
                let one_result_arr=one_result.replace(/\s+/g, ' ').trim().split(' ');
                //console.log(one_result_arr);
                const [slurmid,jobName,wwwuser,status,node,thread,run_time,info_raw] = one_result_arr;
                //const info = info_raw.replace(/^\(|\)$/g, "");
                if (!jobName.endsWith(userid)){return;}

                // 获取目标元素
                const controlElement = document.getElementById(`slurm_control_${slurmid}`);
                let innerHTML_txt='';
                // 检查元素是否存在，再操作 innerHTML
                if (controlElement) {
                    let slurm_handle_str='';
                    if (status=='R'){slurm_handle_str = `
                        <div class='slurm_real_controls_one' onclick="slurm_handle('scancel','${slurmid}')"><img src='/000_image/svg_slurm_close.svg'></div>`;
                    }
                    /*suspend似乎需要的权限比scancel更高
                    if (status=='R'){slurm_handle_str = `
                        <div class='slurm_real_controls_one' onclick="slurm_handle('suspend','${slurmid}')"><img src='/000_image/svg_slurm_suspend.svg'></div>
                        <div class='slurm_real_controls_one' onclick="slurm_handle('scancel','${slurmid}')"><img src='/000_image/svg_slurm_close.svg'></div>`;
                    }
                    else if(status=='S'){slurm_handle_str = `
                        <div class='slurm_real_controls_one' onclick="slurm_handle('resume','${slurmid}')"><img src='/000_image/svg_slurm_suspend.svg'></div>
                        <div class='slurm_real_controls_one' onclick="slurm_handle('scancel','${slurmid}')"><img src='/000_image/svg_slurm_close.svg'></div>`;
                    }*/
                    else{slurm_handle_str = `
                        <div class='slurm_real_controls_one' onclick="slurm_handle('scancel','${slurmid}')"><img src='/000_image/svg_slurm_close.svg'></div>`;
                    }
                    innerHTML_txt=`<div class='slurm_real_state'>${status} <span style='color:white'>·</span> n=${thread} <span style='color:white'>·</span> ${run_time}</div><div class='slurm_real_controls'>${slurm_handle_str}</div>`;
                    
                    controlElement.innerHTML=innerHTML_txt;
                }
            })
            //showAndFadeOut('success', 2000, 5,raw_result);
            
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
    
    
    function slurm_handle(action,slurmid){
        console.log('slurm_handle',action,slurmid);
        fetch('function_progress_RUNslurm.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
                'action':action,
                'slurmid':slurmid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log('slurm_handle：',data);
            progress_refresh_click();
            //showAndFadeOut('success', 2000, 5,raw_result);
            
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
</script>

<script>
    progress_refresh_click();
    let pollInterval = 3000; // 3秒轮询间隔
    let pollTimer = null;
    let inactivityTimeout = 60000 ; // 1分钟无操作超时
    let inactivityTimer = null;
    let lastActivityTime = Date.now();
    
    // 轮询函数
    function startPolling() {
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(() => {
        progress_refresh_click();
      }, pollInterval);
      console.log("Polling started.");
    }
    
    // 暂停轮询
    function stopPolling() {
      if (pollTimer) {
        clearInterval(pollTimer);
        pollTimer = null;
        console.log("Polling stopped.");
      }
    }
    
    // 检测用户活动
    function resetInactivityTimer() {
      lastActivityTime = Date.now();
      if (inactivityTimer) clearTimeout(inactivityTimer);
      
      // 如果页面不可见，不重启轮询（等待页面恢复）
      if (document.hidden) return;
      
      // 重启轮询（如果之前被暂停）
      if (!pollTimer) {
        startPolling();
      }
      
      // 设置无操作超时检测
      inactivityTimer = setTimeout(() => {
        const idleTime = Date.now() - lastActivityTime;
        if (idleTime >= inactivityTimeout && !document.hidden) {
          stopPolling();
          console.log("Polling paused due to inactivity.");
        }
      }, inactivityTimeout);
    }
    
    // 初始化轮询
    startPolling();
    
    // 监听页面可见性变化
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        stopPolling();
        console.log("Polling paused (page hidden).");
      } else {
        resetInactivityTimer(); // 页面恢复时重置活动状态
      }
    });
    
    // 监听用户活动（鼠标、键盘、触摸等）
    const activityEvents = ["mousedown", "mousemove", "keypress", "scroll", "touchstart"];
    activityEvents.forEach(event => {
      window.addEventListener(event, resetInactivityTimer);
    });
    
    // 初始设置无操作超时
    resetInactivityTimer();
</script>




    
    
    














