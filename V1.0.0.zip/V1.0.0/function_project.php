<?php    
    session_start(); // 开始会话
    //var_dump($_SESSION['user_name_id']);die();
    if (isset($_SESSION["user_uuid"])  &&  isset($_SESSION["user_email"]) &&  isset($_SESSION["user_name"])  &&  isset($_SESSION["user_name_id"])) {
        $navi_user_state= "
            <span style='font-size:xx-small;margin-left:50px'>欢迎, </span>{$_SESSION['user_name']}<span style='font-size:xx-small'> [{$_SESSION['user_email']}] </span> 
            <div style='display:inline-block'>
                <form  action='index.php' method='post'>
                    <input type='hidden'  name='action' ID='action' value='logout'></input><button id='logout'>[退出]</button>
                </form>    
            </div> ";
        
    }
    else{
        header("Location: index.php");  
        exit; // 确保重定向后停止脚本执行  
    }    
   
    $user_name_id=$_SESSION['user_name_id'];
    $base_path = "/www/wwwroot/bioslurm/user/{$user_name_id}";  
    if (is_dir($base_path)==false)  {  echo "用户未初始化，用户文件夹不存在。";  die();} 
    
    $searchword='';
    if (isset($_GET["searchword"]) && $_GET["searchword"] !== ''){
        //if(strpos($_GET["searchword"], "script_") === 0){
            $searchword=$_GET["searchword"];//var_dump($_GET["searchword"] );
            //echo "searchword".$searchword; 
        //}
    }    
    else{$searchword='';}

    
    //链接数据库，获取用户的设置
    include 'database_connect.php'; 
    $sql = "SELECT * FROM 用户信息 WHERE 用户名自动生成 = ?";
    $params =[ ['type' => 's', 'value' => $user_name_id]]; // 's' 表示字符串类型
    $rows = database_query($conn, $sql, $params);   //这里我自定义了数据库的逻辑，极大减轻工作量
    $select_theme_TXT=$rows[0]['设置_文本编辑器'];
    $select_wrap_TXT=$rows[0]['设置_文本编辑器_自动换行'];
?>


<!DOCTYPE  html>
<html  lang="en">
<head>
    <meta  charset="UTF-8">
    <meta  name="viewport"  content="width=device-width,  initial-scale=1.0">
    <title>BioSlurm生信服务器</title>
    <meta name="keywords" content="BioSlurm生信服务器">
    <meta name="description" content="BioSlurm生信服务器" >
    <link rel="icon" href="000_image/favicon.png" type="image/png">     
    
    
    <link rel="stylesheet" href="plug/monaco_editor/DIY/editor.css">
    
    <style>

        * {box-sizing: border-box;margin:0;padding:0;}
        body {font-family: sans-serif;min-width:300px;background-color: rgba(0,0,0,0.06);}/*background-color: rgba(0,0,0,0.03);*/
        div {user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; }
        .flex_div{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;}
        #top_navigator {position:fixed;top:0;width: 100%;background-color:#005580;padding:4px;margin:0 0 auto 0;height:30px;color:white;z-index:111111}
        #top_navigator a{color:white; text-decoration:none; margin:0 10px;font-size:17px;}
        #top_navigator a:hover{color:#ffff99}
        #top_navigator_title_name{font-weight:500;text-shadow: 0 0 1px black, 1px 1px 5px black;}
        #top_navigator_current_time{font-size:xx-small}
        #logout{background: none;border:none;padding: 0;font: inherit;cursor: pointer; color: rgb(200,200,200);outline: none;display:inline-block; font-size:xx-small; }
        #logout:hover{color:red}
        
        

        #easylink_div{position:fixed;left:0;top:0;height:100%;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;background-color:rgba(0, 0, 0,0.1);padding:70PX 0 20px 0;z-index:1}
        .function_link_div{display:block;width:40px;height:40px;margin:5px 10px;border:solid 0px grey;border-radius:5px;background-color:#e6e6e6;cursor:pointer;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;position: relative; 
        }
        .function_link_div:hover{background-color:white;}
        .function_link_div_dropdown{position: absolute;top:100%;left:1px;font-size:10px;opacity:0;width:100px;color:grey;z-index:100;transition: opacity 1s cubic-bezier(0.68, -0.55, 0.27, 1.55);}
        .function_link_div:hover .function_link_div_dropdown{opacity:1}
        .select_div{background-color:#fafafa;position: relative; }
        .select_div:after{
            content: '';  
            position: absolute;  
            right: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-left: 8px solid #fafafa; }
        .select_div:hover:after{border-left: 8px solid white}
        
        #main_content{margin:50px 25px 20px 75px;border:solid 0px red;transition:1s;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:flex-start}
        #main_content_part1{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s;flex:none;transition:1s}

        #file_manager{position:relative}
        #file_manager_head{color:#cc0066;font-size:20px;font-weight:bold;margin-bottom:20px;}
        #projectdir_mark_div{position:absolute;left:90px;top:1px}
        #projectdir_mark_div2{display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:left;align-items:top}
        #projectdir_mark_div_icon{position:relative;top:2px;left:7px}
        #projectdir_mark_div_icon_dropdown{display:none;position:absolute;top:23px;left:3px;font-size:xx-small;transition:0.3s;width:400px;color:#d81e06}
        #projectdir_mark_div_icon:hover #projectdir_mark_div_icon_dropdown{display:block}
        #projectdir_mark_div_right{display:none}
        #projectdir_mark_div_content{display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:left;align-items:center;padding:0px 6px 0px 6px;}
        #projectdir_mark_div_content>div{height:25px;color:#d81e06;padding:5px 7px;font-size:xx-small;cursor:pointer;border-radius:5px;margin:0 2px}

        #projectdir_mark_div_content:hover #projectdir_mark_div_close{display:block}
        #projectdir_mark_div_txt{max-width:400px;min-width;100px;;}        #projectdir_mark_div_txt:hover{background-color:#d81e06;color:white}
        #projectdir_mark_div_close {display:none;width;100px;}             #projectdir_mark_div_close:hover{background-color:#d81e06;color:white}
        
        
        #file_manager_path_all{position:relative}
        .file_manager_path{border:solid 0px blue;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:flex-start;;align-items:flex-start;}
        .file_manager_path_button{width:25px;height:25px;border:solid 1px #e6e6e6;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;user-select: none;cursor:pointer;}
        .file_manager_path_button:hover{background-color:#e5f2ff}
        .file_manager_path_button:active{background-color:#cc99ff}
        /**/
        .file_manager_path_classpath{display:flex;display:-webkit-flex;justify-content:flex-start;align-items:flex-start;;font-size:small;;user-select:none ;max-width:400px;min-width:400px;white-space: nowrap;flex-wrap: nowrap;position:relative;}
        
        .file_manager_blocks_click_region{min-width:400px;max-width:400px;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:flex-start;align-items:flex-start;;}

        .file_manager_path_classpath_each{height:25px;border:solid 0px red;display:inline-flex;;flex-wrap:nowrap;justify-content:center;align-items:center;cursor:pointer;}
        .file_manager_path_classpath_each_1{height:25px;transition:0.9s;padding:3px 5px 0 5px;border-left:solid 1px rgba(150, 150, 150,0)}
        .file_manager_path_classpath_each_2{height:25px;transition:0.9s;padding-top:3px;text-align:center;width:12px;border-left:solid 1px rgba(150, 150, 150,0);border-right:solid 1px rgba(150, 150, 150,0);position:relative}
        .file_manager_path_classpath_each:hover  .file_manager_path_classpath_each_1{background-color:#669999;transition:0.2s;border-left:solid 1px rgba(150, 150, 150,0.2)}
        .file_manager_path_classpath_each:hover  .file_manager_path_classpath_each_2{background-color:#d1e0e0;transition:0.2s;border-left:solid 1px rgba(150, 150, 150,0.2);border-right:solid 1px rgba(150, 150, 150,0.2)}
        .file_manager_path_classpath_each_2_dropdown{position:absolute;top:25px;left:0;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;;display:none;background: #e5f2ff;box-shadow: 2px 2px 7px 1px rgba(0,0,0,0.5);z-index:9999;}
        .file_manager_path_classpath_each_2:hover .file_manager_path_classpath_each_2_dropdown{display:block}
        .file_manager_path_classpath_each_2_dropdown div{cursor:pointer;padding:2px 5px; margin: 0;font: x-small;;border:solid 1px #d9e6f2}
        .file_manager_path_classpath_each_2_dropdown div:hover{background-color:rgba(51, 102, 153,0.5);}
        .file_manager_path_classpath_each_2_dropdown div:active{background-color:rgba(204, 153, 255,0.5);}
        
        
        #file_manager_content{min-height:500px}
        #file_manager_path2{position:absolute;left:0;top:0;height:23px;width:100%;background-color:white;z-index:-1;}
        #file_manager_path2_input{width:100%;background: none;border: none;padding: 0 15px 0 0; margin: 0;font: inherit;color: inherit;text-decoration: none;cursor: text;outline: none;position:relative;top:0px;line-height:1;height:24px}
        #file_manager_center_front{position:absolute;left:0;top:0;height:25px;width:400px;border-top:solid 1px #e6e6e6;;;border-bottom:solid 1px #e6e6e6;;z-index:9999;pointer-events: none;}
        #file_manager_center_back{position:absolute;left:0;top:0;height:25px;width:400px;background-color:	 #f3f7f7;z-index:-9999;pointer-events: none;}
        .table_top_function{float:right;}
        .table_top_function>div{display:inline-block}
        
        .table_top_button{height:22px;width:22px;display:inline-block}
        .file_table{margin:30px 0;border-collapse: collapse;background-color:white;font-size:small;z-index:1;min-width:490px;max-width:490px;width:490px}
        .file_table th{background-color:rgba(51, 102, 153,0.3);user-select: none;font-size:normal}
        .file_table th, .file_table td {
            padding: 2px 4px;
            border-bottom: 1px solid #ddd;
            text-align: left;white-space: nowrap;
        }
        .file_table tr:nth-child(even) {background-color: rgba(0, 0, 0,0.03);}
        #new_folder_tr,#new_file_tr{;display:none}
        #new_folder_tr td,#new_file_tr td{background-color: rgba(0, 153, 153,0.3);}
        #new_folder_tr input,#new_file_tr input{background:transparent;border: none;padding: 2px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;width:100%}
        .file_table tr:not(:first-child):hover {background-color:rgba(0, 102, 102,0.2)}
        .file_table td{color:grey}
        .file_name{cursor:pointer;padding-right:20px;color:black}
        .file_name:hover{color:#ff0066}
        .file_name_rename{display:none}
        .file_name_td{max-width:200px;overflow:hidden;;white-space: nowrap}
        .file_name_td:hover{overflow:auto;} 
        .refresh_time {  color: red; animation: fadeToBlack 1s forwards;}  
        @keyframes fadeToBlack {  from { color: red;}  to {  color: black;}  }
        
        .file_filesize_td{max-width:100px;overflow:hidden;;white-space: nowrap}
        .file_filesize_td:hover{overflow:auto;} 
        .file_updateTime_td{max-width:150px;overflow:hidden;;white-space: nowrap}        
        .file_updateTime_td:hover{overflow:auto;} 
        .link_setting{position:relative;display:inline-block;text-align:center}
        .link_setting_editor{text-decoration:none;display:inline-block;}
        .link_setting_editor_img{visibility: hidden;}
        .file_table tr:hover .link_setting_editor_img{visibility: visible;} 
        
        .link_setting_a{text-decoration:none}
        .link_setting_dropdown{position:absolute;left:100%;top:0;display:none;z-index:99999}
        .link_setting:hover .link_setting_dropdown{display:block}
        .link_setting_dropdown_div{display: grid;grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));gap: 0px;justify-content: start; align-items: center; border: solid 1px rgba(0,0,0,0.1);color:black}
        .link_setting_dropdown_button{background: #f2f2f2;border: none;padding: 2px 5px; margin: 0;font: inherit;color: inherit;text-decoration: none;cursor: pointer;outline: none; white-space: nowrap;z-index:99999;font-size:xx-small}
        .link_setting_dropdown_button:hover{background: #99ccff;color:#cc0066}
        .file_name_rename_div{position:relative}
        .file_name_rename_div:hover .file_name_rename_input{display:block}
        .file_name_rename_input{display:none;position:absolute;left:70px;top:0;width:300px}  
        
        .colored_mark td{background-color:rgba(51, 153, 102,0.1);}
        .colored_mark td:nth-child(3){color:red}
        
        #drop_area {border: 2px dashed #ccc;width: 400px;height: 50px;line-height: 50px;text-align: center;font-size: 20px;color: #ccc;display:none;position:absolute;bottom:30px;right:0px;background-color:rgba(255,255,255,0.9)}  
        #drop_area2 {border: 2px dashed #f2f2f2;width: 100%;height: 150px;line-height: 50px;text-align: center;font-size: 20px;color: #f2f2f2;;background-color:rgba(255,255,255,0.9)}  
        
        
        
        
        #main_content_part2{margin:5px;transition:1s;flex:1;position:relative;min-width:400px;width:100%;transition:1s}  
        .project_top_right div{display: inline-block;;transition:0.5s}
        .project_top_right:hover div{background-color:#e0ebeb;;transition:0.1s}
        .project_top_right #task_refresh{display:none}
        .project_top_right:hover #task_refresh{display:inline-block}
        #main_content_part3{margin:5px;transition:1s;flex:1;position:relative;min-width:200px;width:100%;transition:1s;display:none}  
        #file_preview_div{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;position:relative;padding-top:12px;width:100%;}
        #file_preview_close{position:absolute;top:5px;right:5px;display:block;height:36px;width:36px;cursor:pointer;display:none;padding:3px;border-radius:8px}
        #file_preview_close:hover{background-color:#f0f5f5}

        #file_preview{border:solid 0px red;margin-left:0 50px;;height:100%;padding:0;width:100%;max-width:100%}
        #file_preview_head{color:#009999;font-size:15px;font-weight:bold;margin-bottom:7px; user-select: text;max-width:95%;white-space:break-all;word-break: break-all; }/*word-break: break-all; 字符单词断开*/
        #file_preview_inner{background-color:white;overflow-wrap: break-word;white-space: pre-wrap;user-select: text;max-width: 99%;box-sizing: border-box;font-family: 'Courier New', Courier, monospace;;border:solid 0px blue;font-size:xx-small}
        
        
        
        /*#top_message{padding:5px 10px;border:solid 1px grey;border-radius:10px;position:fixed;top:30px;left:50%;transform: translateX(-50%);font-size:small;display:none;opacity: 0; }*/
        .message-box {padding: 5px 10px;border: solid 1px grey;border-radius: 10px;position: fixed;left: 50%;transform: translateX(-50%);font-size: small;display: block;opacity: 1; z-index: 9999;background-color: white;transition: opacity ease-in-out; margin-top: 40px; }
    </style> 
    <style>  
        #project_manager_content_div{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;;margin-bottom:10px}
        
        
    </style>
    <style>
        /**/
        /*最上方的搜索*/
        #project_show_option_inner2{padding:0 0px;;height:auto;margin-bottom:5px}
        #project_show_option_inner2_inner{border:solid 0px blue;height:100%;;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;position:relative}
        #project_show_option_inner2_inner>div{height:22px;border:solid 0px green;height:100%;}
        #project_show_option_inner2_inner input{height:20px;;border:solid 1px rgba(0,0,0,0.2);padding:1px 24px 1px 4px;width:120px}
        #project_show_option_inner2_inner_div{position:absolute;right:0;top:3px;width:20px;height:20px;cursor:pointer;border:solid 0px #000066;
            background-color:rgba(0, 0, 102,0.1);display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center}
        #project_show_option_inner2_inner_div:hover{background-color:rgba(0, 0, 102,0.3)}
        #project_show_option_inner2_inner_div:active{background-color:rgba(204, 102, 153,0.3)}
        #project_show_option_inner2_inner_div img{width:15px;height:15px}
        
        /*table的上方信息*/
        #table_top{width:100%;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center}
        #table_top_1{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;}
        #table_top_2{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-end;align-items:center;width:100%}
        .table_top_2_function{margin:0 50px}
        .table_top_2_function_button{background:rgba(51, 102, 153,0.1);border:solid 1px grey;padding: 1px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;border-radius:2px;cursor:pointer;line-height:1}
        .table_top_2_function_button:hover{background-color:rgba(51, 102, 153,0.9);color:white}
        .table_top_2_function_button:active{background-color:black;color:white}
        
        .num_per_page{margin-right:30px}
        .num_per_page span{font-size:xx-small;color:#336699;cursor:pointer}
        .num_per_page span:hover{color:red}
        
        #table_top_2_page{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;}
        .table_top_2_page_arrow{cursor:pointer}
        .refresh_time {  color: red; animation: fadeToBlack 1s forwards;}  
        @keyframes fadeToBlack {  from { color: red;}  to {  color: black;}  }
        .refresh_time2 {  color: red; animation: fadeToBlack2 1s forwards;}  
        @keyframes fadeToBlack2 {  from { color:#004c4d;}  to {  color: #009999;}  }
        /**table信息*/
        .info_table{width:100%}
        .info_table{margin:0px 0 15px 0;border-collapse: collapse;background-color:white;font-size:small;z-index:1;min-width:300px}
        .info_table th{background-color:rgba(51, 102, 153,0.3);user-select: none;font-size:normal;transition:0s;}
        .info_table th:not(:first-child):not(:last-child):hover{background-color:rgba(51, 102, 153,0.6);cursor:pointer}
        .info_table th:not(:first-child):not(:last-child):active{background-color:rgba(151, 102, 153,1);}
        .info_table th {padding: 1px 5px;text-align: left;height:24px;white-space:nowrap;overflow:hidden;transition:1s}
        .info_table td {padding: 1px 0px;border-bottom: 1px solid #ddd;text-align: left;height:24px;white-space:nowrap;overflow:hidden;transition:1s}
        .info_table tr:nth-child(even) {background-color: rgba(0, 0, 0,0.03);}
        .info_table tr:not(:first-child):hover {background-color:rgba(0, 102, 102,0.2)}
        /*table的最后一列*/
        .table_link_col>div {display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;}
        .link_svg{cursor:pointer;}      
        
        /*table内部的input*/
        .edited_info {width:100%;height:24px;margin:0;box-sizing:border-box;border:none;border-radius:5px;background-color:transparent;padding:0 5px;outline:none;border:solid 1px transparent;transition:0.3s}
        .edited_info:focus{border:solid 1px #3366ff;}
        .edited_info:hover{border:solid 1px #3366ff;} 
        .slight_border{border:solid 1px rgba(0,0,0,0.1);background-color:rgba(255,255,255,0.3)}
        
        /*新建数据*/
        #new_folder_tr2,#new_file_tr2{;display:none}
        #new_folder_tr2 td,#new_file_tr2 td{background-color: rgba(0, 153, 153,0.3);}
        #new_folder_tr2 input,#new_file_tr2 input{background:transparent;border: none;padding: 2px 5px; margin: 0;font: inherit;;text-decoration: none; white-space: nowrap;width:100%}
        .colored_row td{background-color:rgba(255, 102, 153,0.3);transition:1s;}/*background-color:rgba(51, 102, 204,0.2)*/
        .marked_taskid{border:solid 2px red}
        
        .table_dirurl_link{background-color:rgba(255,255,255,0.5);border:solid 1px rgba(229, 247, 255,0.1);border-radius:5px;cursor:pointer;transition:0.5s;color:#336699;padding:2px 5px 1px 5px;;font-weight:bold;}
        .table_dirurl_link:hover{transition:0s;background-color:white;overflow:auto;height:auto;transition:0.3s}
        .table_dirurl_link:active{transition:0s;background-color:#cc99ff;}
        
        .table_set_td_div{background-color:rgba(255,255,255,0.1);border:solid 1px rgba(229, 247, 255,0.1);border-radius:5px;;transition:0.5s;color:#336699;padding:2px 5px 1px 5px;;font-weight:bold;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;width:100%}
        .table_set_td_div:hover{transition:0s;background-color:white;}
        .table_button_div{cursor:pointer;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;height:20px;width:20px;margin:0 5px}
        .task2dir_div{position:relative;float:right;margin-right:30px;cursor:pointer}
        .task2dir_div_dropdown{position:absolute;bottom:-3px;right:20px;display:none;font-size:xx-small;;line-height:25px;padding-left:10px}
        .task2dir_div:hover .task2dir_div_dropdown{display:block;}
        /*其他*/
        .green_background{background-color: rgba(0, 204, 0,0.4); /* 立刻变成绿色底纹 */}/*transition: background-color 6s linear;  */
        
        /*点击某个时高亮一行*/
        .marked_row td{background-color:rgba(255, 102, 153,0.3);transition:0s;}
        .marked_row:hover td{background-color:rgba(255, 102, 153,0.5);transition:0s;}
        
        .marked_projectid{border:solid 2px red}
        
        /**/
         #new_section_all{font-family: 'Microsoft YaHei', '微软雅黑', sans-serif;margin:auto;padding:auto}
    </style>
    
    <style>
        /*task_prepare_div*/
        #task_prepare_div{}
        .task_prepare_div_highlight{background-color:yellow;background-color 0.5s ease,}
        #task_prepare_head_div {display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;width:100%;}
        #task_prepare_head_div button{padding:1px 5px}
        #task_prepare_head_div span{color:#006699}
        #project_prepare_list_div{margin-top:10px;position:relative}
        #section2paste_clear{cursor:pointer;font-size:xx-small;color:#336699;padding:2px 5px;position:absolute;left:210px;top:-30px}
        #project_prepare_list_div_inner{}
        .project_prepare_list_div_inner_one{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:center;width:200px;border:solid 1px grey;color:#336699;;cursor:pointer;margin-bottom:-1px}
        .project_prepare_list_div_inner_one>div{background-color:white;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;border-right:solid 1px grey}
        .project_prepare_list_div_inner_one:hover{background-color:rgba(0, 102, 102,0.5);color:white}
        .project_prepare_list_div_inner_one span{font-size:xx-small;padding:2px 5px}
        .marked_project_prepare_button{background-color:rgba(153, 51, 51,0.5);;color:white}
        #project_prepare_content_div{}
        #project_prepare_content_div_inner_table{border:solid 1px grey;color:#336699;margin-left:21px;background-color:rgba(153, 51, 51,0.05);max-width:500px}
        #project_prepare_content_div_inner_table tr td:first-child{width:55px;max-width:55px;min-width:55px;color:#336699;font-size:small}
        .detail_eachpart{margin:3px 10px;}
        
        .detail_each_head{font-size:8px;position:relative;top:6px;margin-right:3px}
        .detail_each_content{font-size:x-small;background-color:rgba(51, 102, 153,0.1);color:black;padding:1px 6px;border:solid 1px grey;border-radius:5px;margin:0 1px 0 0px;padding:3px 6px }
        .detail_each_content2{font-size:x-small;background-color:rgba(51, 102, 153,0.1);color:black;padding:1px 6px;border:solid 1px grey;border-radius:5px;margin:0 1px 0 0px;padding:3px 6px }
        .detail_each_content input{max-width:200px;border: none;background: none;  outline: none; box-shadow: none;}
        .link_td{color:#0099cc;font-size:xx-small;cursor:pointer;}
        .link_td:hover{color:#007399;background-color:rgba(0, 102, 153,0.5);color:white}
        .link_td:active{color:#ff0066;background-color:rgba(0, 102, 153,0.9);color:white}
        #project_revise_div{position:absolute;top:-1px;right:-172px;height:40px;width:170px;border:solid 1px grey;color:#ff0066;padding:0;overflow:hidden}
        #project_revise_div>div{margin:0;height:20;min-height:20px;max-height:20px;width:170px;border:solid 0px blue;overflow:hidden;
             display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;
        }
        #project_revise_div>div:first-child{border-bottom:solid 1px grey;}
        #project_revise_div input{width:168px;;border:none; outline: none; box-shadow: none;height:20px;padding:2px 5px;line-height:20px;}
        
        #variable_input_div{font-size:small;border:solid 0px grey;margin-top:-1px;margin-left:80px;min-height:70px}
        #variable_input_div table{border:solid 1px grey}
        #variable_input_div .color_icon{height:10px;width:10px;border:solid 1px grey;display:inline-block;cursor:pointer;margin:0 3px}
        .variable_new{padding:0px 5px 1px 5px}
        .relative_td{position:relative}
        .relative_td_restore_span{position:absolute;left:2px;top:0px;color:#336699;font-size:xx-small;cursor:pointer;white-space:nowrap;padding:3px 6px}
        .relative_td_restore_span:hover{color:#ff6600}
        
        .relative_td_info_div{position:absolute;left:50px;top:10px;background-color:rgba(0, 85, 128,0.1);border-radius:5px;border:dashed 1px grey;
            display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;
        }
        .relative_td_info_div_textdiv{color:#336699;font-size:xx-small;width:100px;margin-left:10px}
        
        .relative_td_arrow_div{position:absolute;top:35px;width:20px;height:1px;border-bottom:dashed 1px grey;}
        
        .relative_td_start_div{position:absolute;top:10px;background-color:rgba(0, 85, 128,0.1);border-radius:5px;border:solid 2px grey;
            display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;height:50px;width:80px;padding:5px;
        }
        .relative_td_start_div:hover{background-color:rgba(0, 85, 128,0.2)}
        .relative_td_start_div:active{background-color:rgb(255, 102, 153)}        
        .relative_td_start_div_textdiv{color:#336699;font-size:xx-small;width:100px;margin-left:10px}  
        .relative_td_start_div_textdiv span{color:#009999}
        .relative_td_start_div_imgdiv{display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:center;align-items:center;height:35px;width:35px;margin:0 0px 0 10px}
        .relative_td_start_div_imgdiv img{height:25px;width:25px;}
        
        .dynamic_info{}
        #item_detail_div{margin:30px 0 330px 0}
        .item_detail_one_div{border:solid 1px grey;margin-bottom:-1px;font-size:x-small;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:left;flex-direction: column;width:400px;margin-left:80px;position:relative}
        /*第0列*/        
        .item_detail_icon{position:absolute;top:-1px;left:-20px;height:20px;width:20px;border:solid 1px grey;cursor:pointer;}
        /*第1列，主要列*/        
        .detail_each_content3{display:flex;display:-webkit-flex;flex-wrap:wrap;justify-content:flex-start;align-items:center;min-height:18px;max-width:400px;}
        .detail_each_content3>div{padding:3px 6px}
        .detail_each_content3>div:first-child{width:50px;flex:none;font-size:10px;color:grey;display:none}
        .detail_each_content3>div:nth-child(2){flex:1;width:400px;}
        /*第2列*/
        .item_detail_morerevise{position:absolute;top:-1px;right:-150px;height:36px;width:150px;border:solid 1px grey;color:#ff0066;overflow:hidden;padding:0}
        .item_detail_morerevise>div:first-child{border-bottom:solid 1px grey}
        .item_detail_morerevise input{width:150px;;border:none; outline: none; box-shadow: none;height:17px;padding:1px 18px 1px 5px}
        /*第3列*/
        .item_detail_startpos_middle{position:absolute;top:-1px;right:-180px;height:36px;width:36px;border:solid 1px grey;color:white;font-size:xx-small;overflow:hidden}
        .state_radio{display:none}
        .state_radio_label{height:18px;width:34px;;display:block;padding:0 2px;text-align:center;background-color:#d9d9d9;border-bottom:solid 1px grey;}
        .state_radio_label:hover{background-color:#99ccff;}
        .state_radio_label:active{background-color:#99ccff;}
        .state_radio:checked + .state_radio_label {  background-color: #ff9966;color:white; }
        /**/
        .state_radio_label2{height:18px;width:34px;;display:block;padding:0 2px;text-align:center;background-color:#d9d9d9;border-bottom:solid 1px grey;font-size:11px;}
        .state_radio_label2:hover{background-color:#99ccff;}
        .state_radio_label2:active{background-color:#99ccff;}
        .state_radio:checked + .state_radio_label2 {  background-color: #009999;color:white; }
        /**/
        .state_radio_label3{height:18px;width:34px;;display:block;padding:0 2px;text-align:center;background-color:#d9d9d9;border-bottom:solid 1px grey;font-size:11px;}
        .state_radio_label3:hover{background-color:#99ccff;}
        .state_radio_label3:active{background-color:#99ccff;}
        .state_radio:checked + .state_radio_label3 {  background-color: #9494b8;color:white; }        
        /*第4列*/
        .each_detail_runstate{position:absolute;top:-1px;right:-186px;height:36px;width:7px;border:solid 1px grey;}
        
        /*跳转标记*/
        .each_detail_jumpmark{position:absolute;top:-100px}
        .one_relynode_button{margin:0 5px;padding:0px 3px;background-color:#e0ebeb;border-radius:5px;font-size:10px}
        /*
    </style>
    
    <style>
        /*task_manager_content*/
        #task_manager_content_div{background-color:white;padding:15px 30px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;;margin-bottom:10px}
        #task_manager_content{}
        #task_create_content{}
        
    </style>    
</head>
<body>
    <div id='top_navigator'>
        <a id='top_navigator_title_name' href='index.php'>Bioslurm</a>
        <span id="top_navigator_current_time"></span>
        <span id="user_state"><?php echo $navi_user_state;?></span>
    </div> 
    <div  id='easylink_div'>
        <a href='index.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_home.svg">
            </div>
        </a>
        
        <a href='function_file.php' >
            <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_file.svg">
                <div class='function_link_div_dropdown'>文件目录</div>
            </div>
        </a>
        
        <a href='function_script.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_script.svg">
                <div class='function_link_div_dropdown'>命令脚本</div>
            </div>
        </a>

        <a href='function_stream.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_stream.svg">
                <div class='function_link_div_dropdown'>线性流程</div>
            </div>
        </a>
        
        <a href='function_structure.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_structure.svg">
                <div class='function_link_div_dropdown'>网络结构</div>
            </div>
        </a>
        
        <a href='function_project.php' >
            <div class='function_link_div select_div'><img style='width:30px;height:30px' src="000_image/svg_function_project.svg">
                <div class='function_link_div_dropdown'>项目执行</div>
            </div>
        </a>     

        <a href='function_progress.php' >
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_progress.svg">
                <div class='function_link_div_dropdown'>作业进度</div>
            </div>
        </a>   
        
        <a href='function_zoom.php' style='margin-top: auto;margin-bottom:50px'>
            <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_gear.svg">
            </div>
        </a>                 
    </div>
    <div id='all_sum'>
        <div id='main_content'>
            <div id='main_content_part1'>
                <div id="file_manager"> 
                    <div id='file_manager_head'>
                        <span style="cursor:pointer; " onclick="path_refresh_click()">项目执行</span>
                    </div>
                    <div id='projectdir_mark_div'>
                        <div id='projectdir_mark_div2'>
                            <div id='projectdir_mark_div_icon' onclick="projectdir_mark()"><svg t="1725533137802" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6281" width="20" height="20"><path d="M288 128H896l-160 256L896 640H288v320H192v-896h96V128z" fill="#d81e06" fill-opacity=".65" p-id="6282"></path></svg>
                                <div  id='projectdir_mark_div_icon_dropdown'>
                                    点击红旗标志固定，默认动态获取<span style='color:grey'>[使用当前目录为项目目录]</span>
                                </div>
                            </div>
                            <div id='projectdir_mark_div_right'>
                                <div id='projectdir_mark_div_content'>
                                    <div id='projectdir_mark_div_txt'></div>
                                    <div id='projectdir_mark_div_close' onclick='projectdir_mark_clear()'>取消固定</div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div id="file_manager_path_all">
                        <div  class="file_manager_path">
                            <div class="file_manager_path_button" onclick='path_back_click()'><img src="000_image/svg_leftarrow.svg"></div>
                            <div class="file_manager_path_button" style='margin-left:-1px' onclick='path_forword_click()'><img src="000_image/svg_leftarrow.svg" style="transform: rotate(180deg);"></div>
                            <div class="file_manager_path_classpath">
                                <!--上层左边，里面一块块的路径，可以换行-->
                                <div class='file_manager_blocks_click_region' id="file_manager_blocks_click_region">
                                </div>
                                
                                <!--底层可以输入的input，absolute-->
                                <div id="file_manager_path2">   
                                    <input id='file_manager_path2_input' type="text" value='/home/'>
                                </div> 
                                
                                <!--底层一个固定边框-->
                                <div id="file_manager_center_front">   </div> 
                                <div id="file_manager_center_back">   </div> 
                                
                            </div>
                            <div class="file_manager_path_button" onclick="path_change_click()" id='path_change_click_button'><img src="000_image/svg_urlwrite.svg"></div>
                            <div class="file_manager_path_button" style='margin-left:-1px' onclick="path_refresh_click()"><img src="000_image/svg_refresh.svg"></div>
                        </div>    
                        <div style='position:absolute;top:40px;right:70px;font-size:xx-small;color:#336699' id='collect_num_show'></div>
                    </div>
                    <!-- 动态生成文件和文件夹 -->  
                    <div id="file_manager_content" >
                    </div>   
                </div>  
            </div>                       
            <div id='main_content_part2'>
                <div id="project_manager_content_div"></div >     
                <div id="task_manager_content_div"> 
                    <div id='task_manager_content'></div>
                    
                    <div id='task_create_content'></div>
                </div> 
            </div>   
            
            <div id='main_content_part3'>
                <div id="file_preview_div">
                    <div id='file_preview_close' onclick='file_preview_close_click()'><img style='width:30px;height:30px' src="000_image/svg_close.svg"></div>
                    <div id="file_preview">
                        <div id="file_preview_head" style='white-space:break-all;'></div>
                        <div id="file_preview_inner" style='min-height: calc(100vh - 150px);'></div>
                    </div> 
                </div> 
            </div> 
        </div> 
        
        <div id='top_message'></div>
        
        <!--力导向图-->
        <style>
            .node {stroke: transparent;stroke-width: 0px;}
            .link {stroke: #999;stroke-width: 1px;}
            .node_label {position: absolute;text-align: center;padding: 2px;background: #f9f9f9;border: 1px solid #d3d3d3;border-radius: 4px;pointer-events: none;display: none;z-index:999}

            #nodename_out {width:496px;text-align:center;margin-top: 20px;padding: 10px;border: 0px solid #ccc;}
        </style> 
        <div id='FDG_all' style='display:none;'>
            <div id='bottom_FDG_button' onclick='bottom_FDG_button_click()' style='position:fixed;bottom:0;left:320px;width:40px;height:40px;border:solid 0px grey;border-radius:5px;background-color:#f5f5f5;cursor:pointer;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;'><img style='width:30px;height:30px' src="000_image/svg_function_FDG.svg">
            </div>
            <div id='bottom_FDG_div' style='width:500px;height:300px;border:solid 1px #f0f5f5;position:fixed;bottom:40px;left:100px;' >   
                <svg id='FDG_svg' width="500" height="300" style="border:solid 0px grey"></svg>        <!--力导向图-->
                <div style='float:right;'><button id="toggleLabelsButton" onclick="toggleAllLabels()">展示标签</button></div>
                <div style='float:right;'><button onclick='all_switch(this)'>全部Close</button></div>
            </div>
            <div id="node_label" class="node_label"></div><!--这个局内标签似乎需要放到较高的层级，放到图里不知道为啥容易不显示-->
            <div id="nodename_out" style='position:fixed;bottom:42px;left:102px;pointer-events:none;font-size:xx-small'></div><!--点击显示node-->
        </div>
        
        <input type='hidden' id="FDG_graph_state_hidden" value='1'>        <!--力导向图 按钮     显示状态---->
        <input type='hidden' id="structure_content_ul_value" value=''> 
        
        <!--file-->
        <input type='hidden' id='local_path' value='/'>
        <input type='hidden' id='local_path_bak' value='/'>
        <input type='hidden' id='all_checkbox_value' name='all_checkbox_value' value=''  />
        <input type='hidden' id='all_checkbox_value_localpath' name='all_checkbox_value_localpath' value=''  />
        
        
        <!--project-->
        <input type='hidden' id="current_project_dir_hidden" value='/'>
        <input type='hidden' id="current_project_dir_state_hidden" value='dynamic'>
        
        <input type='hidden' id="current_page_hidden" value='1'>
        <input type='hidden' id="current_page_sum_hidden" value='0'>
        <input type='hidden' id="current_searchword_hidden" value='<?php echo $searchword; ?>'>
        <input type='hidden' id="current_sortcol_hidden" value=''>
        <input type='hidden' id="current_sortcol_direction_hidden" value='desc'>
        <input type='hidden' id="current_num_per_page_hidden" value='5'>
        
        <input type='hidden' id="current_project_itemid_hidden" value=''>
        
        <!--project_prepare-->
        <input type='hidden' id="project_prepare_item_hidden" value=''>
        <input type='hidden' id="project_prepare_dir_hidden" value=''>
                
        <!--task-->
        <input type='hidden' id="current_page2_hidden" value='1'>
        <input type='hidden' id="current_page_sum2_hidden" value='0'>
        <input type='hidden' id="current_searchword2_hidden" value='<?php echo $searchword; ?>'>
        <input type='hidden' id="current_sortcol2_hidden" value=''>
        <input type='hidden' id="current_sortcol_direction2_hidden" value='desc'>
        <input type='hidden' id="current_num_per_page2_hidden" value='5'>
        <input type='hidden' id="current_task_module_name_hidden" value=''>
        <input type='hidden' id="current_taskid_hidden" value=''>                           <!--style='position:fixed;top:40px;left:20px'  用于测试和debug-->
    </div> 
        </div>
    </div> 
    
    <script src="/plug/d3.v6.min.js"></script>  
    <script src="/plug/monaco_editor/min/vs/loader.js"></script><!--注意更改路径-->   
    <script src="plug/monaco_editor/DIY/editor.js"></script>
</body>      
</html>

<script>
    function getCurrentTime() {
        var now = new Date();
    
        // 获取小时、分钟和秒
        var hours = now.getHours();
        var minutes = now.getMinutes();
        var seconds = now.getSeconds();
    
        // 格式化时间（例如：09:05:03）
        var formattedTime = [
            String(hours).padStart(2, '0'),
            String(minutes).padStart(2, '0'),  //String(hours).padStart(2, '0') 是将 hours 转换为字符串，并且如果 hours 的长度小于 2，就在其前面填充 '0'，确保输出始终是两位数的格式
            String(seconds).padStart(2, '0')
        ].join(':');
    
        return formattedTime;
    }
   
    function getCurrentTime2() {
        var now = new Date();
        var year = now.getFullYear();
        var month = String(now.getMonth() + 1).padStart(2, '0'); // 月份从 0 开始，需要加 1
        var day = String(now.getDate()).padStart(2, '0');
        var hours = String(now.getHours()).padStart(2, '0');
        var minutes = String(now.getMinutes()).padStart(2, '0');
        var seconds = String(now.getSeconds()).padStart(2, '0');
        // 格式化年月日和时间
        var formattedTime = [year, month, day].join('') + [hours, minutes, seconds].join('');
        return formattedTime;
    }
    
    function generateRandomString(length) {  
        var characters = 'abcdefghijklmnopqrstuvwxyz0123456789';  
        let result = '';  
        for (let i = 0; i < length; i++) {  
            var randomIndex = Math.floor(Math.random() * characters.length);  
            result += characters[randomIndex];  
        }  
        return result;  
    }  
    
    ///随机生成一个颜色如何防止出现特别亮或者饱和度特别低的颜色
    //let randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);   //随机生成一个颜色
    function getRandomColor() {  
        // 生成一个随机的色调值 (0 - 360)  
        let hue = Math.floor(Math.random() * 360);  
      
        // 生成一个随机的饱和度值 (80% - 100%) 以避免饱和度太低  
        let saturation =100 ; // 50到100  Math.floor(Math.random() * 51)即取0到50的整数Math.floor(Math.random() * 21) + 80
      
        // 生成一个随机的亮度值 (60% - 70%) 以避免颜色太亮或太暗  
        let lightness = Math.floor(Math.random() * 11) + 60; // 30到70  
      
        // 将 HSL 转换为 RGB  
        // 基于 HSL 到 RGB 的转换算法  
        function hslToRgb(h, s, l) {  
            s /= 100;  
            l /= 100;  
            var k = (n) => (n + h / 60) % 6;  
            var f = (n) => l * (1 - s * Math.max(Math.min(k(n), 4 - k(n), 1), 0));  
            return [f(5), f(3), f(1)].map(v => Math.round(v * 255)).join(',');  
        }  
      
        let rgb = hslToRgb(hue, saturation, lightness);  
        let color = `rgb(${rgb})`;  
      
        // 如果需要 HEX 格式  
        function rgbToHex(r, g, b) {  
            return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();  
        }  
      
        let r, g, b;  
        [r, g, b] = rgb.split(',').map(Number);  
        let hexColor = rgbToHex(r, g, b);  
      
        return hexColor;  
    }  
    const dict_node2name = {};
    const checkboxValuesSet = new Set();  //外部声明一个set，虽然是const定义的的，由于是set仍然可以编辑
    
    // 上传文件
    function uploadFiles(files, uploadPath) {
        // 创建 FormData 对象
        var formData = new FormData();
        formData.append('upload_path', uploadPath); // 将目录路径添加到 FormData
        // 将文件添加到 FormData 对象中
        for (let file of files) {formData.append('files[]', file); }
        // 使用 Fetch API 上传文件
        fetch('/function_file_upload.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json()) // 解析 JSON 响应
        .then(data => {
            console.log('Upload successful:', data);
            // 打印 filelist
            if (data.status === 'success') {
                console.log('Uploaded files:', data.result.filelist);
                path_refresh_click(data.result.filelist); // 刷新路径
                //alert('Files uploaded successfully.');
                let innerHTML='文件上传成功';
                showAndFadeOut('success', 2000, 3,innerHTML);
            } else {
                console.log('Errors:', data.result.errors);
                alert('Error uploading files.');
            }
        })
        .catch(error => {
            console.error('Error uploading files:', error);
            showAndFadeOut('error', 2000, 3,error)
            alert('Error uploading files.');
        });
    }
    //拖拽的
    function preventDefaults(e) {e.preventDefault();e.stopPropagation(); }
    function handleDrop(e) {
        preventDefaults(e);
        var files = e.dataTransfer.files;
        var uploadPath = (base_path + document.getElementById('local_path').value);
        console.log("uploadPath:", uploadPath);
        uploadFiles(files, uploadPath);
    }
    function handleDragOver(e) {preventDefaults(e);e.dataTransfer.dropEffect = 'copy';}
    //选择的文件
    // 监听文件选择器的 change 事件，选择文件后自动上传
    function triggerFileSelection() {document.getElementById('fileInput').click(); }  // 点击按钮时，触发隐藏的文件选择器    
   
    const local_path_history =  ['/'];
    const local_path_history2 = [];
    function ajax_get_filelist(base_path, local_path, colored_list,is_backforward,callback) {
        //console.log("ajax_get_filelist开始：","base_path:",base_path, "local_path:",local_path, "colored_list:",colored_list);
        let complete_path=base_path+local_path;
        fetch('function_file_get_filelist.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'action':'get_all',
                'base_path': base_path ,
                'local_path': local_path,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            //console.log(data.result);
            //console.log(data.error);

            let query_type=data.url_type;
            
            //清空复选框
            checkboxValuesSet.clear();
            // 你可以根据 data 内容生成 HTML 片段
            
            let current_time=getCurrentTime();
            let table1=`    <table class="file_table">
                                <tr class=''>
                                    <td colspan='6' style='vertical-align:bottom'>
                                        <span class='refresh_time' style='position:relative;top:5px;cursor:pointer' onclick="path_refresh_click()">刷新时间: ${current_time}</span> 
                                        <div class='table_top_function'>
                                            
                                            <div>
                                                新建<button class='table_top_button' onclick='create_dir_click()'><img src='/000_image/svg_link_create_dir.svg'></button><button  onclick='create_txt_click()' class='table_top_button' style='margin-left:1px' ><img src='/000_image/svg_link_create_txt.svg'></button>
                                            </div>                                                 
                                            
                                            <div class='toggle-btn' style='position:relative'>
                                                上传<input type="file" id="fileInput" multiple style="display: none;" /><button class='table_top_button' id="uploadButton" onclick="triggerFileSelection()"><img src='/000_image/svg_link_upload.svg'></button><button  onclick="show_and_hide('drop_area')" class='table_top_button' style='margin-left:1px' ><img src='/000_image/svg_link_drag.svg'></button><div id="drop_area">Drag and drop files here</div>
                                            </div>  
 
                                            <div >
                                                移动<button class='table_top_button' onclick='collect_checkboxs()'><img src='/000_image/svg_link_cut.svg'></button><button class='table_top_button' style='margin-left:1px' onclick='collect_checkboxs_mvfile()'><img src='/000_image/svg_link_paste.svg' ></button>
                                            </div>
                                            
                                            <div class='link_setting'>
                                                处理<button class='table_top_button'><img src='/000_image/svg_link_gears.svg'></button>
                                                <div class='link_setting_dropdown'>
                                                     <div class='link_setting_dropdown_div'>
                                                        <button class='link_setting_dropdown_button' onclick="file_operate_multi('批量删除')">批量删除</button>
                                                        <button class='link_setting_dropdown_button' onclick="file_operate_multi('批量压缩')">批量压缩</button>
                                                    </div>   
                                                </div>    
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th colspan='2' style='width:20px'><input  type='checkbox' id='all_checkbox' name='all_checkbox' value='all_checkbox' onclick='all_checkbox_click()' style='position:relative;top:2px'>
                                        <input type='hidden' id='all_checkbox_state' name='all_checkbox_state' value='0'  />
                                        <span id='checkbox_selected_num' style='font-size:10px;color:darkblue'></span>
                                    </th>
                                    <th>Name</th>
                                    <th>文件大小</th>
                                    <th>更新时间</th>
                                    <th style='text-align:center'>操作</th>
                                </tr>
                                <tr id='new_folder_tr' >
                                    <td></td>
                                    <td><img style='position:relative;top:3px' src='/000_image/svg_filetype_folder.svg'></td>
                                    <td colspan='4'><input type='text' id='new_folder_tr_input' value='新建文件夹'></td>
                                </tr>
                                <tr id='new_file_tr' >
                                    <td></td>
                                    <td><img style='position:relative;top:3px' src='/000_image/svg_filetype_normal.svg'></td>
                                    <td colspan='4'><input type='text' id='new_file_tr_input' value='新建文件'></td>
                                </tr>                                
                                `;
            let table2=``;
            let dir_list=[];let dir_file_num=0;let normal_file_num=0;
            raw_result.forEach((item) => {
                let fileType_icon_name="";let file_type='';let file_name_click_str='';
                let file_name=item.fileName.split('/').pop();;  
                let filesize=item.size;
                let file_pointer_events='';
                let complete_path_real=complete_path.substring(21);
                let download_file=complete_path_real+"/"+file_name;
                //有颜色闪烁的一行
                let colored_mark='';
                //
                
                if (typeof colored_list !== 'undefined'){
                    //console.log('有colored_list');
                    if(colored_list.includes(file_name)){colored_mark='colored_mark';console.log('高亮的行：',file_name);}
                }
                //
                let file_size_show=filesize;
                let code_editor_str='';
                if(item.fileType=="d"){     fileType_icon_name='svg_filetype_folder.svg';file_type='文件夹';file_name_click_str='file_jumpinto';
                                            dir_list.push(file_name);dir_file_num+=1;file_pointer_events=" style='pointer-events: none;visibility: hidden;'";file_size_show=`<button style='all: unset;color:#009999' onclick ="cal_dir_size('${file_name}')">计算</button>`;}
                else{                       fileType_icon_name='svg_filetype_normal.svg';file_type='文件';file_name_click_str='file_open';normal_file_num+=1;
                    file_size_show=formatBytes(filesize);
                    if (filesize<10485760){ //10M
                        //如果是预定的一些扩展名，尽量显示他们
                        const extensions = ['.abap','.cls','.azcli','.bat','.bicep','.mligo','.clj','.coffee','.cpp','.cs','.csp','.css','.cyp','.dart','.dockerfile','.ecl','.ex','.js','.jsx','.ts','.tsx','.flow9','.freemarker2','.fsharp','.go','.graphql','.handlebars','.hcl','.html','.ini','.java','.julia','.kt','.less','.lexon','.liquid','.lua','.m3','.md','.mdx','.mips','.msdax','.mysql','.m','.pas','.pascaligo','.pl','.pgsql','.php','.pla','.postiats','.pq','.ps1','.proto','.pug','.py','.qs','.r','.razor','.redis','.redshift','.rst','.rb','.rs','.sb','.scala','.scm','.scss','.sh','.sol','.sophia','.rq','.sql','.st','.swift','.sv','.tcl','.twig','.vb','.wgsl','.xml','.yaml','.yml','.log','.err','.fai','.txt','.slm','.vcf','.bed','.fasta','.fas','.fa'];
                        const regex = new RegExp(`\\.(${extensions.map(ext => ext.slice(1)).join('|')})$`, 'i');// 生成正则表达式（如：/\.(abap|cls|azcli|...)$/i）
                        let good_extension_str=``;
                        if(regex.test(file_name)){good_extension_str=`visibility:visible`;}
                        //
                        code_editor_str=`
                                <div class='link_setting_editor'>
                                    <img style='position:relative;top:3px;${good_extension_str}' src='/000_image/svg_link_editor.svg' class='link_setting_editor_img'  onclick="code_editor_generate('${complete_path_real}','${file_name}')">
                                </div>`;}
                }
                let BioSlurm_share_checkbox='';let select_checkbox_class='select_checkbox';let link_setting_hidden='';
                if (file_name=='BioSlurm_share'){BioSlurm_share_checkbox='disabled';select_checkbox_class='';link_setting_hidden='display:none';}
                table2+=`       <tr class='${colored_mark}'>
                                    <td style='width:10px'>
                                        <input  type='checkbox' class='${select_checkbox_class}' style='position:relative;top:3px' name='selected_files' onclick='one_checkbox_click(this)' value='${file_name}_||_${file_type}'  ${BioSlurm_share_checkbox}>
                                    </td>
                                    <td style='width:12px'><img style='position:relative;top:3px' src='/000_image/${fileType_icon_name}' onclick="copy_str('${file_name}')"></td>
                                    <td class="file_name_td">
                                        <div class='file_name' onclick="${file_name_click_str}('${file_name}','${filesize}')" >${file_name}</div>
                                    </td>
                                    <td>${file_size_show}</td>
                                    <td style='width:120px'>${item.updateTime}</td>
                                    <td style='text-align:right;width:75px'>
                                        ${code_editor_str}
                                        <a href="${download_file}" download class='link_setting_a'  ${file_pointer_events}><div class='link_setting'>
                                            <img style='position:relative;top:3px' src='/000_image/svg_link_download.svg'>
                                             </div>   
                                        </a>
                                        <div class='link_setting' style='${link_setting_hidden}'>
                                            <img style='position:relative;top:3px' src='/000_image/svg_link_gear.svg'>
                                            <div class='link_setting_dropdown'>
                                                 <div class='link_setting_dropdown_div'>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('删除','${file_type}','${file_name}')">删除</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('复制','${file_type}','${file_name}')">复制</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('压缩','${file_type}','${file_name}')">压缩</button>
                                                    <button class='link_setting_dropdown_button' onclick="file_operate('解压','${file_type}','${file_name}')">解压</button>
                                                    <div class='link_setting_dropdown_button file_name_rename_div' >
                                                        重命名
                                                        <input type='text' class='file_name_rename_input' onchange="file_operate('重命名','${file_type}','${file_name}',this)" value='${file_name}'>
                                                    </div>
                                                    
                                                </div>   
                                            </div>    
                                        </div>
                                    </td>
                                </tr>`;
            });
            let table3=`        <tr>
                                    <td colspan='6' style='font-size:15px;color:grey;font-size:xx-small'>
                                        文件夹数量${dir_file_num}个，文件数量${normal_file_num}个。点击图标复制名称。
                                    </td>
                                </tr>
                                <tr style='background-color:transparent;'>
                                    <td colspan='6' style='font-size:15px;color:grey;font-size:xx-small;background-color:transparent;border:none'>
                                        <div id="drop_area2">Drag and drop files here</div>
                                    </td>
                                </tr>
                            <table>`;
            let table_sum=table1+table2+table3;
            let contentHtml = `${table_sum}`.trim();

            //改表头
            let new_local_path=document.getElementById('local_path_bak').value;
            document.getElementById('local_path').value=new_local_path;
            let path2_url=("/home/"+new_local_path).replace(/\/{2,}/g, '/');   //去掉连续的
            let new_local_path_arr = new_local_path.split('/');
            
            if (query_type=="文件"){
                new_local_path_arr.pop();
                path2_url = path2_url.replace(/\/[^\/]*\/?$/, '')+"/";       //如果是文件，去掉最后一个非边界/之后的内容
                let truncted_local_path=path2_url.replace(/^(\/?home\/)/, '/');
                console.log("文件，truncted_local_path:",truncted_local_path);
                document.getElementById('local_path').value=truncted_local_path;
                document.getElementById('local_path_bak').value=truncted_local_path;
            }
            //console.log(query_type);
            //console.log("path2_url",path2_url);
            document.getElementById('file_manager_path2_input').value=path2_url.replace(/\/{2,}/g, '/');
            //console.log("new_local_path_arr",new_local_path_arr);
            let file_manager_blocks_click_region=`<div class="file_manager_path_classpath_each">   
                                        <span class="file_manager_path_classpath_each_1" onclick="dirurl_jumpinto('/')">home</span>     
                                        <span class="file_manager_path_classpath_each_2" id='dir_expand_1' onclick="dir_expand_click('dir_expand_1','/')">><div class="file_manager_path_classpath_each_2_dropdown" id='dir_expand_1_dropdown'></div></span>     
                                    </div>`;
            let dir_url="/";
            let dir_expand_num=1;
            let part_local_path='/';
            new_local_path_arr.forEach((item) => {
                if (item != "") { 
                    dir_url+=item+"/";
                    dir_expand_num+=1;  part_local_path+="/"+item;
                    file_manager_blocks_click_region+=    `<div class="file_manager_path_classpath_each">   
                                                    <span class="file_manager_path_classpath_each_1" onclick="dirurl_jumpinto('${dir_url}')">${item}</span>     
                                                    <span class="file_manager_path_classpath_each_2" id='dir_expand_${dir_expand_num}' onclick="dir_expand_click('dir_expand_${dir_expand_num}','${part_local_path}')">><div id='dir_expand_${dir_expand_num}_dropdown'  class="file_manager_path_classpath_each_2_dropdown" ></div></span>     
                                                </div>`;
                }
            });
            //console.log("file_manager_blocks_click_region",file_manager_blocks_click_region);
            document.getElementById('file_manager_blocks_click_region').innerHTML=file_manager_blocks_click_region;;
            
            //改内容
            var fileManagerContentDiv = document.getElementById('file_manager_content');;
            fileManagerContentDiv.innerHTML = contentHtml;
            
            //非历史左右键则考虑更新
            if(is_backforward=="is_backforward"){}else{
                if(local_path_history[local_path_history.length - 1] == local_path) {}                                                //重复请求
                else{
                    local_path_history.push(local_path);
                    //是否前进
                    if(local_path_history2.length > 0){
                        if (local_path_history2[0] !== local_path) {local_path_history2.length = 0; }       //清空path2
                        else{local_path_history2.shift(); }                                                 // 移除第一个元素
                    }
                }
                //console.log(local_path_history,local_path_history2);
            }
            // 拖拽上传, 给div加上监听
            var dropArea = document.getElementById('drop_area');
            dropArea.addEventListener('dragenter', preventDefaults, false);
            dropArea.addEventListener('dragover', handleDragOver, false);
            dropArea.addEventListener('drop', handleDrop, false);
            // 使 drop_area2 拥有相同的行为
            var dropArea2 = document.getElementById('drop_area2');
            dropArea2.addEventListener('dragenter', preventDefaults, false);
            dropArea2.addEventListener('dragover', handleDragOver, false);
            dropArea2.addEventListener('drop', function(e) {
                // 模拟 drop_area1 的 handleDrop 行为
                handleDrop.call(dropArea, e);
            }, false);   
            
            
            //点击上传
            document.getElementById('fileInput').addEventListener('change', function() {// 监听文件选择器的 change 事件，选择文件后自动上传
                var files = document.getElementById('fileInput').files;
                var uploadPath = base_path + document.getElementById('local_path').value;
            
                if (files.length > 0) {
                    // 自动上传文件
                    uploadFiles(files, uploadPath);
                } else {
                    alert('请先选择文件。');
                }
            });

            //显示项目表
            let current_project_dir_state_hidden= document.getElementById('current_project_dir_state_hidden').value;
            if(current_project_dir_state_hidden=='dynamic'){ 
                refresh_project_click();
                //清空任务列表
                document.getElementById('task_manager_content').innerHTML=''; 
            }
            
            if(callback){
                callback();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            if (error.message == "没有那个文件或目录") {
                document.getElementById('file_manager_path2_input').value = "/home/" + document.getElementById('local_path').value;
                let innerHTML = '没有那个文件或目录，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else if (error.message == "错误的路径格式") {
                document.getElementById('file_manager_path2_input').value = "/home/" + document.getElementById('local_path').value;
                let innerHTML = '错误的路径格式，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else{
                // 处理其他未知错误
                let innerHTML = '发生错误，路径不存在';
                showAndFadeOut('error', 2000, 3,innerHTML);
            }
        });
    }
    
    //页面初始化时的操作
    const base_path = <?php echo json_encode($base_path); ?>;
    const local_path =document.getElementById('local_path').value;;
    ajax_get_filelist(base_path, local_path);
    
    //路径输入
    let isPathInputActive = false; // 标志变量，用于跟踪路径输入是否激活  
    function path_change_click() {  
        console.log('path_change_click');  
          
        // 设置路径输入激活状态  
        isPathInputActive = true;  
        document.getElementById('file_manager_path2').style.zIndex = '9999';
        document.getElementById('file_manager_blocks_click_region').style.display='none';
        let inputElement = document.getElementById('file_manager_path2_input');
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
       // 添加点击事件监听器  
        document.addEventListener('click', handleClickOutsideInput);  
          
        // 添加键盘事件监听器  
        document.addEventListener('keydown', handleKeydown);  
    }  
      
    function handleClickOutsideInput(event) {  
        // 检查点击是否发生在输入框之外，且不是特定按钮  
        const inputElement = document.getElementById('file_manager_path2_input');  
        const buttonElement = document.querySelector('#path_change_click_button');  
        if (isPathInputActive &&  
            !inputElement.contains(event.target) &&  
            (buttonElement === null || !buttonElement.contains(event.target))) {  
              
            // 点击发生在输入框和特定按钮之外，执行相应操作  
            document.getElementById('file_manager_path2').style.zIndex = '-1';  
            document.getElementById('file_manager_blocks_click_region').style.display = 'flex';  
              
            // 路径输入处理完成，移除监听器  
            removeListeners();  
        }  
    }  
      
    function handleKeydown(event) {  
        if (isPathInputActive && (event.key === 'Enter' || event.keyCode === 13)) {  
            // 按下了回车键，执行相应操作  
              
            // 还原z-index和显示区域  
            document.getElementById('file_manager_path2').style.zIndex = '-1';  
            document.getElementById('file_manager_blocks_click_region').style.display = 'flex';  
              
            // 路径输入处理完成，移除监听器  
            removeListeners();  
        }  
    }  
      
    function removeListeners() {  
        // 移除点击和键盘事件监听器  
        document.removeEventListener('click', handleClickOutsideInput);  
        document.removeEventListener('keydown', handleKeydown);  
          
        // 重置路径输入激活状态  
        isPathInputActive = false;  
    }  
    
    //单击文件的操作
    function file_jumpinto(file_name,filesize){
        let old_local_path    =document.getElementById('local_path').value;
        let new_local_path    =old_local_path+"/"+file_name+"/";
        new_local_path = new_local_path.replace(/\/{2,}/g, '/');
        //console.log("js将进入新文件夹：",new_local_path);
        document.getElementById('local_path_bak').value=new_local_path;
        ajax_get_filelist(base_path, new_local_path);
    }
    
    //url to link
    function dirurl_jumpinto(dirurl,is_backforward,callback){
        new_local_path = (dirurl+"/").replace(/\/{2,}/g, '/');
        //console.log("js将进入新url：",new_local_path);
        document.getElementById('local_path_bak').value=new_local_path;
        ajax_get_filelist(base_path, new_local_path,"",is_backforward,function(){if(callback){callback();}});
    }
    
    //path_back_click
    /*function path_back_click(){
        /* 只是删除最后一个层级，没啥意义，还是回溯和前进历史比较好
        let old_local_path    =document.getElementById('local_path').value;
        let lastSlashIndex = old_local_path.lastIndexOf('/');
        // 如果路径中有斜杠
        if (lastSlashIndex !== -1) {
            let new_local_path=old_local_path.substring(0, lastSlashIndex); 
            document.getElementById('local_path').value=new_local_path;
            document.getElementById('local_path_bak').value=new_local_path;
            ajax_get_filelist(base_path, new_local_path);
        }
    }*/
    
    function path_back_click() {
        let old_local_path = document.getElementById('local_path').value;let new_local_path = '';
        if (local_path_history.length > 1) {
            let lastPath = local_path_history.pop();    local_path_history2.unshift(lastPath);     // 移除local_path_history最后个元素并添加到 local_path_history2的开头
            new_local_path = local_path_history[local_path_history.length-1]; } 
        else { new_local_path = old_local_path;}
        document.getElementById('local_path').value=new_local_path;
        dirurl_jumpinto(new_local_path,"is_backforward");
        console.log(local_path_history,local_path_history2);
        //console.log("local_path_history1/2:",local_path_history,local_path_history2);
        //console.log("新地址：",new_local_path);
    }

    function path_forword_click(){
        let old_local_path = document.getElementById('local_path').value;let new_local_path = '';
        if(local_path_history2.length > 0){
            let firstPath = local_path_history2.shift();        local_path_history.push(firstPath);      // 移除local_path_history2第一个元素并添加到 local_path_history
            new_local_path = firstPath; }  
        else{new_local_path = old_local_path;}
        document.getElementById('local_path').value=new_local_path;
        dirurl_jumpinto(new_local_path,"is_backforward");
        console.log(local_path_history,local_path_history2);
        //console.log("local_path_history1/2:",local_path_history,local_path_history2);
        //console.log("新地址：",new_local_path);
    }
    
    function path_refresh_click(colored_list,callback){
        let old_local_path    =document.getElementById('local_path').value;
        ajax_get_filelist(base_path, old_local_path,colored_list,'',function(){
            if(callback){callback();}
        });//function ajax_get_filelist(base_path, local_path, colored_list,is_backforward,callback)
        
    }
    
    //url按回车 或 监听失去焦点事件
    document.getElementById('file_manager_path2_input').addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // 阻止默认的提交行为
            handlePathUpdate(); // 处理路径更新
        }
    });
    document.getElementById('file_manager_path2_input').addEventListener('blur', function() {
        handlePathUpdate(); // 处理路径更新
    });
    function handlePathUpdate() {
        var inputElement = document.getElementById('file_manager_path2_input');
        var inputValue = inputElement.value; // 获取输入框的值
        console.log("用户输入的路径是:", inputValue);
        // 处理路径
        let new_local_path = inputValue.replace(/^\/?home\//, '/').replace(/\/{2,}/g, '/'); // 去掉以 "/home/" 或 "home/" 开头的部分
        // 更新隐藏字段值
        document.getElementById('local_path_bak').value = new_local_path;
        // 调用 ajax_get_filelist 函数
        ajax_get_filelist(base_path, new_local_path);
    }    
    
    
    //url的>扩展
    function dir_expand_click(dir_expand_num,new_local_path){
        console.log("dir_expand_num,new_local_path:",dir_expand_num,new_local_path);
        fetch('function_file_get_filelist.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'action':'get_dir',
                'base_path': base_path ,
                'local_path': new_local_path,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            let dropdown_html='';
            raw_result.forEach((item) => {
                if (item != "") { 
                    let part_local_path=new_local_path+"/"+item;
                    dropdown_html+= `   <div onclick="dirurl_jumpinto('${part_local_path}')">   
                                            ${item}
                                        </div>`;
                }
            });
            //改写
            let dir_expand_num_dropdown=document.getElementById(dir_expand_num+"_dropdown");
            dir_expand_num_dropdown.innerHTML=dropdown_html;
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            if (error.message == "没有那个文件或目录") {
                document.getElementById('file_manager_path2_input').value = "/home" + document.getElementById('local_path').value;
                let innerHTML = '没有下级目录了';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else if (error.message == "错误的路径格式") {
                document.getElementById('file_manager_path2_input').value = "/home" + document.getElementById('local_path').value;
                let innerHTML = '错误的路径格式，路径已还原';
                showAndFadeOut('error', 2000, 3,innerHTML);
                return;
            }
            else{
                // 处理其他未知错误
                let innerHTML = '发生未知错误，请稍后再试';
                showAndFadeOut('error', 2000, 3,innerHTML);
            }
        });
    }
    
    
    function create_dir_click() {  
        console.log("操作: create_dir_click");  
        const newFolderTr = document.getElementById('new_folder_tr');  
        const inputElement = document.getElementById('new_folder_tr_input');  
          
        // 显示新文件夹输入行  
        newFolderTr.style.display = "table-row";  
          
        // 聚焦到输入框并移动光标到末尾  
        inputElement.focus();  
        let value = inputElement.value;  
        inputElement.value = ''; // 清空内容以重置光标位置（这一步可能是多余的，除非有特定需求）  
        inputElement.value = value; // 重新设置内容  
          
        //
        let submitted = false; // 标志位：是否已提交
        function handleSubmit(){
            if(submitted){return false;}
            new_value=inputElement.value;
            file_operate("新建", "文件夹", new_value);  
            event.preventDefault(); 
            submitted=true;
        }
        // 监听失去焦点
        // 监听失去焦点事件
         inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            handleSubmit();
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                handleSubmit();
            }
        });  
    }  
    
    //create_txt_click
    function create_txt_click(){
        console.log("操作: create_txt_click");
        document.getElementById('new_file_tr').style.display = "table-row";
        // 将光标移到文本末尾
        let inputElement = document.getElementById('new_file_tr_input');
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
        
        let new_value= inputElement.value;
        //
        let submitted = false; // 标志位：是否已提交
        function handleSubmit(){
            if(submitted){return false;}
            new_value=inputElement.value;
            file_operate("新建","文件",new_value);
            event.preventDefault(); 
            submitted=true;
        }
        // 监听失去焦点
        // 监听失去焦点事件
         inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            handleSubmit();
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                handleSubmit();
            }
        });
    }
    
    function formatBytes(bytes, decimalPlaces = 2) {
        if (bytes == 0) return '0 ';
        if (isNaN(bytes) || !isFinite(bytes)) return 'Invalid Bytes';
    
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        // 确保不超过GB单位（根据需求可扩展TB）
        const clampedIndex = Math.min(i, sizes.length - 1);
        
        // 计算转换后的值（保留指定位小数）
        const formattedValue = parseFloat(
            (bytes / Math.pow(k, clampedIndex)).toFixed(decimalPlaces)
        );
        
        return `${formattedValue} ${sizes[clampedIndex]}`;
    }
    function cal_dir_size(file_name){
        console.log('cal_dir_size');
        let local_path= document.getElementById('local_path').value;
        let file_complete_path=base_path + local_path + "/" + file_name;
        // 发起请求
        fetch('function_file_get_dirsize.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                dir_complete_path: file_complete_path,
            }),
        })
        .then(response => {
            if (!response.ok) {
                // 尝试解析错误响应（假设后端返回JSON错误）
                return response.json().then(err => {
                    throw new Error(err.message || 'Unknown server error');
                });
            }
            return response.json();
        })
        .then(data => {
            // 验证响应数据结构
            if (!data || data.status === undefined) {
                throw new Error('Invalid response format');
            }
    
            if (data.status === 'success') {
                console.log('Directory size:', data);
                let formatsize=formatBytes(data.bytes);
                showAndFadeOut('success', 2000, 3, formatsize || 'No size data');
            } else {
                throw new Error(data.message || 'Operation failed');
            }
        })
        .catch(error => {
            console.error('Error:', error.message);
            showAndFadeOut('error', 3000, 3, `Error: ${error.message}`);
        });
    }
    
    
    function file_open(file_name, filesize) {
        let local_path= document.getElementById('local_path').value;
        let file_complete_path=base_path + local_path + "/" + file_name;
        let file_web_path = file_complete_path.substring(21);
        console.log("file_web_path", file_web_path);
        //显示一个题目，路径
        document.getElementById('main_content_part3').style.display="flex";

        document.getElementById('file_preview_head').innerHTML=("/home/"+local_path+'/'+file_name).replace(/\/+/g, '/')+`<img style='position:relative;left:10px;cursor:pointer;top:3px' src='/000_image/svg_refresh.svg' onclick="file_open2('${file_name}','${local_path}')">`;;
        document.getElementById('file_preview_close').style.display="block";
        //
        var ext = file_name.split('.').pop().toLowerCase();
        //console.log("ext:",ext);
        var file_preview_inner = document.getElementById('file_preview_inner');
        file_preview_inner.innerHTML = ''; // 清空之前的内容
        if (['png', 'jpeg', 'jpg', 'tif', 'svg'].includes(ext)) {
            // 处理图片或 SVG 文件
            var img = document.createElement('img');
            img.src = file_web_path; // 使用完整的文件路径
            img.style.maxWidth = '100%';
            file_preview_inner.appendChild(img);
        } 
        else if (ext === 'pdf') {
            // 处理 PDF 文件
            var pdfEmbed = document.createElement('embed');
            pdfEmbed.src = file_web_path; // 使用完整的文件路径
            pdfEmbed.type = 'application/pdf';
            pdfEmbed.style.width = '100%';
            
            // 动态计算高度
            var viewportHeight = window.innerHeight;
            var offsetHeight = 150; // 需要减去的像素值
            var newHeight = viewportHeight - offsetHeight;
            pdfEmbed.style.height = `${newHeight}px`;
            
            file_preview_inner.appendChild(pdfEmbed);
        } 
        else if (ext === 'html') {
            console.log('展示html');
            fetch(file_web_path)
                .then(response => response.text())
                .then(html => {
                    const blob = new Blob([html], { type: 'text/html' });
                    const blobUrl = URL.createObjectURL(blob);
                    
                    const iframe = document.createElement('iframe');
                    iframe.src = blobUrl;
                    iframe.style.width = '100%';
                    iframe.style.height = `${window.innerHeight - 150}px`;
                    iframe.style.border = 'none';
                    
                    // 可选：页面卸载时释放 blob URL，避免内存泄漏
                    iframe.onload = () => URL.revokeObjectURL(blobUrl);
                    
                    file_preview_inner.appendChild(iframe);
                })
                .catch(error => {
                    console.error('Error loading HTML:', error);
                    file_preview_inner.innerHTML = 'HTML 文件加载失败。';
                });
        }
        else {
            // 处理任何类型的文件
            fetch(`/function_file_preview.php?filename=${encodeURIComponent(file_complete_path)}`)
                .then(response => response.text()) // 直接获取文本内容
                .then(text => {
                    //file_preview_inner.innerHTML = `${text}`;//
                    file_preview_inner.innerHTML = `<pre style="white-space: pre-wrap; text-align: left;">${text}</pre>`;
                    if (text.length >= 104857) {  // 如果内容接近1MB，提示用户1048576
                        file_preview_inner.innerHTML += `<br>文件内容过大，仅显示前 0.1MB 内容。`;
                    }
                })
                .catch(error => {
                    console.error('Error loading file:', error);
                    file_preview_inner.innerHTML = '文件加载失败。';
                });
        }   
    }
    //file_open2刷新用
    function file_open2(file_name,local_path){
        let file_complete_path=base_path + local_path + "/" + file_name;
        let file_web_path = file_complete_path.substring(21);
        console.log("file_web_path", file_web_path);
        //显示一个题目，路径
        document.getElementById('file_preview_head').innerHTML=("/home/"+local_path+'/'+file_name).replace(/\/+/g, '/')+`<img style='position:relative;left:10px;cursor:pointer;top:3px' src='/000_image/svg_refresh.svg' onclick="file_open2('${file_name}','${local_path}')">`;;
        document.getElementById('file_preview_close').style.display="block";
        //
        const ext = file_name.split('.').pop().toLowerCase();
        console.log("ext:",ext);
        const file_preview_inner = document.getElementById('file_preview_inner');
        file_preview_inner.innerHTML = ''; // 清空之前的内容
        if (['png', 'jpeg', 'jpg', 'tif', 'svg'].includes(ext)) {
            // 处理图片或 SVG 文件
            const img = document.createElement('img');
            img.src = file_web_path; // 使用完整的文件路径
            img.style.maxWidth = '100%';
            file_preview_inner.appendChild(img);
        } 
        else if (ext === 'pdf') {
            // 处理 PDF 文件
            const pdfEmbed = document.createElement('embed');
            pdfEmbed.src = file_web_path; // 使用完整的文件路径
            pdfEmbed.type = 'application/pdf';
            pdfEmbed.style.width = '100%';
            
            // 动态计算高度
            const viewportHeight = window.innerHeight;
            const offsetHeight = 150; // 需要减去的像素值
            const newHeight = viewportHeight - offsetHeight;
            pdfEmbed.style.height = `${newHeight}px`;
            
            file_preview_inner.appendChild(pdfEmbed);
        } 
        else if (ext === 'html') {
            console.log('展示html');
            fetch(file_web_path)
                .then(response => response.text())
                .then(html => {
                    const blob = new Blob([html], { type: 'text/html' });
                    const blobUrl = URL.createObjectURL(blob);
                    
                    const iframe = document.createElement('iframe');
                    iframe.src = blobUrl;
                    iframe.style.width = '100%';
                    iframe.style.height = `${window.innerHeight - 150}px`;
                    iframe.style.border = 'none';
                    
                    // 可选：页面卸载时释放 blob URL，避免内存泄漏
                    iframe.onload = () => URL.revokeObjectURL(blobUrl);
                    
                    file_preview_inner.appendChild(iframe);
                })
                .catch(error => {
                    console.error('Error loading HTML:', error);
                    file_preview_inner.innerHTML = 'HTML 文件加载失败。';
                });
        }
        else {
            // 处理任何类型的文件
            fetch(`/function_file_preview.php?filename=${encodeURIComponent(file_complete_path)}`)
                .then(response => response.text()) // 直接获取文本内容
                .then(text => {
                    //file_preview_inner.innerHTML = `${text}`;//
                    file_preview_inner.innerHTML = `<pre style="white-space: pre-wrap; text-align: left;">${text}</pre>`;
                    if (text.length >= 104857) {  // 如果内容接近1MB，提示用户1048576
                        file_preview_inner.innerHTML += `<br>文件内容过大，仅显示前 0.1MB 内容。`;
                    }
                })
                .catch(error => {
                    console.error('Error loading file:', error);
                    file_preview_inner.innerHTML = '文件加载失败。';
                });
        }           
        
    }
    
    function file_preview_close_click(){
        document.getElementById('main_content_part3').style.display="none";
        document.getElementById('file_preview_head').innerHTML='';
        document.getElementById('file_preview_inner').innerHTML = ''; // 清空之前的内容
        document.getElementById('file_preview_close').style.display="none";
    }
    
    // 添加点击事件监听器
    document.querySelectorAll('.file_name').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            var file_name = e.target.dataset.filename;
            var filesize = parseInt(e.target.dataset.filesize, 10); // 获取文件大小
            file_open(file_name, filesize);
        });
    });

    
    function file_operate(operate,file_type,file_name,file_name_new_object){
        console.log(operate,file_type,file_name);
        if(operate=="新建文件"||operate=="新建文件夹"){}
        
        if(operate=="删除"||operate=="复制"||operate=="压缩"){
            if(confirm("你确定要执行 " + operate + " 操作吗？")==false){
                return false;
            }; 
        }
        
       
        let file_name_new='';
        if(operate=="重命名"){
            if(file_name_new_object.value==''){
                file_name_new_object.value=file_name;
                showAndFadeOut('error', 2000, 3,"重命名不能为空"); 
                return false;
            }
            else{
                file_name_new=file_name_new_object.value;
            }
        }
        
        let local_path=document.getElementById('local_path').value;
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'file_type':file_type,
                'file_name':file_name,
                'file_name_new':file_name_new,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });       
    };
    function code_editor_generate(file_path,file_name){
        console.log(file_path,file_name);
        
        editor_start(file_path,file_name,"<?php echo $select_theme_TXT;?>","<?php echo $select_wrap_TXT;?>");
    }
    function file_operate_multi(operate){    /*用于批量删除和批量压缩*/
        console.log(operate);
        let all_checkbox_value=Array.from(checkboxValuesSet).join('_;;;_');
        let local_path=document.getElementById('local_path').value;
        if(all_checkbox_value==""){
            showAndFadeOut('error', 2000, 3,"需要选中至少一个文件/文件夹");return false;
        }
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'all_checkbox_value':all_checkbox_value,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });  
    }
    function file_operate_multi_mv(operate){    /*仅用于剪切功能*/
        console.log(operate);
        let all_checkbox_value=document.getElementById('all_checkbox_value').value;
        let all_checkbox_value_localpath=document.getElementById('all_checkbox_value_localpath').value;
        let local_path=document.getElementById('local_path').value;
        if(all_checkbox_value==""){
            showAndFadeOut('error', 2000, 3,"需要选中至少一个文件/文件夹");return false;
        }
        fetch('function_file_operate.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({ 
                'base_path': base_path ,
                'local_path': local_path,
                'operate':operate,
                'all_checkbox_value':all_checkbox_value,
                'all_checkbox_value_localpath':all_checkbox_value_localpath,
            }), 
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log(data);
            showAndFadeOut('success', 2000, 3,raw_result);
            if(data.status=='success'){
                path_refresh_click();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            console.log('错误消息:', error.message); // 查看错误消息
            // 如果是文件或目录不存在的错误
            showAndFadeOut('error', 2000, 5,error.message);
            path_refresh_click();
        });  
    }
    
    //处理错误/成功/tip信息
    // 渐显并渐隐函数
    /*
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        var div = document.getElementById("top_message");
        let message_text_new='';
        if (message_type == "error") {      
                div.style.backgroundColor = "rgb(255, 255, 153)";  message_text_new="<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> "+message_text;  } 
        else if (message_type == "success") {
                div.style.backgroundColor = "#e5ffe5"; message_text_new="<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> "+message_text;}
        else {div.style.backgroundColor = "gray"; }
        div.innerHTML = message_text_new;
        if (div) {
            div.style.display = 'block'; // 使div可见
            div.style.opacity = 1; // 将透明度设为 1 (完全可见)
            
            // 延时后开始渐隐
            setTimeout(function() {
                div.style.transition = `opacity ${fadeDuration}s ease-in-out`;
                div.style.opacity = 0; // 开始渐隐
                
                // 渐隐完成后隐藏元素
                setTimeout(function() {
                    div.style.display = 'none';
                }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
            }, delayBeforeFade);
        }
    }*/
    function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
        // 创建新的消息元素
        var div = document.createElement("div");
        div.className = "message-box"; // 应用样式类
    
        let message_text_new = '';
        
        // 根据消息类型设置背景颜色和内容
        if (message_type == "error") {
            div.style.backgroundColor = "rgb(255, 255, 153)";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> " + message_text;
        } else if (message_type == "success") {
            div.style.backgroundColor = "#e5ffe5";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> " + message_text;
        } else if (message_type == "warn") {
            div.style.backgroundColor = "#ffff99";
            message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_warn.svg'> " + message_text;            
        } else {
            div.style.backgroundColor = "gray";
            message_text_new = message_text;
        }
    
        div.innerHTML = message_text_new;
        div.style.transition = `opacity ${fadeDuration}s ease-in-out`; // 动态设置渐隐时长
    
        // 将新的消息元素添加到 body
        document.body.appendChild(div);
    
        // 动态调整所有消息的 vertical 位置，防止重叠
        adjustMessagesPosition();
    
        // 延时后开始渐隐
        setTimeout(function() {
            div.style.opacity = 0; // 开始渐隐
            
            // 渐隐完成后移除元素
            setTimeout(function() {
                document.body.removeChild(div);
                adjustMessagesPosition(); // 调整剩余消息的位置
            }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
        }, delayBeforeFade);
    }
    // 动态调整所有消息的位置，防止重叠
    function adjustMessagesPosition() {
        var messages = document.querySelectorAll('.message-box'); // 选择所有消息元素
        let currentTop = 0; // 从顶部开始，预留一些空间
    
        messages.forEach(message => {
            message.style.top = `${currentTop}px`;
            currentTop += message.offsetHeight + 2; // 累加消息高度和间距
        });
    }
    
    //显示与隐藏
        let currentObjectId = null;

        function show_and_hide(object_id) {
            var dropArea = document.getElementById(object_id);
            var isVisible = dropArea.style.display === 'block';

            // Update currentObjectId
            currentObjectId = object_id;

            dropArea.style.display = isVisible ? 'none' : 'block';
        }

        document.addEventListener('click', function(event) {
            // Ensure currentObjectId is valid
            if (currentObjectId) {
                var dropArea = document.getElementById(currentObjectId);

                // Check if the click was outside the drop area
                if (!dropArea.contains(event.target) && event.target.closest('.toggle-btn') === null) {
                    dropArea.style.display = 'none';
                    currentObjectId = null; // Reset currentObjectId
                }
            }
        });
    
    
    
    
    //复选框
    function all_checkbox_click(){
        let all_checkbox_state_old = document.getElementById("all_checkbox_state").value;
        let all_checkbox_state_new='';
        if (all_checkbox_state_old==0){     all_checkbox_state_new=1;}
        else{                               all_checkbox_state_new=0;}
        document.getElementById("all_checkbox_state").value=all_checkbox_state_new;
        console.log("所有复选框state:",all_checkbox_state_old,"变为",all_checkbox_state_new);
        let select_checkboxes = document.querySelectorAll('.select_checkbox');
        if (all_checkbox_state_new==1){
            select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = true;
                checkboxValuesSet.add(checkbox.value);  // 将值添加到 Set 中
            });
        }
        else{
             select_checkboxes.forEach(function(checkbox) {
                checkbox.checked = false;
            });
            checkboxValuesSet.clear();  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}

    }
    
    function one_checkbox_click(this_checkbox) {
        // 检查当前复选框的状态
        if (this_checkbox.checked) {
            checkboxValuesSet.add(this_checkbox.value);  // 将值添加到 Set 中
        }
        else{
            // 如果当前复选框不是选中的状态，则将 all_checkbox_state 设为 0
            document.querySelector('#all_checkbox_state').value=0;
            document.querySelector('#all_checkbox').checked = false;
            checkboxValuesSet.delete(this_checkbox.value);  // 将值添加到 Set 中
        }
        //console.log("checkboxValuesSet",checkboxValuesSet);
        let selected_num=checkboxValuesSet.size;
        let selected_num_show=document.getElementById("checkbox_selected_num");
        if(selected_num>0){     selected_num_show.innerText=selected_num+"";}
        else{                   selected_num_show.innerText="";}
    }
    
    //////
    function projectdir_mark(){
        let local_path=document.getElementById('local_path').value;
        let project_path_show="/home"+local_path;
        document.getElementById("projectdir_mark_div_txt").innerHTML=`<span onclick="dirurl_jumpinto('${local_path}')">${project_path_show}</span>`;
        showAndFadeOut('success', 2000, 3,'项目目录设置为：'+project_path_show);
        document.getElementById('current_project_dir_state_hidden').value='static';
        refresh_project_click("初始化aihwgklhasd");
        document.getElementById("projectdir_mark_div_right").style.display="block";
    }
    function projectdir_mark_clear(){
        document.getElementById("projectdir_mark_div_txt").innerHTML=``;
        showAndFadeOut('success', 2000, 3,'项目目录动态获取');
        document.getElementById('current_project_dir_state_hidden').value='dynamic';
        document.getElementById("projectdir_mark_div_right").style.display="none";
    }
     
    /*批量剪接功能*/
    function collect_checkboxs(){
        console.log("collect_checkboxs");
        console.log(checkboxValuesSet);
        let checkboxValuesSet_num=checkboxValuesSet.size;
        // 初始化计数器  
        let fileCount = 0;  let folderCount = 0;  
        checkboxValuesSet.forEach(item => {  
            let [name, type] = item.split('_||_');  
            if (type === '文件') {  fileCount++;  } 
            else if (type === '文件夹') {  folderCount++;  }  
        });  
        if(checkboxValuesSet_num==0){
            document.getElementById("all_checkbox_value").value='';
            document.getElementById("all_checkbox_value_localpath").value= '';           
            document.getElementById("collect_num_show").innerText=``;
            showAndFadeOut('error', 2000, 3,"请至少选择一个复选框");return false;
        }
        else{
            showAndFadeOut('success', 2000, 3,`选择了${folderCount}文件夹，选择了${fileCount}个文件`);
        }
        //SET转str
        let checkboxValuesSet_str = Array.from(checkboxValuesSet).join('_;;;_');
        document.getElementById("all_checkbox_value").value=checkboxValuesSet_str;
        document.getElementById("all_checkbox_value_localpath").value=document.getElementById('local_path').value;
        document.getElementById("collect_num_show").innerText=`选中${checkboxValuesSet_num}`;
        checkboxValuesSet.clear();
    }
    function collect_checkboxs_mvfile(){
        console.log("collect_checkboxs_mvfile");
        let all_checkbox_value=document.getElementById("all_checkbox_value").value;
        let all_checkbox_value_localpath=document.getElementById("all_checkbox_value_localpath").value;
        let local_path=document.getElementById("local_path").value;
        console.log(all_checkbox_value,all_checkbox_value_localpath,local_path);
        if(all_checkbox_value==''){showAndFadeOut('error', 2000, 3,"尚未剪切文件，请勾选复选框后点击剪刀图标");return false;}
        if(all_checkbox_value_localpath==local_path){showAndFadeOut('error', 2000, 3,"剪切文件后，需要粘贴至新目录");return false;}
        //判断父文件夹剪切后，自己下级粘贴的情况
        let all_checkbox_arr = all_checkbox_value.split('_;;;_');  
        for (let item of all_checkbox_arr) {
            let [name, type] = item.split('_||_');  
            console.log(local_path, all_checkbox_value_localpath + name);
            if (type === "文件夹" && local_path.startsWith(all_checkbox_value_localpath + name)) {
                showAndFadeOut('error', 2000, 3, "无法将文件夹剪切至其自身内部");
                return false;  // 退出函数，阻止后续代码执行
            }
        }
        //
        file_operate_multi_mv('批量移动');
        document.getElementById("collect_num_show").innerText=``;
    }
</script>
<script>
    const userid='<?php echo $user_name_id;?>';

    refresh_project_click();
    function refresh_project_click(colored_itemid,callback){
        if(colored_itemid=="初始化aihwgklhasd"){ // && colored_itemid=="初始化"      只要有值就初始化
            document.getElementById('current_page_hidden').value='1';
            document.getElementById('current_searchword_hidden').value='';
            document.getElementById('current_sortcol_hidden').value='';
            document.getElementById('current_sortcol_direction_hidden').value='desc';
            colored_itemid='';
        }
        
        let projectdir=document.getElementById('local_path').value;
        let projectdir_database="/home"+projectdir;
        let page=document.getElementById('current_page_hidden').value;
        let searchword=document.getElementById('current_searchword_hidden').value;
        let sortcol=document.getElementById('current_sortcol_hidden').value;
        let sortdirection=document.getElementById('current_sortcol_direction_hidden').value;
        let num_per_page=document.getElementById('current_num_per_page_hidden').value;
        
        //console.log("refresh_project_click_____action:",projectdir,page,searchword,sortcol,sortdirection,colored_itemid);
        console.log("project的目录为：",projectdir_database)
        fetch('function_project_get_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':'refresh_project',
                'projectdir':projectdir_database,
                'page':page,
                'searchword':searchword,
                'sortcol':sortcol,
                'sortdirection':sortdirection,
                'num_per_page':num_per_page,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            //console.log(data);
            let raw_result=data.result;
            let result_num=data.result_num;
            let page_num=data.page_num;
            document.getElementById("current_page_sum_hidden").value=page_num; 
            let current_page=document.getElementById("current_page_hidden").value; 
            //console.log(data);
            //console.log("data.result:",data.result);
            //console.log("data.result_num:",result_num);
            //
            // 假设你有一个select元素  
            let selectHTML = ``;  let current_page_str='';
            for (let i = 1; i <= page_num; i++) {  
                if(current_page==i){current_page_str='selected';}else{current_page_str='';}
                selectHTML += `<option value='${i}' ${current_page_str}>${i}</option>`;  
            }  
            //
            let marked_col_id='';
            if (sortcol!=''){
                if(sortcol=='创建时间'){marked_col_id='table1_th1';}
                else if(sortcol=='唯一识别码'){marked_col_id='table1_th2';}
                else if(sortcol=='名称'){marked_col_id='table1_th3';}
                else if(sortcol=='描述'){marked_col_id='table1_th4';}
                else if(sortcol=='更新时间'){marked_col_id='table1_th5';}
                else if(sortcol=='项目目录'){marked_col_id='table1_th6';}
                /*else if(sortcol=='使用模块'){marked_col_id='th8';}
                else if(sortcol=='模板预设'){marked_col_id='th9';}
                else if(sortcol=='参数预设'){marked_col_id='th10';}
                else if(sortcol=='备注信息'){marked_col_id='th11';}*/
            }    
            
            let current_time=getCurrentTime();
            let table1=`         
                            <div style='width:100%;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:stretch;align-items:flex-start' >
                                <div style='flex:1;color:#cc0066;font-size:15px;font-weight:bold;margin-left:0;cursor:pointer;' class='project_top_right' onclick="refresh_project_click('初始化aihwgklhasd')">
                                    <div>
                                        <span  >项目列表</span>
                                        <span style='white-space:break-all;word-break: break-all;'>/home${projectdir}</span>
                                        <span  style="color:#0099cc;font-size:xx-small" id='task_refresh'>&nbsp;[刷新]</span>
                                    </div>    
                                </div>    
                                <div style='flex:none;'>
                                    <div id='project_show_option_inner2'>
                                        <div id='project_show_option_inner2_inner'>
                                            <div>
                                                <input type='text' id='search_input'></input>
                                            </div>    
                                            <div>  
                                                <div id="project_show_option_inner2_inner_div" onclick='search_input_click()'>
                                                    <img style='' src="000_image/svg_magnify.svg">
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>            
                            <table class="info_table">
                                <tr class=''>
                                    <td colspan='8' style='vertical-align:bottom'>
                                        <div id='table_top'>
                                            <div id='table_top_1'>
                                                <div><span  style='cursor:pointer' class='refresh_time' onclick="refresh_project_click()">刷新时间: ${current_time}</span></div> 
                                                <div class='table_top_2_function'>
                                                    <button class='table_top_2_function_button' onclick='create_project_click()'>新建项目</button>
                                                    <button class='table_top_2_function_button' onclick='clear_project_click()'>清空项目</button>
                                                </div>  
                                            </div>  
                                            <div id='table_top_2'>
                                                <div class='num_per_page'>                  
                                                    <span onclick="num_per_page_click('1')">1</span>|<span onclick="num_per_page_click('5')">5</span>|<span onclick="num_per_page_click('20')">20</span>|<span onclick="num_per_page_click('100')">100</span>
                                                </div>
                                                <div  id='table_top_2_page' >
                                                    <div>页码:</div>
                                                    <div class='table_top_2_page_arrow' onclick="page_click_addminus('减一')">
                                                        <img style='width:10px;height:10px' src="000_image/svg_arrow_left.svg">
                                                    </div>
                                                    <div>
                                                        <select class='studynote_page_option' id='' name='' onchange="page_click(this.value)" ondblclick='enterEditMode(this)'>
                                                            ${selectHTML}
                                                        </select>
                                                    </div>
                                                    <div class='table_top_2_page_arrow' onclick="page_click_addminus('加一')">
                                                        <img style='width:10px;height:10px' src="000_image/svg_arrow_right.svg">
                                                    </div>
                                                </div>    
                                            </div>
                                        </div>
                                    </td>
                                </tr>                                
                                <tr>
                                    <th  id='table1_th1'  onclick="th_click('table1_th1','创建时间')" >创建时间</th>
                                    <th  id='table1_th2'  onclick="th_click('table1_th2','唯一识别码')" >project ID</th>
                                    <th  id='table1_th3'  onclick="th_click('table1_th3','名称')" >项目名称</th>
                                    <th  id='table1_th4'  onclick="th_click('table1_th4','描述')" >备注信息</th>
                                    <th  id='table1_th5'  onclick="th_click('table1_th5','更新时间')" >更新时间</th>
                                    <th  id='table1_th6'  onclick="th_click('table1_th6','项目目录')" >项目目录 (点击跳转)</th>
                                    <th></th>
                                    <!--<th  id='th8'  onclick="th_click('th8','使用模块')" >使用模块</th>
                                    <th  id='th9'  onclick="th_click('th9','模板预设')" >模板预设</th>
                                    <th  id='th10'  onclick="th_click('th10','参数预设')" >参数预设</th>
                                    <th  id='th11'  onclick="th_click('th11','备注信息')" >备注信息</th>-->
                                    <!--<th style='text-align:center'></th>-->
                                </tr>
                                <tr id='new_folder_tr2' >
                                    <td colspan='2' style='text-align:right;padding-right:5px'><img style='position:relative;top:3px;height:20px;width:20px' src='/000_image/svg_function_project.svg'></td>
                                    <td colspan='5'><input type='text' id='new_folder_tr_input2' value='新建项目'></td>
                                </tr>
                                `;
            let table2=``;
            let ii=0;let serial_base=(current_page-1)*100;
            raw_result.forEach((item) => {
                ii+=1;//serial=serial_base+ii;
                
                //console.log(item);
                let item_create_time     = item["创建时间"]; 
                let item_id              = item["唯一识别码"];  
                let item_name           = item["名称"]|| "";
                let item_note            = item["描述"]|| "";
                //let item_state          = item["状态"]|| "";
                let item_update_time     = item["更新时间"]|| ""; 
                let item_project_dir     = item["项目目录"]|| ""; 
                let  item_project_dir_local = item_project_dir.replace(/^\/home/, ''); 
                /*let item_project_element     = item["使用模块"]|| ""; 
                let item_project_template     = item["模板预设"]|| ""; 
                let item_project_parameter     = item["参数预设"]|| ""; 
                let item_project_info     = item["备注信息"]|| ""; */
                //
                let colored_itemid_str='';
                if(colored_itemid==item_id){colored_itemid_str='colored_row';}
                //
                table2+=`       <tr id='${item_id}' class='${colored_itemid_str}'>
                                    <td onclick="main_input_click('${item_id}','${item_project_dir}')" style='width:71px;min-width:71px;max-width:71px' id='first_project_tr1td1'>
                                        <input  class='edited_info' style='width:71px;min-width:71px;max-width:71px' onmouseover='this.title=this.value'  value='${item_create_time}' readonly ></td>
                                    <td onclick="main_input_click('${item_id}','${item_project_dir}')" ' style='width:130px;min-width:50px;max-width:130px;'>
                                        <input id="${item_id}_projectid" class='edited_info' style='width:130px;min-width:50px;max-width:130px;' onmouseover='this.title=this.value'  value='${item_id}' readonly ></td>
                                    <td onclick="main_input_click('${item_id}','${item_project_dir}')"  style='max-width:100px;min-width:50px;width:70px'>
                                        <input  class='edited_info' onmouseover='this.title=this.value'  value='${item_name}' onchange="info_change(this,'${item_id}','名称')"></td>
                                    <td onclick="main_input_click('${item_id}','${item_project_dir}')" style="max-width:200px;min-width:70px;">
                                        <input  class='edited_info' style='border-left:solid 1px rgba(51, 102, 153,0.5);border-radius:7px;color:#004c4d;border-right:solid 1px rgba(51, 102, 153,0.5);border-radius:7px;color:#004c4d;' onmouseover='this.title=this.value'  value='${item_note}' onchange="info_change(this,'${item_id}','描述')"></td>
                   
                                    <td onclick="main_input_click('${item_id}','${item_project_dir}')"  style='width:71px;min-width:71px;max-width:71px'>
                                        <input  class='edited_info'  onmouseover='this.title=this.value'  value='${item_update_time}' readonly ></td>
                                    <td style='min-width:101px;' >
                                        <div  class='edited_info table_dirurl_link'  id='${item_id}_url' onclick="dirurl_jumpinto('${item_project_dir_local}')">${item_project_dir}</div></td>
                                    <td >
                                        <div class='table_set_td_div'>
                                            <div class='table_button_div' onclick="delete_info('${item_id}')"><img  style='height:15px;width:15px' src='/000_image/svg_button_garbage2.svg'></div>
                                        </div></td>
                                </tr>`;
                                /*<!--<td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_element}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_template}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_parameter}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_info}' ></td>-->*/
            });
            let table3=`        <tr>
                                    <td colspan='8' style='font-size:15px;color:grey;font-size:xx-small'>
                                        共<span id='result_num'></span>个项目(project)。
                                    </td>
                                </tr>

                            <table>`;
            let table_sum=table1+table2+table3;
            let contentHtml = `${table_sum}`;    
            //改内容
            document.getElementById('project_manager_content_div').innerHTML = contentHtml;   ;
            //document.getElementById('file_preview_inner').innerHTML='';
        
            //高亮被排序的列
            if(marked_col_id!=''){document.getElementById(marked_col_id).style.backgroundColor = 'rgba(51, 102, 153,0.6)';}
            
            //显示结果数量和page
            document.getElementById('result_num').innerText=result_num;
            
            //存一个当前的dir
            document.getElementById('current_project_dir_hidden').value=projectdir_database;
            
            //确定路径是否存在
            table_dirurl_link();
            
            //模拟点击第一个元素
            let first_project_tr1td1=document.getElementById('first_project_tr1td1');
            if(first_project_tr1td1){first_project_tr1td1.onclick();  }
            else{
                document.getElementById('current_project_itemid_hidden').value='';
                document.getElementById('current_page2_hidden').value='1';
                document.getElementById('current_searchword2_hidden').value='';
                document.getElementById('current_sortcol2_hidden').value='';
                document.getElementById('current_sortcol_direction2_hidden').value='desc';
                //task_manager_content_refresh();//即便是空的任务表，也应该显示下
                document.getElementById('task_manager_content').innerHTML='';
                document.getElementById('task_create_content').innerHTML='';
            }
            if(callback){callback();}
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
        });
    }
    
    
    function th_click(th_id,col_name){
        //先确定是排哪列，是升序还是降序
        //console.log('点击了列名，即将排序');
        let current_sortcol = document.getElementById("current_sortcol_hidden");                     
        let current_sortcol_direction= document.getElementById("current_sortcol_direction_hidden");  
        let current_sortcol_old=current_sortcol.value;                            let current_sortcol_new=col_name;
        let current_sortcol_direction_old=current_sortcol_direction.value;        let current_sortcol_direction_new='';
        if (current_sortcol_new==current_sortcol_old){
            if(current_sortcol_direction_old=='asc'){current_sortcol_direction_new='desc';          }
            else{                                     current_sortcol_direction_new='asc';          }
        }
        else{
            current_sortcol_direction_new='desc';
        }
        current_sortcol.value              =current_sortcol_new; 
        current_sortcol_direction.value    =current_sortcol_direction_new;
        console.log("需要排序的col和方向：",current_sortcol_new,current_sortcol_direction_new)
        refresh_project_click();
    }
    
    function search_input_click(){
        let current_searchword = document.getElementById("search_input").value;
        document.getElementById("current_searchword_hidden").value=current_searchword;
        console.log("current_searchword:",current_searchword);
        refresh_project_click();
    }

    function page_click(page){
        document.getElementById("current_page_hidden").value=page;
        console.log("page_click启动:");
        refresh_project_click();
    }    
    function page_click_addminus(addminus){
        let current_page=parseInt(document.getElementById('current_page_hidden').value);
        let page_max=parseInt(document.getElementById('current_page_sum_hidden').value);
        let new_page='';
        if (addminus=="减一"){
            let current_page_minus=current_page-1;
            if(current_page_minus==0){new_page=1;}else{new_page=current_page_minus;}
        }
        if (addminus=="加一"){
            let current_page_add=current_page+1;
            if(current_page_add>page_max){new_page=page_max;}else{new_page=current_page_add;}
        }
        console.log("新页码:",new_page);
        page_click(new_page);
        file_preview_close_click();
    } 
    
    //新建脚本
    function create_project_click(){
        console.log("操作: create_project_click2，中间的新建项目");
        document.getElementById('new_folder_tr2').style.display = "table-row";
        // 将光标移到文本末尾
        let inputElement = document.getElementById('new_folder_tr_input2');
        let new_item_id0='project_'+generateRandomString(9);
        let new_item_id1='project_'+generateRandomString(10);
        // 聚焦到输入框
        inputElement.focus();
        let value = inputElement.value;
        inputElement.value = ''; // 清空内容以重置光标位置
        inputElement.value = value; // 重新设置内容
        let new_name='';
        // 监听失去焦点事件
         inputElement.addEventListener('blur', function() {
            console.log("输入框失去焦点");
            // 在这里执行你需要的操作
            new_name = inputElement.value;
            create_project(new_item_id0,new_item_id1,new_name,function() {  
                refresh_project_click(new_item_id1);
            });
        });
        // 监听回车键按下事件
        inputElement.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                console.log("回车键按下");
                new_name = inputElement.value;
                create_project(new_item_id0,new_item_id1,new_name,function() {  
                    refresh_project_click(new_item_id1); 
                });
            }
        });
    }
    
    function create_project(new_item_id0,new_item_id1,new_name,callback){
        console.log('create_project的新脚本名:',new_name);
        let current_project_dir_hidden = document.getElementById('current_project_dir_hidden').value;
        fetch('function_project_create_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'base_path':base_path,
                'new_item_id0':new_item_id0,
                'new_item_id1':new_item_id1,
                'project_dir':current_project_dir_hidden,
                'userid':userid,
                'new_name':new_name,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                path_refresh_click();
                callback();
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
        });
    }
    function clear_project_click(){
        console.log('create_project_clear');
        // 弹出确认对话框
        
        let current_project_dir_hidden = document.getElementById('current_project_dir_hidden').value;
        var userConfirmed = confirm(`你确定要删除此文件夹内所有项目吗？\n${current_project_dir_hidden}`);
        if (!userConfirmed) {return;}// 如果用户没有确认删除，直接返回，不执行删除操作
        fetch('function_project_delete_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'dir_id':current_project_dir_hidden,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                refresh_project_click();
                showAndFadeOut('success', 2000, 3,'删除成功');
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
        });
    }    
    function delete_info(item_id){
        console.log('delete_info开始');

        // 弹出确认对话框
        var userConfirmed = confirm("你确定要删除吗？");
        if (!userConfirmed) {return;}// 如果用户没有确认删除，直接返回，不执行删除操作
        
        fetch('function_project_delete_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'item_id':item_id,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                refresh_project_click();
                showAndFadeOut('success', 2000, 3,'删除成功');
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
        });
    }
    
    function info_change(this_object,item_id,col_name){
        let input_value=this_object.value;
        console.log("info_change:",item_id,col_name,input_value);
        fetch('function_project_edit_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'item_id':item_id,
                'col_name':col_name,
                'input_value':input_value,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                //this_object.classList.remove('green_background_out');  
                this_object.classList.add('green_background');  
                setTimeout(function() {  
                    this_object.classList.remove('green_background');
                    //this_object.classList.add('green_background_out');  
                }, 3000);  
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
        });
    }
    
    function num_per_page_click(num){
        document.getElementById('current_num_per_page_hidden').value=num;
        refresh_project_click();
        showAndFadeOut('success', 2000, 3,'每页显示project数量：'+num);
    }
</script>


<script>
    function main_input_click(item_id,item_project_dir){
        let current_project_itemid_hidden = document.getElementById('current_project_itemid_hidden');
        let current_project_itemid_hidden_old=current_project_itemid_hidden.value;
        console.log("main_input_click:",current_project_itemid_hidden_old,item_id);
        
        //存一个item_project_dir
        document.getElementById('project_prepare_dir_hidden').value=item_project_dir;

        //旧的还原
        if(current_project_itemid_hidden_old!=''){
            let old_element = document.getElementById(current_project_itemid_hidden_old);
            if (old_element) { 
                old_element.classList.remove('marked_row');
                document.getElementById(current_project_itemid_hidden_old+"_projectid").classList.remove('marked_projectid');
            }
        }

        //新的要更新
        if(current_project_itemid_hidden_old!=item_id){
            current_project_itemid_hidden.value=item_id;
            refresh_section_click(item_id);
        }
        
        //无论新旧都给点击的加颜色
        document.getElementById(item_id).classList.add('marked_row');
        document.getElementById(item_id+"_projectid").classList.add('marked_projectid');
        
        task_manager_content_refresh();
    }
    
    function refresh_section_click(item_id){
        
        // 清空之前的内容
        document.getElementById('task_create_content').innerHTML = "";
        let section_content=`<div id='new_section_all'>`;
        //任务生成模块
        section_content+=   `<div id='task_prepare_div'>`;//<span style='color:#cc0066;font-size:15px;font-weight:bold;'>新建任务 </span><span style='font-size:xx-small;color:grey;cursor:pointer'  onclick="copy_str('${item_id}')">[${item_id}]</span>
        section_content+=   `<div id='task_prepare_head_div'>
                                <button  onclick='section2paste_itemid_click()'>粘贴<span>命令脚本</span>/<span>线性流程</span>/<span>网络结构</span></button>
                            </div>`;
        section_content+=   `<div id='project_prepare_list_div'></div>`
        section_content+=   `<div id='project_prepare_content_div'></div></div>`
       
        section_content+=   `</div>`
        document.getElementById('task_create_content').innerHTML =  section_content;  
        //.trim().replace(/\n/g, '');  ;
    }
    function task_create_click(item_id){
        refresh_section_click(item_id);
        
        document.getElementById('task_prepare_div').classList.add('task_prepare_div_highlight');
        setTimeout(function() {
            document.getElementById('task_prepare_div').classList.remove('task_prepare_div_highlight');
        }, 500); // 乘以1000将秒转化为毫秒
    }
    
    
    function section2paste_itemid_click(){
        console.log("section开始");
                // 将 Set 转换为数组  
        fetch('function_save2load.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'action':'提取剪切itemid',
                'target':'粘贴至project',
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            //console.log("raw_result:",raw_result);
            if(!raw_result){return false;}
            let item_array=raw_result[0]["存储变量1"].split(";");
            //console.log(item_array);
            let container = document.getElementById('project_prepare_list_div');
            let container_content='';
            container_content += `<div id='section2paste_clear' onclick="delete_all_prepare_select()">clear</div><div id='project_prepare_list_div_inner'>`;
            item_array.forEach(one =>{
                let li_itemid=one;let icon_type='';
                if (li_itemid.startsWith('script_')) {href_php="function_script"; icon_type='script';  }
                else if (li_itemid.startsWith('stream_')) {href_php="function_stream";icon_type='stream';  }
                else if (li_itemid.startsWith('structure_')) {href_php="function_structure";icon_type='structure';  }
                container_content += `<div class='project_prepare_list_div_inner_one' id='${li_itemid}' onclick="project_prepare_list_one_click('${li_itemid}')" ><div><img style='position:relative;top:0px;height:20px;width:20px' src='/000_image/svg_function_${icon_type}.svg' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')"></div><span id='project_prepare_list_one_click_button' >${li_itemid}</span></div>`;  
                //<span class='li_itemid collection_marked' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')">${li_itemid}</span>
            });
            container_content+="</div>";
            container.innerHTML =container_content;
            
            //点击第一个元素
            document.getElementById('project_prepare_item_hidden').value='';
            let first_item=item_array[0];
            project_prepare_list_one_click(first_item);
            //
            if(data.status=='success'){
                showAndFadeOut('success', 2000, 3,"已粘贴和初始化，请配置并提交项目");
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    
    function project_prepare_list_one_click(oneitem,callback){
        let project_prepare_item_hidden=document.getElementById('project_prepare_item_hidden');
        let project_prepare_item_hidden_old=project_prepare_item_hidden.value;
        //console.log("project_prepare_item_hidden_old,oneitem:",project_prepare_item_hidden_old,oneitem);
        if(project_prepare_item_hidden_old!=oneitem){document.getElementById(oneitem).classList.add('marked_project_prepare_button');project_prepare_item_hidden.value=oneitem;}
        if(project_prepare_item_hidden_old!='' && project_prepare_item_hidden_old!=oneitem){document.getElementById(project_prepare_item_hidden_old).classList.remove('marked_project_prepare_button');}
        fetch_sss_item_info(callback);
    }
    
    
    const detail_node_list=[];
    const node_replyARR_dict={};
    const variable_id_list=[];
    function fetch_sss_item_info(callback) {  
        let item_id=document.getElementById('project_prepare_item_hidden').value;
        
        console.log('fetch_sss_item_info，点击了粘贴的类型item：',item_id);
        fetch('function_project_get_info.php', {    
            method: 'POST',    
            headers: {    
                'Content-Type': 'application/json',  
            },    
            body: JSON.stringify({  
                'action': "content_simple_one",  
                'item_id': item_id,  
            }),   
        })    
        .then(response => {  
            if (!response.ok) {  
                return response.json().then(errorData => {  
                    // 抛出错误以便在 catch 中捕获  
                    throw new Error(errorData.error);  
                });  
            }  
            return response.json();  
        })  
        .then(data => {  
            let raw_result = data.result;  
            let item = raw_result[0];  

            console.log('fetch_item_info结果：', item);  
            let item_identifier          = item["唯一识别码"]; 
            let item_class1          = item["分类1"]|| "";
            let item_class2          = item["分类2"]|| "";
            let item_class3          = item["分类3"]|| "";
            let item_name            = item["名称"]|| "";  
            document.getElementById('current_task_module_name_hidden').value=item_name;
            let item_desc1           = item["描述1"]|| ""; 
            let item_desc2           = item["描述2"]|| ""; 
            let item_desc3           = item["描述3"]|| ""; 
            let thread_num          = item["线程分配"]|| ""; 
            let command_name        = item["命令名称"]|| ""; 
            let item_template        = item["模板预设"]|| "";item_template = item_template.replace(/#.*$/gm, "").trim(); 
            let item_parameter      = item["参数预设"]|| ""; item_parameter = item_parameter.replace(/#.*$/gm, "").trim();
            let item_result         = item["结果预设"]|| ""; item_result = item_result.replace(/#.*$/gm, "").trim();
            let item_variable       = item["变量预设"]|| ""; item_variable = item_variable.replace(/#.*$/gm, "").trim();
            let item_note           = item["备注信息"]|| ""; item_note = item_note.replace(/\n/g, "<br>").trim();
            let stream_content           = item["流程内容"]|| ""; 
            let structure_content           = item["网络内容"]|| ""; 
            if(structure_content){document.getElementById('structure_content_ul_value').value=structure_content;}else{document.getElementById('structure_content_ul_value').value='';}
            let container = document.getElementById('project_prepare_content_div');
            let container_innerHTML=``;
            container_innerHTML+=`<table id='project_prepare_content_div_inner_table'>`;
            container_innerHTML+=`<tr class='detail_eachpart '><td>链接</td><td class='link_td' onclick="openNewPage('${href_php}.php?searchword=${item_id}')" style='text-align:center'>link</td></tr>`;
            
            if(item_name!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>名称</td><td style='font-size:small;color:#006699;font-weight:bold'>${item_name}</td></tr>`;}
            
            if(item_class1!='' || item_class2!='' || item_class3!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>分类</td><td><div class='flex_div'>`;
                if(item_class1!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value' value='${item_class1}'></div><div class='detail_each_head'>1</div>`;}
                if(item_class2!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value' value='${item_class2}'></div><div class='detail_each_head'>2</div>`;}
                if(item_class3!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value' value='${item_class3}'></div><div class='detail_each_head'>3</div>`;}
                container_innerHTML+=`</div></td></tr>`;
            }
            
            
            if(item_desc1!='' || item_desc2!='' || item_desc3!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>描述</td><td><div class='flex_div'>`;
                if(item_desc1!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value'  value='${item_desc1}'></div><div class='detail_each_head'>1</div>`;}
                if(item_desc2!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value'  value='${item_desc2}'></div><div class='detail_each_head'>2</div>`;}
                if(item_desc3!=''){container_innerHTML+=`<div class='detail_each_content'><input readonly onmouseover='this.title=this.value'  value='${item_desc3}'></div><div class='detail_each_head'>3</div>`;}
                container_innerHTML+=`</div></td></tr>`;
            }
           
            let item_template_content_str='';
            if(item_template!=''){
                let item_template_str_new=[];let item_template_arr=item_template.split("\n");let item_template_str_new_one='';
                for(let one_raw of item_template_arr){
                    item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_raw.split('#')[0]}</span>`;
                    item_template_str_new.push(item_template_str_new_one);
                }
                item_template=item_template_str_new.join(' ').replace(/\s+/g, ' ').trim();
                item_template_content_str=`<div class='detail_each_content2'><div><span style=';color:#336699;margin-right:7px'>${command_name}</span>${item_template}</div></div>`;
            }
            let revise_hidden='';
            if (item_identifier.indexOf('script') === 0){}
            else{revise_hidden='hidden'}
            container_innerHTML+=`<tr class='detail_eachpart'><td>模板预设</td><td>${item_template_content_str}</td><td style='position:relative' ${revise_hidden}><div id='project_revise_div'><div ><input id='task_start_template_sum' placeholder='模板修订' onmouseover='this.title=this.value'></div><div><input  id='task_start_parameter_sum'  placeholder='参数修订' onmouseover='this.title=this.value'></div></div></td></tr>`;  
            
            let item_parameter_content_str='';
            if(item_parameter!=''){
                item_parameter=item_parameter.replace(/\n/g, '<br>');
                item_parameter_content_str=`<div class='detail_each_content2 dynamic_info'><div>${item_parameter}</div><input type='hidden' value='${item_parameter}'></div>`;}
            container_innerHTML+=`<tr class='detail_eachpart'><td>参数预设</td><td>${item_parameter_content_str}</td></tr>`; 
                
            if(item_result!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>结果预设</td><td><div class='detail_each_content2 dynamic_info'><div>${item_result}</div><input type='hidden' value='${item_result}'></div></td></tr>`;}        
                
            /*if(item_variable!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>变量预设</td><td><div class='detail_each_content2'>${item_variable}</div></td></tr>`;}            */
                
            if(item_note!=''){
                container_innerHTML+=`<tr class='detail_eachpart'><td>备注信息</td><td><div class='detail_each_content2'>${item_note}</div></td></tr>`;}                      
            container_innerHTML+=`</table>`;
        
            ///信息表下面的部分，输入内容
            
            let variable_inputs_str=``;
            if(item_id.startsWith("script_") || item_id.startsWith("stream_")  ){
                if(thread_num==''){thread_num='1';}
                // 创建下拉选择框的选项字符串  
                let options_str = '';  
                for (let i = 1; i <= 70; i++) {  options_str += `<option value='${i}'${i == thread_num ? ' selected' : ''}>${i}</option>`;   }  
                variable_inputs_str += `  
                    <tr>  
                        <td hidden>并行数量</td>  
                        <td hidden><select class='variable_new' id='task_start_thread_sum' onchange='this.title=this.value'>  
                                ${options_str}  
                            </select></td>  
                    </tr>`;  }
            let start_button_str=`      <div class='relative_td_info_div'  >
                                            <div class='relative_td_info_div_textdiv'>①填写变量<br>②额外修订<br>③指定范围</div>
                                        </div>
                                        
                                        <div class='relative_td_arrow_div' style='left:162px'></div>
                                        <div class='relative_td_start_div' style='left:180px'  onclick="task_start1('${item_identifier}')">
                                            <div class='relative_td_start_div_textdiv' style='font-weight:bold;'>生成任务<span>参数记录</span></div>
                                        </div>

                                        <div class='relative_td_arrow_div' style='left:262px'></div>
                                        <div class='relative_td_start_div' style='left:280px'  onclick="task_start2()">
                                            <div class='relative_td_start_div_textdiv' style='font-weight:bold;'>生成脚本<span>脚本确认</span></div>
                                        </div>
                                        
                                        <div class='relative_td_arrow_div' style='left:362px'></div>
                                        <div class='relative_td_start_div' style='left:380px'  onclick="task_start3()">
                                            <div class='relative_td_start_div_textdiv' style='font-weight:bold;'>提交作业<span>状态监控</span></div>
                                        </div>           
                                        `;
                                        /*                                         
                                        <div class='relative_td_start_div3'   onclick="task_start3()">
                                            <input type='hidden' id='taskid_hidden' value=''>
                                            <div class='relative_td_start_div3_imgdiv' >
                                                <img src='/000_image/svg_start_middle.svg' >
                                            </div>
                                            <div class='relative_td_start_div_textdiv' style='font-weight:bold;font-size:15px'>Start</div>
                                        </div> */
            //
            variable_id_list.length=0;
            if(item_variable!=''){
                // 替换换行符为空格 // 将多个空格替换为单个空格//去掉 = 号两边的空格
                let variable_arr = item_variable.replace(/\n/g, '__||;;;||__').replace(/\s+/g, ' ').replace(/\s*=\s*/g, '=').trim().split('__||;;;||__');    
                let one_variable_ii=0;
                console.log(variable_arr);
                for(let one_variable of variable_arr){
                    //console.log(one_variable);
                    //去掉#后面的内容
                    one_variable=one_variable.split("#")[0].trim();
                    // 跳过以 "=" 开头或结尾的变量）
                    if (one_variable.startsWith("=") || one_variable.endsWith("=")) {
                        continue;
                    }
                    else if (one_variable.endsWith("=?")) {
                        one_variable_ii+=1;
                        let randomColor =getRandomColor();   //随机生成一个颜色
                        let variable_id='variable_'+one_variable_ii+'_'+generateRandomString(9);                    //随机生成一个ID
                        ////如果是重复的则省略之后的，这是在script/stream/structure信息中的重复变量的错误，可以在源头避免，这个保险再验证一下
                        if(variable_id_list.includes(variable_id)){continue;}
                        else{variable_id_list.push(variable_id);}     
                        //
                        let one_variable_name=one_variable.replace(/=\?$/, '');
                        let start_button_str_real='';
                        if(one_variable_ii==1){start_button_str_real=start_button_str;}
                        variable_inputs_str += `<tr id='${one_variable_name}_tr' class='variable_tr'>
                                                    <td><span class='variable_raw' id="${variable_id}_name">${one_variable_name}</span><span class='color_icon' style='background-color:${randomColor}' id="${variable_id}_icon" onclick="variable_color_change('${variable_id}_icon')"></span></td>
                                                    <td><input class='variable_new' id="${variable_id}_value" value="${one_variable_name}"  oninput="variable_change()"></td>
                                                    <td class='relative_td'><span class='relative_td_restore_span' onclick="restore('${variable_id}_value','${one_variable_name}')">还原</span>${start_button_str_real}</td>
                                                </tr>`;}
                    else if (one_variable.includes("=")) {
                        //console.log('A');
                        one_variable_ii += 1;
                        let randomColor = getRandomColor();
                        let variable_id = 'variable_' + one_variable_ii + '_' + generateRandomString(9);
                        ////如果是重复的则省略之后的，这是在script/stream/structure信息中的重复变量的错误，可以在源头避免，这个保险再验证一下
                        if(variable_id_list.includes(variable_id)){continue;}
                        else{variable_id_list.push(variable_id);} 
                
                        let equalSignIndex = one_variable.indexOf("=");
                        let one_variable_name = one_variable.substring(0, equalSignIndex);
                        let one_variable_value = one_variable.substring(equalSignIndex + 1);
                        let start_button_str_real = '';
                        if (one_variable_ii == 1) {
                            start_button_str_real = start_button_str;
                        }
                
                        variable_inputs_str += `<tr id='${one_variable_name}_tr' class='variable_tr'>
                                                    <td><span class='variable_raw' id="${variable_id}_name">${one_variable_name}</span><span class='color_icon' style='background-color:${randomColor}' id="${variable_id}_icon" onclick="variable_color_change('${variable_id}_icon')"></span></td>
                                                    <td><input class='variable_new' id="${variable_id}_value" value="${one_variable_value}" oninput="variable_change()"></td>
                                                    <td class='relative_td'><span class='relative_td_restore_span' onclick="restore('${variable_id}_value','${one_variable_value}')">还原</span>${start_button_str_real}</td>
                                                </tr>`;
                    }                            
                }
            }
            else{
                let start_button_str_real=start_button_str;
                variable_inputs_str += `<tr><td><span class='variable_raw'>无预设变量<br>点击右侧按钮直接运行</td><td class='relative_td'>${start_button_str_real}</td></tr>`;
            }
            container_innerHTML+=`<div id='variable_input_div'><table>${variable_inputs_str}</table></div>`;
            
            container.innerHTML=container_innerHTML;      
            variable_change(); //标记颜色
            //
            container.innerHTML+=  ` <div id='item_detail_div'></div>`;
            
            let item_detail_div='';
            detail_node_list.length = 0; // 清空数组
            
            //如果是脚本
            if(item_id.startsWith("script_") ){
                if(callback){
                    callback();
                }
            }
                
            //如果是流程
            // 异步获取流程内容
            //在代码中你有一个 fetch 请求嵌套在另一个 for 循环中（针对 stream_content 的处理），每次循环都会发起新的 fetch 请求。
            //当多个异步请求并行发起时，可能会出现竞态条件（race condition），导致数据覆盖或者显示不完整。
            //解决方法：将 fetch 请求封装为一个 Promise.all 以并行处理多个请求
            else if (item_id.startsWith("stream_") && stream_content) {
                let detail_obj_content_arr = stream_content.split("_;;;_");
                Promise.all(detail_obj_content_arr.map(detail_obj_one => {
                    let detail_obj_one_arr = detail_obj_one.split("_|||_");
                    let detail_obj_node   =detail_obj_one_arr[0].trim();           detail_node_list.push(detail_obj_node);
                    let detail_obj_itemid = detail_obj_one_arr[2];
                    let template_revise =detail_obj_one_arr[3];
                    let parameter_revise = detail_obj_one_arr[4];
                    return fetch('function_project_get_info.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            'action': "content_simple_one2",
                            'item_id': detail_obj_itemid
                        }),
                    }).then(response => response.json()).then(data => {  
                        // 在这里处理数据，并返回包含所有必要信息的对象  
                        return {  
                            data: data,  
                            detail_obj_node:detail_obj_node,
                            template_revise: template_revise,  
                            parameter_revise: parameter_revise  
                        };  
                    }); 
                })).then(detail_obj_data => {  
                    let item_detail_div = document.getElementById('item_detail_div');  
                    detail_obj_data.forEach(wrappedData => {  
                        let data = wrappedData.data;  
                        let template_revise = wrappedData.template_revise;  
                        let parameter_revise = wrappedData.parameter_revise;  
                        let detail_obj_node = wrappedData.detail_obj_node.trim();  
                        //
                        let item = data.result[0];
                        let item_detail_identifier=item['唯一识别码'];
                        if (item_detail_identifier.startsWith('script_') ) {item_detail_href_php="function_script"; item_detail_icon_type='script';  }
                        else if (item_detail_identifier.startsWith('stream_')) {item_detail_href_php="function_stream";item_detail_icon_type='stream';  }
                        else if (item_detail_identifier.startsWith('structure_')) {item_detail_href_php="function_structure";item_detail_icon_type='structure';  }
                        let icon_content = `<img class='item_detail_icon' style='' src='/000_image/svg_function_${item_detail_icon_type}.svg'  onclick="openNewPage('${item_detail_href_php}.php?searchword=${item_detail_identifier}')">`;  
                        
                        let item_name           =item["名称"]|| "";    item_name =item_name.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();      
                        let command_name        = item["命令名称"]|| ""; command_name=command_name.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
                        let command_name_str='';
                        if(command_name){command_name_str =`<span style='margin-right:7px;color:#006699;font-weight:bold'>${command_name}</span>`;}

                        let item_template      = item["模板预设"]|| "";
                        let item_template_str_new=[];let item_template_arr=item_template.split("\n");let item_template_str_new_one='';
                        if(!template_revise ){
                            for(let one_raw of item_template_arr){
                                item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(0, 153, 204,0.1)' onclick='copy_str(this.innerText)'>${one_raw.split('#')[0]}</span>`;
                                item_template_str_new.push(item_template_str_new_one);
                            }
                        }
                        else{
                            let template_revise_set=new Set(template_revise.split("\n"));
                            for(let one_raw of item_template_arr){
                                let one_new=one_raw;
                                for(let one_revise of template_revise_set){
                                    if(one_raw.split("=")[0].trim()==one_revise.split("=")[0].trim()){ one_new=one_revise;template_revise_set.delete(one_revise);break;} //
                                }
                                item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(0, 153, 204,0.1)' onclick='copy_str(this.innerText)'>${one_new.split('#')[0]}</span>`;
                                item_template_str_new.push(item_template_str_new_one); 
                            }
                            //template_revise_set去掉其中替换了的还剩下额外附加的
                            if(template_revise_set.size>0){
                                for(let one_revise of template_revise_set){
                                    item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(0, 153, 204,0.1)' onclick='copy_str(this.innerText)'>${one_revise.split('#')[0]}</span>`;
                                    item_template_str_new.push(item_template_str_new_one); 
                                }
                            }
                        }
                        item_template=command_name_str+item_template_str_new.join('&nbsp;&nbsp;').replace(/\s+/g, ' ').trim();
                        
                        
                        let item_parameter      = item["参数预设"]|| "";
                        let item_parameter_str_new=[];let item_parameter_arr=item_parameter.split("\n");let item_parameter_str_new_one='';
                        if(!parameter_revise ){
                            for(let one_raw of item_parameter_arr){
                                item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_raw.split('#')[0]}</span>`;
                                item_parameter_str_new.push(item_parameter_str_new_one);
                            }
                        }
                        else{
                            let parameter_revise_set=new Set(parameter_revise.split("\n"));
                            for(let one_raw of item_parameter_arr){
                                let one_new=one_raw;
                                for(let one_revise of parameter_revise_set){
                                    if(one_raw.split("=")[0].trim()==one_revise.split("=")[0].trim()){ one_new=one_revise;parameter_revise_set.delete(one_revise);break;} //
                                }
                                item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_new.split('#')[0]}</span>`;
                                item_parameter_str_new.push(item_parameter_str_new_one); 
                            }
                            //parameter_revise_set去掉其中替换了的还剩下额外附加的
                            if(parameter_revise_set.size>0){
                                for(let one_revise of parameter_revise_set){
                                    item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_revise.split('#')[0]}</span>`;
                                    item_parameter_str_new.push(item_parameter_str_new_one); 
                                }
                            }
                        }
                        item_parameter=item_parameter_str_new.join('<br>').replace(/\s+/g, ' ').trim();
                        
                        
                        let item_detail_one='';
                        
                        if(item_name!=''){
                            item_detail_one+=`  <div class='detail_each_content3 '>    
                                                    <div>名称</div>
                                                    <div><span style='margin-right:7px;font-weight:bold;color:#009999'>${item_name}</span></div>
                                                </div>`;}   
                                                
                        if(item_template!=''){
                            item_detail_one+=`  <div class='detail_each_content3 '>    
                                                    <div>模板预设</div>
                                                    <div class='dynamic_info' style=';color:#336699;'><div>${item_template}</div><input type='hidden' value="${item_template}"></div>
                                                </div>`;}     
                            
                        if(item_parameter!=''){
                            item_detail_one+=`  <div class='detail_each_content3 '>    
                                                    <div>参数预设</div>
                                                    <div class='dynamic_info'><div>${item_parameter}</div><input type='hidden' value="${item_parameter}"></div>
                                                </div>`;}   
                                                
                        let morerevise_content=`<div class='item_detail_morerevise'><div><input  placeholder='模板修订' id='${detail_obj_node}_template_revise' onmouseover='this.title=this.value'></div><div><input placeholder='参数修订'  id='${detail_obj_node}_parameter_revise' onmouseover='this.title=this.value'></div></div>`; 
                        
                        let middle_start_content=`<div class='item_detail_startpos_middle'>`+
                                                        `<input type="radio" id="${detail_obj_node}_startRadio" class="state_radio" name="nodeid_start" value='${detail_obj_node}' onchange='radio_change()'><label for="${detail_obj_node}_startRadio" class="state_radio_label" id="${detail_obj_node}_startRadio_label">Start</label>`+
                                                        `<input type="radio" id="${detail_obj_node}_endRadio" class="state_radio" name="nodeid_end" value='${detail_obj_node}' onchange='radio_change()'><label for="${detail_obj_node}_endRadio" class="state_radio_label"  id="${detail_obj_node}_endRadio_label">End</label>`+
                                                `</div>`;
                        let each_detail_runstate=`<div class='each_detail_runstate' id="${detail_obj_node}_detailState"></div>`;
                            
                        item_detail_div.innerHTML += `<div   class='item_detail_one_div'>${icon_content}${item_detail_one}${morerevise_content}${middle_start_content}${each_detail_runstate}</div>`;
                    });
                    // 在所有异步操作完成和 DOM 更新后，调用 variable_change()  
                    variable_change(); //标记颜色
                    radio_initial();    //标记第一个为起点，最后一个为终点
                    if(callback){
                        callback();
                    }
                });
            }
            
            //如果是网络
            else if(item_id.startsWith("structure_") && structure_content){
                let detail_obj_content_arr = structure_content.split("_;;;_");
                Promise.all(detail_obj_content_arr.map(detail_obj_one => {
                    let detail_obj_one_arr = detail_obj_one.split("_|||_");
                    let detail_obj_node   =detail_obj_one_arr[0].trim();            detail_node_list.push(detail_obj_node);
                    let detail_obj_node_rely =detail_obj_one_arr[1];                node_replyARR_dict[detail_obj_node]=detail_obj_node_rely.split(';');
                    let detail_obj_itemid = detail_obj_one_arr[2];
                    let template_revise =detail_obj_one_arr[3];
                    let parameter_revise = detail_obj_one_arr[4];
                    return fetch('function_project_get_info.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            'action': "content_simple_one2",
                            'item_id': detail_obj_itemid
                        }),
                    }).then(response => response.json()).then(data => {  
                        // 在这里处理数据，并返回包含所有必要信息的对象  
                        return {  
                            data: data,  
                            detail_obj_node:detail_obj_node,
                            template_revise: template_revise,  
                            parameter_revise: parameter_revise,
                            detail_obj_node_rely:detail_obj_node_rely
                        };  
                    }); 
                })).then(detail_obj_data => {  
                    let item_detail_div = document.getElementById('item_detail_div');  
                    detail_obj_data.forEach(wrappedData => {  
                        let data = wrappedData.data;  
                        let template_revise = wrappedData.template_revise;  
                        let parameter_revise = wrappedData.parameter_revise;  
                        let detail_obj_node = wrappedData.detail_obj_node.trim(); 
                        let detail_obj_node_rely = wrappedData.detail_obj_node_rely;
                        //
                        let item = data.result[0];
                        let item_detail_identifier=item['唯一识别码'];
                        if (item_detail_identifier.startsWith('script_') ) {item_detail_href_php="function_script"; item_detail_icon_type='script';  }
                        else if (item_detail_identifier.startsWith('stream_') ) {item_detail_href_php="function_stream";item_detail_icon_type='stream';  }
                        else if (item_detail_identifier.startsWith('structure_')  ) {item_detail_href_php="function_structure";item_detail_icon_type='structure';  }
                        let icon_content = `<img class='item_detail_icon' style='' src='/000_image/svg_function_${item_detail_icon_type}.svg'  onclick="openNewPage('${item_detail_href_php}.php?searchword=${item_detail_identifier}')">`;  
                        
                        let item_name           =item["名称"]|| "";    item_name =item_name.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();                dict_node2name[detail_obj_node]=item_name;
                        let command_name        = item["命令名称"]|| ""; command_name=command_name.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
                        let command_name_str='';
                        if(command_name){command_name_str =`<span style='margin-right:7px;color:#006699;font-weight:bold'>${command_name}</span>`;}

                        
                        let item_template      = item["模板预设"]|| "";
                        let item_template_str_new=[];let item_template_arr=item_template.split("\n");let item_template_str_new_one='';
                        if(!template_revise ){
                            for(let one_raw of item_template_arr){
                                item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_raw.split('#')[0]}</span>`;
                                item_template_str_new.push(item_template_str_new_one);
                            }
                        }
                        else{
                            let template_revise_set=new Set(template_revise.split("\n"));
                            for(let one_raw of item_template_arr){
                                let one_new=one_raw;
                                for(let one_revise of template_revise_set){
                                    if(one_raw.split("=")[0].trim()==one_revise.split("=")[0].trim()){ one_new=one_revise;template_revise_set.delete(one_revise);break;} //
                                }
                                item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_new.split('#')[0]}</span>`;
                                item_template_str_new.push(item_template_str_new_one); 
                            }
                            //template_revise_set去掉其中替换了的还剩下额外附加的
                            if(template_revise_set.size>0){
                                for(let one_revise of template_revise_set){
                                    item_template_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_revise.split('#')[0]}</span>`;
                                    item_template_str_new.push(item_template_str_new_one); 
                                }
                            }
                        }
                        item_template=command_name_str+item_template_str_new.join('<br>').replace(/\s+/g, ' ').trim();
                        
                        
                        let item_parameter      = item["参数预设"]|| "";
                        let item_parameter_str_new=[];let item_parameter_arr=item_parameter.split("\n");let item_parameter_str_new_one='';
                        if(!parameter_revise ){
                            for(let one_raw of item_parameter_arr){
                                item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_raw.split('#')[0]}</span>`;
                                item_parameter_str_new.push(item_parameter_str_new_one);
                            }
                        }
                        else{
                            let parameter_revise_set=new Set(parameter_revise.split("\n"));
                            for(let one_raw of item_parameter_arr){
                                let one_new=one_raw;
                                for(let one_revise of parameter_revise_set){
                                    if(one_raw.split("=")[0].trim()==one_revise.split("=")[0].trim()){ one_new=one_revise;parameter_revise_set.delete(one_revise);break;} //
                                }
                                item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_new.split('#')[0]}</span>`;
                                item_parameter_str_new.push(item_parameter_str_new_one); 
                            }
                            //parameter_revise_set去掉其中替换了的还剩下额外附加的
                            if(parameter_revise_set.size>0){
                                for(let one_revise of parameter_revise_set){
                                    item_parameter_str_new_one=`<span class='paste_part' style='background-color:rgba(102, 102, 153,0.1)' onclick='copy_str(this.innerText)'>${one_revise.split('#')[0]}</span>`;
                                    item_parameter_str_new.push(item_parameter_str_new_one); 
                                }
                            }
                        }
                        item_parameter=item_parameter_str_new.join('<br>').replace(/\s+/g, ' ').trim();
                        
                        
                        let item_detail_one='';
                        
                        let detail_obj_node_rely_str='';
                        if(detail_obj_node_rely){
                            let detail_obj_node_rely_arr=detail_obj_node_rely.split(';');
                            let detail_obj_node_rely_arr_new=detail_obj_node_rely_arr.map(one_relynode=>{return `<span class='one_relynode_button' id="${one_relynode}_rely"  onclick='copy_str(this.innerText)'>${one_relynode}</span>`});
                            detail_obj_node_rely_str="<img src='/000_image/svg_leftarrow2.svg' style='height:10px;width:10px'>"+detail_obj_node_rely_arr_new.join(''); 
                        }
                            
                        item_detail_one+=`  <div class='detail_each_content3 '><span style='margin-right:5px;font-size:10px' onclick='copy_str(this.innerText)'>${detail_obj_node}</span>${detail_obj_node_rely_str} <span style='font-weight:bold;color:#009999;white-space:break-all'>${item_name}</span></div>    `;
                        
                        if(item_template!=''){
                            item_detail_one+=`  <div class='detail_each_content3 '>    
                                                    <div>模板预设</div>
                                                    <div class='dynamic_info' style=';color:#336699;'><div>${item_template}</div><input type='hidden' value="${item_template}"></div>
                                                </div>`;}     
                            
                        if(item_parameter!=''){
                            item_detail_one+=`  <div class='detail_each_content3 '>    
                                                    <div>参数预设</div>
                                                    <div class='dynamic_info'><div>${item_parameter}</div><input type='hidden' value="${item_parameter}"></div>
                                                </div>`;}   
                        let revise_hidden='';let hidden_div_style='';
                        if (item_detail_identifier.indexOf('script') === 0){}
                        else{revise_hidden='hidden';hidden_div_style='border: none;border-top: 1px solid grey';}
                        let morerevise_content=`<div class='item_detail_morerevise' style='${hidden_div_style}'><div ${revise_hidden}><input placeholder='模板修订'  id='${detail_obj_node}_template_revise' onmouseover='this.title=this.value' ></div><div ${revise_hidden}><input placeholder='参数修订'  id='${detail_obj_node}_parameter_revise' onmouseover='this.title=this.value' ></div></div>`; 
                        
                        let middle_start_content=`<div class='item_detail_startpos_middle'>`+
                                                        `<input type="radio" id="${detail_obj_node}_Open" class="state_radio" name="${detail_obj_node}_radio" value='${detail_obj_node}' onchange='radio_change2()' checked><label style='font-size:11px' for="${detail_obj_node}_Open" class="state_radio_label2" id="${detail_obj_node}_open_label">Open</label>`+
                                                        `<input type="radio" id="${detail_obj_node}_Close" class="state_radio" name="${detail_obj_node}_radio" value='${detail_obj_node}' onchange='radio_change2()'><label for="${detail_obj_node}_Close" class="state_radio_label3"  id="${detail_obj_node}_close_label">Close</label>`+
                                                `</div>`;
                        let each_detail_runstate=`<div class='each_detail_runstate' id="${detail_obj_node}_detailState"></div>`;
                            
                        let each_detail_jumpmark=`<div class="each_detail_jumpmark" id='${detail_obj_node}_jumpmark'></div>`;    
                        
                        
                        item_detail_div.innerHTML += `<div class='item_detail_one_div li_hover' id='${detail_obj_node}_maindiv'>${icon_content}${item_detail_one}${morerevise_content}${middle_start_content}${each_detail_runstate}${each_detail_jumpmark}</div>`;
                    });

                    // 在所有异步操作完成和 DOM 更新后，调用 variable_change()  
                    variable_change(); //标记颜色
                    
                     /*画有向图*/
                    document.getElementById('FDG_graph_state_hidden').value='1';document.getElementById('FDG_all').style.display='block';
                    document.getElementById("bottom_FDG_div").style.display ="block";document.getElementById("nodename_out").style.display ="block";refresh_FDG();
                    /*给每个detail单元绑定hover，显示节点*/
                    li_hover2main_div();
                    /*给每个detail单元里的依赖节点绑定hover，显示蓝色的其他detail_one*/
                    nodehover_To_colormark();
                    
                    radio_change2();    //标记每个open/close的状态
                    if(callback){
                        callback();
                    }   
                });
             
            }
            

        })  
        .catch(error => {    
            console.error('捕获到的错误:', error); // 查看错误的完整对象  
            showAndFadeOut('error', 2000, 3,error);
            throw error; // 可以选择重新抛出错误，以便上层调用者可以捕获  
        });  
    }  

    function delete_all_prepare_select(liId) {  
        document.getElementById('project_prepare_list_div').innerHTML="";
        document.getElementById('project_prepare_content_div').innerHTML="";;
        task_manager_content_refresh();
    } 
    /*onclick触发打开新页面，直接用a标签不知道为啥drag时能把元素直接拖出来导致错误*/
    function openNewPage(url) {
        window.open(url, '_blank'); // 在新标签页中打开指定的 URL
    }
    
    function copy_str(text) {
        // 创建一个不可见的 textarea 元素
        var textArea = document.createElement("textarea");
        textArea.value = text;
    
        // 使 textarea 不可见，但依然可以选择文本
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
    
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
    
        try {
            // 执行复制命令
            var successful = document.execCommand('copy');
            var msg = successful ? '成功' : '失败';
            console.log('文本复制' + msg);
            showAndFadeOut('success', 2000, 3,"已经将名称复制到剪切板，使用ctrl+V进行粘贴<br><span style='color:#336699'>"+text+"</span>");
            //alert('已复制到剪贴板: ' + text);
        } catch (err) {
            console.error('复制文本失败', err);
            showAndFadeOut('error', 2000, 3,error);
        }
    
        // 移除 textarea 元素
        document.body.removeChild(textArea);
    }

    //动态该变量名字
    function variable_change() {
        //console.log("variable_change");
        let dynamic_info_list = document.querySelectorAll('.dynamic_info'); // 获取所有具有 .dynamic_info 类的元素
        let variable_tr_list = document.querySelectorAll('.variable_tr');
        
        for (let one_dynamic_info of dynamic_info_list) {
            let dynamic_info_raw = one_dynamic_info.querySelector('input').value; // 获取元素内唯一的 input
            let dynamic_info_region = one_dynamic_info.querySelector('div'); // 获取元素内唯一的 div 为显示区域
            
            //
            let font_weight_bold_css='font-weight:bold';
            if (dynamic_info_region.innerText.includes('结果')) {font_weight_bold_css='';}
            
            let dynamic_info_new_value = dynamic_info_raw; // 初始化为原始值
            
            for (let one_variable_tr of variable_tr_list) {
                let one_variable_color = one_variable_tr.querySelector('.color_icon').style.backgroundColor; // 获取元素内唯一 .color_icon
                let one_variable_name_raw = one_variable_tr.querySelector('.variable_raw').innerText;   
                let one_variable_name_new = one_variable_tr.querySelector('.variable_new').value; //
                
                // 将 new_text 用 span 包裹并加上对应的颜色
                let highlighted_new_Text = `<span style="color:${one_variable_color};${font_weight_bold_css}">${one_variable_name_new}</span>`;
                
                // 替换所有匹配的旧变量名
                dynamic_info_new_value = dynamic_info_new_value.replace(new RegExp(`\\{${one_variable_name_raw}\\}`, 'g'),  `{${highlighted_new_Text}}`);
            }
            
            // 更新显示区域的 innerHTML 为替换后的值
            dynamic_info_region.innerHTML = dynamic_info_new_value;
        }
    }
    
    //还原
    function restore(input_id,input_rawvalue){
        document.getElementById(input_id).value=input_rawvalue;;
        document.getElementById(input_id).oninput();
    }
    
    //改颜色
    function variable_color_change(input_id){
        let randomColor = getRandomColor();   //随机生成一个颜色
        document.getElementById(input_id).style.backgroundColor=randomColor;
        variable_change();
    }
    

    
    function radio_initial(){
        console.log("radio_initial：",detail_node_list);
        document.getElementById(detail_node_list[0]+"_startRadio").checked='true';
        document.getElementById(detail_node_list[detail_node_list.length-1]+"_endRadio").checked='true'  ;
        radio_change();
    }
    
    const good_node_list = [];  
    function radio_change(){
        // 获取被选中的“Start”单选按钮的值  
        var startRadio = document.querySelector('input[name="nodeid_start"]:checked');  
        var startValue = startRadio ? startRadio.value : null;  
      
        // 获取被选中的“End”单选按钮的值  
        var endRadio = document.querySelector('input[name="nodeid_end"]:checked');  
        var endValue = endRadio ? endRadio.value : null;  
      
        // 输出或处理这些值  
        console.log("Selected Start Node ID:", startValue);  
        console.log("Selected End Node ID:", endValue);  
        
        //获得如果startValue的index <= endValue的index,good_node_list=从startValue至endValue的nodelist，否则good_node_list=[]
        // 初始化 good_node_list  
        good_node_list.length=0;
        if (startValue !== null && endValue !== null && detail_node_list.indexOf(startValue) <= detail_node_list.indexOf(endValue)) {  
            // 从 startValue 到 endValue 的节点加入到 good_node_list 中  
            var startIndex = detail_node_list.indexOf(startValue);  
            var endIndex = detail_node_list.indexOf(endValue);  
            good_node_list.push(...detail_node_list.slice(startIndex, endIndex + 1));  
        }  
        
        for (let onenode of detail_node_list){
            if(good_node_list.includes(onenode)){document.getElementById(onenode+'_detailState').style.backgroundColor='rgba(0, 204, 153)';}
            else{document.getElementById(onenode+'_detailState').style.backgroundColor='';}
        }
    }

    
    function radio_change2(){
        let dict_node_state={};
        // 使用 querySelectorAll 获取所有具有 class=state_radio 的元素  
        for (let onenode of detail_node_list){
            // 获取所有具有相同 name 属性的 radio 输入  
            const radios = document.getElementsByName(onenode+"_radio");  
            for (let radio of radios) {  
                if (radio.checked) {  
                    if (radio.id.endsWith("_Open")) {dict_node_state[onenode]=true;break;  } 
                    else if (radio.id.endsWith("_Close")) {dict_node_state[onenode]=false;break;  }  
                }  
            }  
        }
        //判断每个
        good_node_list.length=0;
        for (let onenode of detail_node_list){
            //开关关闭，自身是红色
            if(dict_node_state[onenode]==false){
                console.log('radio_change2, 关闭');
                document.getElementById(onenode+"_detailState").style.backgroundColor='#ff0000';  
                document.getElementById(onenode+"_false").style.display='block';
            }
            //如果开放，需要判断依赖是否开放，算了，不容易把握，除了依赖还有依赖的依赖呢。。。
            else{
                //console.log('radio_change2, 打开');
                document.getElementById(onenode+"_detailState").style.backgroundColor='#00cc00'; 
                document.getElementById(onenode+"_false").style.display='none';
                good_node_list.push(onenode);
                /*
                let onenode_denpend_list=node_replyARR_dict[onenode];
                if (onenode_denpend_list){
                    let onenode_state=true;
                    for (let onenode_denpend of onenode_denpend_list){
                        if (dict_node_state[onenode_denpend]==false){onenode_state=false;break;}
                    }
                    if(onenode_state==false){
                        console.log('radio_change2, 关闭');
                        document.getElementById(onenode+"_detailState").style.backgroundColor='#ff0000';  
                        document.getElementById(onenode+"_false").style.display='block';

                    }
                    else{
                        console.log('radio_change2, 打开');
                        document.getElementById(onenode+"_detailState").style.backgroundColor='#00cc00'; 
                        document.getElementById(onenode+"_false").style.display='none';
                        //记录下来
                        good_node_list.push(onenode);
                    }
                }
                */
            }
        }
    }
    

    function nodehover_To_colormark() {  
        // 获取所有 .one_relynode_button 元素  
        let buttons = document.querySelectorAll('.one_relynode_button');  
        buttons.forEach(button => {  
            let buttonId = button.id.slice(0, -5);;;  
            let mainElement = document.getElementById(buttonId+'_maindiv');  
            if (mainElement) {  
                button.addEventListener('mouseover', () => {  mainElement.style.backgroundColor = ' #e5f7ff';  });  
                button.addEventListener('mouseout', () => {   mainElement.style.backgroundColor = 'transparent'; });  
            } else {  
                console.warn(`No element found with id ${buttonId}'`);  
            }  
        });  
    }  
    
    function all_switch(element) {  
        console.log(element.innerText);  
        if (element.innerText === '全部Close') {  
            element.innerText = '全部Open';  
            for (let onenode of detail_node_list){
                // 获取所有具有相同 name 属性的 radio 输入  
                document.getElementById(onenode+"_Close").checked=true;  
            }
        } 
        else if (element.innerText === '全部Open') {  
            element.innerText = '全部Close';
            for (let onenode of detail_node_list){
                // 获取所有具有相同 name 属性的 radio 输入  
                document.getElementById(onenode+"_Open").checked=true;  
            }
        }  
        radio_change2(); 
    }
    
    /*判断project的table_dirurl_link目录是否存在*/
    function table_dirurl_link(){
        let elements = document.querySelectorAll('.table_dirurl_link');
        for(let one_element of elements){
            let one_url      =one_element.innerText.slice(5);;
            
            let one_item_id     =one_element.id.slice(0, -4);//console.log(one_item_id);
            let one_log_url  =one_url+'log_'+one_item_id;
            fetch('function_project_dirurl_state.php', {  
                method: 'POST',  
                headers: {  
                    'Content-Type': 'application/json',
                },  
                body: JSON.stringify({
                    'base_path':base_path,
                    /*'item_id':one_item_id,*/
                    'one_url':one_log_url,
                }), 
            })  
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        // 抛出错误以便在 catch 中捕获
                        throw new Error(errorData.error);
                    });
                }
                return response.json();
            })
            .then(data => {
                let raw_result=data.result;
                //console.log(raw_result);
                if(raw_result=="路径不存在"){
                    //
                    one_element.style.color = '#d9d9d9';
                    //
                    var trElement = document.getElementById(one_item_id);// 获取指定 id 的 tr 元素
                    if(trElement){
                        var tdElements = trElement.getElementsByTagName('input');// 获取该 tr 下所有的 td 元素
                        for (var i = 0; i < tdElements.length; i++) {// 遍历所有的 td 并修改它们的颜色
                            tdElements[i].style.color = '#b3b3b3';
                        }
                    }
                }
            })
            .catch(error => {  
                console.error('捕获到的错误:', error); // 查看错误的完整对象
                showAndFadeOut('error', 2000, 3,error);
            });
        }
        
    }
    /*判断task的table_dirurl_link目录log是否存在*/
    function table_dirurl_link2(){
        let elements = document.querySelectorAll('.table_dirurl_link2');
        for(let one_element of elements){
            let one_url      =one_element.innerText.slice(5);;//去掉开头的/home
            let one_item_id     =one_element.id.slice(0, -4);//console.log(one_item_id);    从' id='${item_id}_url'中获得id
            fetch('function_task_url_state.php', {  
                method: 'POST',  
                headers: {  
                    'Content-Type': 'application/json',
                },  
                body: JSON.stringify({
                    'base_path':base_path,
                    /*'item_id':one_item_id,*/
                    'one_url':one_url,
                }), 
            })  
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        // 抛出错误以便在 catch 中捕获
                        throw new Error(errorData.error);
                    });
                }
                return response.json();
            })
            .then(data => {
                let raw_result=data.result;
                //console.log(raw_result);
                if(raw_result=="路径不存在"){
                    //
                    one_element.style.color = '#d9d9d9';
                    //
                    var trElement = document.getElementById(one_item_id);// 获取指定 id 的 tr 元素
                    if (trElement) {
                        var tdElements = trElement.getElementsByTagName('input');// 获取该 tr 下所有的 td 元素
                        for (var i = 0; i < tdElements.length; i++) {// 遍历所有的 td 并修改它们的颜色
                            tdElements[i].style.color = '#b3b3b3';
                        }
                    }
                }
            })
            .catch(error => {  
                console.error('捕获到的错误:', error); // 查看错误的完整对象
                showAndFadeOut('error', 2000, 3,error);
            });
        }
        
    }
</script>









<script>
    function refresh_FDG() {
        var svg = d3.select("#FDG_svg"),
            width = +svg.attr("width"),
            height = +svg.attr("height");
            
        svg.selectAll("*").remove(); // 清空之前的内容
        
        var container = svg.append("g");
    
        // 添加箭头标记（保持不变）
        svg.append("defs").append("marker")
            .attr("id", "arrowhead")
            .attr("viewBox", "-0 -5 10 10")
            .attr("refX", 19)
            .attr("refY", 0)
            .attr("orient", "auto")
            .attr("markerWidth", 8)
            .attr("markerHeight", 8)
            .attr("xoverflow", "visible")
            .append("svg:path")
            .attr("d", "M 0,-5 L 10,0 L 0,5")
            .attr("fill", "#999")
            .style("stroke", "none");
        
        // 解析数据（保持不变）
        var lines = document.getElementById('structure_content_ul_value').value.split('_;;;_');
        var nodesSet = new Set();
        var edges = [];
        lines.forEach(line => {
            if (line.trim() === '') return;
            var parts = line.split('_|||_');
            if (parts.length < 5) return;
            var targetNode = parts[0].trim();
            var sourceNodes = parts[1].trim().split(';').map(node => node.trim()).filter(node => node !== '');
            nodesSet.add(targetNode);
            sourceNodes.forEach(sourceNode => {
                if (sourceNode) {
                    nodesSet.add(sourceNode);
                    edges.push({ source: sourceNode, target: targetNode });
                }
            });
        });
        var nodes = Array.from(nodesSet).map(id => ({ id: id })).reverse();
    
        // 力导向模拟（保持不变）
        var simulation = d3.forceSimulation(nodes)
            .force("link", d3.forceLink(edges).id(d => d.id).distance(20))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("x", d3.forceX(width / 2).strength(0.1))
            .force("y", d3.forceY(height / 2).strength(0.1));
        
        // 添加边（保持不变）
        var link = container.append("g")
            .attr("class", "links")
            .selectAll("line")
            .data(edges)
            .enter().append("line")
            .attr("class", "link")
            .attr("marker-end", "url(#arrowhead)");
    
        // 阴影滤镜（保持不变）
        svg.append("defs").append("filter")
            .attr("id", "drop-shadow")
            .attr("x", "-50%")
            .attr("y", "-50%")
            .attr("width", "200%")
            .attr("height", "200%")
            .append("feDropShadow")
            .attr("dx", 3)
            .attr("dy", 3)
            .attr("stdDeviation", 3)
            .attr("flood-color", "rgba(0,0,0,0.5)");
        
        // === 新增：创建持久标签组 ===
        var persistentLabels = container.append("g")
            .attr("class", "persistent-labels");
        
        // 为每个节点创建持久标签（初始隐藏）
        var labelGroups = persistentLabels.selectAll(".persistent-label")
            .data(nodes)
            .enter().append("g")
            .attr("class", "persistent-label")
            .attr("id", d => "persistent-label-" + d.id)
            .style("display", "none"); // 默认隐藏
        
        // 添加标签背景矩形和文本
        labelGroups.each(function(d) {
            var group = d3.select(this);
            // 背景矩形（可选）
            group.append("rect")
                .attr("rx",0)
                .attr("ry",0)
                .attr("width", 50) // 临时值，后面更新
                .attr("height", 20) // 临时值，后面更新
                .attr("fill", "transparent")
                //.attr("stroke", "#ccc")
                //.attr("stroke-width", 1)
                //.style("filter", "url(#drop-shadow)");
            
            // 标签文本
            group.append("text")
                .attr("class", "label-text")
                .attr("dx", 0)
                .attr("dy", 0)
                .html(d => `
                    <!--tspan style="fill:green;font-size:8px">${d.id}</tspan-->
                    <tspan x="0" dy="1" style="fill:#336699;font-size:8px;font-weight:bold">${dict_node2name[d.id] || "N/A"}</tspan>
                `);
        });
    
        // 添加节点（修改mouseover/mouseout以不干扰持久标签）
        var node = container.append("g")
            .attr("class", "nodes")
            .selectAll("circle")
            .data(nodes)
            .enter().append("circle")
            .attr("class", "node")
            .attr("r", 8)
            .style("filter", "url(#drop-shadow)")
            .attr("id", d => "FDG_" + d.id)
            .attr("fill", d => "#0099cc")
            .on("mouseover", function(event, d) {
                d3.select(this).attr("fill", "#ffcccc");
                // 原有hover标签（保持不变）
                let node_label = `<span style='color:red;font-size:xx-small'>${d.id}</span><br><span style='color:blue;font-size:small;font-weight:bold'>${dict_node2name[d.id]}</span>`;
                d3.select("#node_label")
                    .style("display", "block")
                    .style("left", (event.pageX + 20) + "px")
                    .style("top", (event.pageY - 20) + "px")
                    .html(node_label);
                // 原有功能
                let current_click_target_id = d.id + '_maindiv';
                document.getElementById(current_click_target_id).style.backgroundColor = "#ffcccc";
            })
            .on("mouseout", function(event, d) {
                d3.select(this).attr("fill", "#0099cc");
                // 隐藏原有hover标签
                d3.select("#node_label").style("display", "none");
                // 原有功能
                let current_click_target_id = d.id + '_maindiv';
                document.getElementById(current_click_target_id).style.backgroundColor = "transparent";
            })
            .on("click", function(event, d) {
                document.getElementById(d.id + '_jumpmark').scrollIntoView({ behavior: 'smooth' });
                d3.select("#nodename_out").text("Clicked: " + d.id);
            })
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));
    
        // 添加叉号（保持不变）
        var cross = container.selectAll("text.cross")
            .data(nodes)
            .enter().append("text")
            .attr("class", "cross")
            .attr("x", d => d.x)
            .attr("y", d => d.y)
            .attr("dy", ".35em")
            .attr("text-anchor", "middle")
            .attr("id", d => d.id + "_false")
            .style("font-size", "42px")
            .style("fill", "red")
            .style("display", "none")
            .style("pointer-events", "none")
            .text("×︎");
    
        // 模拟更新（添加标签位置更新）
        simulation.on("tick", function() {
            link
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
            node
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);
            cross
                .attr("x", d => d.x)
                .attr("y", d => d.y);
            
             // 更新持久标签位置
            // 更新持久标签位置
            labelGroups.attr("transform", d => `translate(${d.x + 10},${d.y + 5})`);
            
            // 动态调整背景矩形大小（仅对存在的元素操作）
            labelGroups.each(function(d) {
                const text = d3.select(this).select(".label-text");
                if (!text.empty()) { // 检查元素是否存在
                    const bbox = text.node()?.getBBox(); // 可选链操作符避免报错
                    if (bbox) { // 检查 getBBox 是否成功
                        d3.select(this).select("rect")
                            .attr("width", bbox.width + 5)
                            .attr("height", bbox.height + 5)
                            .attr("x", bbox.x - 5)
                            .attr("y", bbox.y - 5);
                    }
                }
            });
        });
    
        // 拖拽函数（保持不变）
        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }
        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }
    
        // 缩放功能（保持不变）
        var zoom = d3.zoom()
            .scaleExtent([0.1, 10])
            .on("zoom", function(event) {
                container.attr("transform", event.transform);
            });
        svg.call(zoom);
    }
    
    // 全局变量，跟踪标签显示状态    
    var showAllLabels = false;
    function toggleAllLabels() {
        showAllLabels = !showAllLabels; // 切换状态
        
        if (showAllLabels) {
            // 显示所有持久标签
            d3.selectAll(".persistent-label").style("display", "block");
            document.getElementById("toggleLabelsButton").textContent = "隐藏标签";
        } else {
            // 隐藏所有持久标签
            d3.selectAll(".persistent-label").style("display", "none");
            document.getElementById("toggleLabelsButton").textContent = "展示标签";
        }
    }


    function bottom_FDG_button_click(){
        
        let FDG_graph_state_hidden=document.getElementById("FDG_graph_state_hidden");
        let FDG_graph_state_hidden_old=FDG_graph_state_hidden.value;
        console.log("bottom_FDG_button_click开始,FDG_graph_state_hidden_old：",FDG_graph_state_hidden_old);
        if (FDG_graph_state_hidden_old=="0"){
            document.getElementById("FDG_graph_state_hidden").value="1";
            document.getElementById("bottom_FDG_div").style.display ="block";
            document.getElementById("nodename_out").style.display ="block";
            document.getElementById("bottom_FDG_button").style.backgroundColor ="#f5f5f5";
            refresh_FDG();radio_change2();
        }
        else{
            document.getElementById("FDG_graph_state_hidden").value="0";
            document.getElementById("bottom_FDG_div").style.display ="none";
            document.getElementById("nodename_out").style.display ="none";
            document.getElementById("bottom_FDG_button").style.backgroundColor ="transparent";
            
        }
    }
    
    function li_hover2main_div(){
        document.querySelectorAll('.li_hover').forEach(function(li) {
            li.addEventListener('mouseenter', function() {
                // 获取li的id
                let originalId = li.id.slice(0, -8);;
                //生成新id:node_mark
                let main_div_id = originalId+"_maindiv";
                document.getElementById(main_div_id).style.backgroundColor="rgba(255, 204, 204,0.3)";          //#ffcccc      
                // 生成新id，假设新id是在原id前加上"FDG_"
                let target_node_id = "FDG_" + originalId;
                let target_node = document.getElementById(target_node_id);

                target_node.setAttribute('fill', '#ffcccc');
                
                //获取label的位置
                let label=document.getElementById("node_label");
                /*let label_rect=label.getBoundingClientRect();
                let label_X = label_rect.left;   // 元素左侧相对于视口的距离
                let label_Y = label_rect.top;    // 元素顶部相对于视口的距离*/
                
                // 获取滚动的位置
                let scroll_X = window.scrollX || window.pageXOffset;
                let scroll_Y = window.scrollY || window.pageYOffset;   
                
                // 获取节点的位置
                let target_node_rect = target_node.getBoundingClientRect();
                let target_X = target_node_rect.left;   // 元素左侧相对于视口的距离
                let target_Y = target_node_rect.top;    // 元素顶部相对于视口的距离
                /*
                // 计算节点相对于 
                let svgContainer = document.getElementById('FDG_svg');//SVG 容器的位置
                let svgContainerBounds = svgContainer.getBoundingClientRect();
                let Container_X = target_X - svgContainerBounds.left;
                let Container_Y = target_Y - svgContainerBounds.top;*/
                label.style.left=(target_X + scroll_X-610) + 'px';
                label.style.top=(target_Y + scroll_Y-70) + 'px';
                label.style.display = 'block';;
                label.innerHTML= `<span style='color:red;font-size:xx-small'>${originalId}</span><br><span style='color:blue;font-size:small;font-weight:bold'>${dict_node2name[originalId]}</span>`;
                
                /*console.log("scrollX,scrollY:",scroll_X,scroll_Y);
                console.log("label位置",label_X,label_Y);
                console.log("相对目标节点位置",scrollX,scrollY);
                console.log("相对svg容器位置",Container_X,Container_Y);*/
            });
            li.addEventListener('mouseleave', function() {
                // 获取li的id
                let originalId = li.id.slice(0, -8);;
                //生成新id:node_mark
                let main_div_id = originalId+"_maindiv";
                document.getElementById(main_div_id).style.backgroundColor="white";   //#d1e0e0
                //生成新id:li_hover
                let li_hover_id = "FDG_" + originalId;
                let svgElement = document.getElementById(li_hover_id);
 
                svgElement.setAttribute('fill', '#0099cc');
                document.getElementById("node_label").style.display = 'none';;;
            });
        });
    }
    
    /*显示textarea*/
    function show_textarea(this_object,target_id){
        console.log('show_textarea:',target_id);
        this_object.style.display="none";
        document.getElementById(target_id).classList.remove('display_none');  
    }    
</script>

<script>
    //项目启动
    const real_node_replyARR_dict={};
    /*生成一个基本的信息表*/
    function task_start1(item_identifier){
        console.log("任务生成：",item_identifier);
        let task_start_template_sum=document.getElementById('task_start_template_sum').value;
        let task_start_parameter_sum=document.getElementById('task_start_parameter_sum').value;
        let task_start_thread_sum_element=document.getElementById('task_start_thread_sum');let task_start_thread_sum='';
        if(task_start_thread_sum_element){task_start_thread_sum=task_start_thread_sum_element.value;}
        //console.log("task_start_template_sum:",task_start_template_sum);
        console.log("task_start_parameter_sum:",task_start_parameter_sum);
        
        if(item_identifier.startsWith('script_')){
            
        }
        else if(item_identifier.startsWith('stream_')){
            if(good_node_list.length==0){ showAndFadeOut('error', 2000, 3,"运行起点/终点错误，end必须在start之后！");return false;}
        }
        else if(item_identifier.startsWith('structure_')){
            if(good_node_list.length==0){ showAndFadeOut('error', 2000, 3,"至少需要开放一个节点！");
            console.log('good_node_list',good_node_list);
            return false;}
        }
        
        //获得所有的预设变量
        let dict_variablename_value={};
        for (let one_variable_id of variable_id_list){
            let one_variable_id_name = document.getElementById(one_variable_id+'_name').innerText;
            let one_variable_id_value = document.getElementById(one_variable_id+'_value').value;
            dict_variablename_value[one_variable_id_name]=one_variable_id_value;
        }
        //console.log(dict_variablename_value);
        
        
        //console.log("good_node_list:",good_node_list);
        //获得所有子程序的预设模板/参数
        let dict_node_templaterevise={};
        let dict_node_parameterrevise={};  
        //如果是script直接就可以运行，没有node，如果是stream，需要按照good_node_list顺序依次运行，如果是structure，需要按照依赖逐步开展，先开始没有任何依赖的，再逐步开始
        if(item_identifier.startsWith('stream_') || item_identifier.startsWith('structure_')){
            for(let one_good_node of good_node_list){
                let one_good_node_template_revise =  document.getElementById(one_good_node+'_template_revise').value;    
                if(one_good_node_template_revise.trim()!=''){dict_node_templaterevise[one_good_node]=one_good_node_template_revise;}
                let one_good_node_parameter_revise =  document.getElementById(one_good_node+'_parameter_revise').value;     
                if(one_good_node_parameter_revise.trim()!=''){dict_node_parameterrevise[one_good_node]=one_good_node_parameter_revise;}
            }
            //console.log(dict_node_templaterevise) ; 
            //console.log(dict_node_parameterrevise) ;  
        }
    
        
        //获取所有子程序的依赖关系，只有网络结构涉及到了依赖 
        if( item_identifier.startsWith('structure_')){
            for(let key in real_node_replyARR_dict){
                if(real_node_replyARR_dict.hasOwnProperty(key)){delete real_node_replyARR_dict[key];}
            } 
            let warn_mark='';
            for(let one_good_node of good_node_list){
                let max_rely=node_replyARR_dict[one_good_node];  //由于有可能是从中途开始，所以max_rely中有部分运行node被关闭
                for (let one_possible_rely of max_rely){
                    if (one_possible_rely==one_good_node){warn_mark='yes';}     //要防止自己依赖自己。。
                    if (good_node_list.includes(one_possible_rely) ){  
                        if (!(one_good_node in real_node_replyARR_dict)){real_node_replyARR_dict[one_good_node]=[];}
                        real_node_replyARR_dict[one_good_node].push(one_possible_rely);
                    }
                }
                
            }
            if(warn_mark=='yes'){showAndFadeOut('warn', 2000, 3,"存在节点依赖于自身，已忽略依赖！");}
            //console.log(real_node_replyARR_dict) ;      
        }
        
        let new_item_id0='task_'+getCurrentTime2()+"_"+generateRandomString(4);
        let new_item_id1=new_item_id0;
        let project_dir=document.getElementById('project_prepare_dir_hidden').value;
        let task_module_name=document.getElementById('current_task_module_name_hidden').value;
        let project_id = document.getElementById('current_project_itemid_hidden').value;//console.log("current_project_itemid_hidden:",current_project_itemid_hidden);     project id
        fetch('function_task_prepare1_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'new_item_id0':new_item_id0,
                'new_item_id1':new_item_id1,
                'userid':userid,         
                'project_id':project_id, 
                'project_dir':project_dir,
                'task_module_id':item_identifier,
                'task_module_name':task_module_name,
                'task_start_template_sum':task_start_template_sum,
                'task_start_parameter_sum':task_start_parameter_sum,
                'task_start_thread_sum':task_start_thread_sum,
                'dict_variablename_value':dict_variablename_value,
                'good_node_list':good_node_list,
                'dict_node_templaterevise':dict_node_templaterevise,
                'dict_node_parameterrevise':dict_node_parameterrevise,
                'real_node_replyARR_dict':real_node_replyARR_dict
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            //task_manager_content_refresh(new_item_id1);
            document.getElementById('current_taskid_hidden').value = new_item_id1;  //存一个taskid_hidden
            showAndFadeOut('success', 2000, 3,"参数被记录，任务编号："+new_item_id1); 
            task_start1s(new_item_id1);
            //showAndFadeOut('success', 2000, 3,"任务已生成："+new_item_id1); 
            //隐藏任务生成页面
            //document.getElementById('project_prepare_list_div').innerHTML = "";       //正式版要去掉注释
            //document.getElementById('project_prepare_content_div').innerHTML = ""; //正式版要去掉注释

            
            //页面平滑滚动到顶
            //window.scroll({top: 0,behavior: 'smooth'});
            document.getElementById('task_manager_content').scrollIntoView({ behavior: 'smooth' });
            //刷新下文件夹内容, 因为刷新文件夹会清空#task_manager_content，在刷新结束加回调task_manager_content_refresh
            //path_refresh_click('',task_manager_content_refresh(new_item_id1));     //正式版要去掉注释
            //
            //document.getElementById('FDG_all').style.display='none';
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
        
    }
    function task_start1s(task_id){
        
        console.log("task_id,userid:",task_id,userid);
        fetch('function_task_prepare1s_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'task_id':task_id,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
             //会导致#task_manager_content清空，所以下面再刷新下task_manager_content_refresh
            task_manager_content_refresh(task_id);
            //showAndFadeOut('success', 2000, 3,"作业已生成");
            if (typeof raw_result === 'string') {showAndFadeOut('success', 2000, 5,raw_result);}
            
            console.log(raw_result);
        })
        .catch(error => {  
            console.log("error:",error);
            task_manager_content_refresh();
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }    
    
</script>
<script>
    function task_manager_content_refresh(colored_itemid){
        console.log("task_manager_content_refresh,刷新任务列表");
        let project_belong_id=document.getElementById('current_project_itemid_hidden').value;
        
        let page=document.getElementById('current_page2_hidden').value;
        let searchword=document.getElementById('current_searchword2_hidden').value;
        let sortcol=document.getElementById('current_sortcol2_hidden').value;
        let sortdirection=document.getElementById('current_sortcol_direction2_hidden').value;
        
        let task_manager_content=document.getElementById('task_manager_content');
        let num_per_page=document.getElementById('current_num_per_page2_hidden').value;

       
     
        
        fetch('function_task_get_info.php', {    
            method: 'POST',    
            headers: {    
                'Content-Type': 'application/json',  
            },    
            body: JSON.stringify({  
                'action':'refresh_task',
                'userid':userid,
                'project_belong_id': project_belong_id,  
                'page':page,
                'searchword':searchword,
                'sortcol':sortcol,
                'sortdirection':sortdirection,
                'num_per_page':num_per_page
            }),   
        })    
        .then(response => {  
            if (!response.ok) {  
                return response.json().then(errorData => {  
                    // 抛出错误以便在 catch 中捕获  
                    throw new Error(errorData.error);  
                });  
            }  
            return response.json();  
        })  
        .then(data => {  
            let raw_result = data.result;  
            //console.log('fetch_item_info结果：', raw_result);  
            let result_num=data.result_num;
            let page_num=data.page_num;
            document.getElementById("current_page_sum2_hidden").value=page_num; 
            let current_page=document.getElementById("current_page2_hidden").value; 
            //console.log(data);
            //console.log("data.result:",data.result);
            //console.log("data.result_num:",result_num);
            //
            // 假设你有一个select元素  
            let selectHTML = ``;  let current_page_str='';
            for (let i = 1; i <= page_num; i++) {  
                if(current_page==i){current_page_str='selected';}else{current_page_str='';}
                selectHTML += `<option value='${i}' ${current_page_str}>${i}</option>`;  
            }  
            //
            let marked_col_id='';
            if (sortcol!=''){
                if(sortcol=='创建时间'){marked_col_id='table2_th1';}
                else if(sortcol=='唯一识别码'){marked_col_id='table2_th2';}
                else if(sortcol=='使用模块'){marked_col_id='table2_th3';}
                else if(sortcol=='模块名称'){marked_col_id='table2_th4';}
                else if(sortcol=='备注信息'){marked_col_id='table2_th5';}
                else if(sortcol=='更新时间'){marked_col_id='table2_th6';}
                else if(sortcol=='状态'){marked_col_id='table2_th7';}
            }     
            let current_time=getCurrentTime();
            let table1=`              
                                <div style='width:100%;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:flex-start;align-items:flex-start' >
                                    <div style='flex:1;color:#cc0066;font-size:15px;font-weight:bold;margin:auto;cursor:pointer'  class='project_top_right'  onclick='task_manager_content_refresh()'>
                                        <div  >
                                            <span  onclick="task_manager_content_refresh()">任务列表</span>
                                            <span style='font-size:xx-small;color:grey;cursor:pointer;font-weight:normal'">[${project_belong_id}]</span> 
                                            <span  style="color:#0099cc;font-size:xx-small" id='task_refresh'>&nbsp;[刷新]</span>
                                        </div>    
                                    </div>    
                                  
                                    <div style='flex:none;'>
                                        <div id='project_show_option_inner2'>
                                            <div id='project_show_option_inner2_inner'>
                                                <div>
                                                    <input type='text' id='search_input2'></input>
                                                </div>    
                                                <div>  
                                                    <div id="project_show_option_inner2_inner_div" onclick='search_input_click2()'>
                                                        <img style='' src="000_image/svg_magnify.svg">
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>            
                                <table class="info_table" >
                                    <tr class=''>
                                        <td colspan='7' style='vertical-align:bottom'>
                                            <div id='table_top'>
                                                <div id='table_top_1'>
                                                    <div><span  style='cursor:pointer' class='refresh_time' onclick="task_manager_content_refresh()">刷新时间: ${current_time}</span></div> 
                                                    <div class='table_top_2_function'>
                                                        <button class='table_top_2_function_button' onclick="task_create_click('${project_belong_id}')">新建任务</button>
                                                        <button class='table_top_2_function_button' onclick="delete_task('delete_all','${project_belong_id}')">清空任务</button>
                                                    </div>      
                                                </div> 
                                                <div id='table_top_2'>    
                                                    <div class='num_per_page'>                  
                                                        <span onclick="num_per_page_click2('1')">1</span>|<span onclick="num_per_page_click2('5')">5</span>|<span onclick="num_per_page_click2('20')">20</span>|<span onclick="num_per_page_click2('100')">100</span>
                                                    </div>
                                                    <div  id='table_top_2_page' >
                                                        <div>页码:</div>
                                                        <div class='table_top_2_page_arrow' onclick="page_click_addminus2('减一')">
                                                            <img style='width:10px;height:10px' src="000_image/svg_arrow_left.svg">
                                                        </div>
                                                        <div>
                                                            <select class='studynote_page_option' id='' name='' onchange="page_click2(this.value)" ondblclick='enterEditMode(this)'>
                                                                ${selectHTML}
                                                            </select>
                                                        </div>
                                                        <div class='table_top_2_page_arrow' onclick="page_click_addminus2('加一')">
                                                            <img style='width:10px;height:10px' src="000_image/svg_arrow_right.svg">
                                                        </div>
                                                    </div>    
                                                </div>    
                                            </div>
                                        </td>
                                    </tr>                                
                                    <tr>
                                        <th  id='table2_th1'  onclick="th_click2('table2_th1','创建时间')" >创建时间</th>
                                        <th  id='table2_th2'  onclick="th_click2('table2_th2','唯一识别码')" >task ID</th>
                                        <th  id='table2_th3'  onclick="th_click2('table2_th3','使用模块')" >使用模块</th>
                                        <th  id='table2_th4'  onclick="th_click2('table2_th4','模块名称')" >模块名称</th>
                                        <th  id='table2_th5'  onclick="th_click2('table2_th5','备注信息')" >备注信息</th>
                                        <th  id='table2_th6'  onclick="th_click2('table2_th6','更新时间')" >更新时间</th>
                                        <!--th  id='table2_th7'  onclick="th_click2('table2_th7','状态')" >状态</th-->
                                        
                                        <th style='text-align:center'>任务/Log/删除</th>
                                    </tr>
                                    `;
            let table2=``;
            let ii=0;let serial_base=(current_page-1)*100;
            let item_belongproj_dir='';
            raw_result.forEach((item) => {
                ii+=1;//serial=serial_base+ii;
                //console.log(item);
                let item_create_time            = item["创建时间"]; 
                let item_id                     = item["唯一识别码"];  
                let item_module                 = item["使用模块"]|| "";
                let task_module_name            = item["模块名称"]|| "";
                let item_note                   = item["备注信息"]|| "";
                let item_update_time            = item["更新时间"]|| "";
                let item_state                  = item["状态"]|| ""; 
                item_belongproj_dir             = item["所属项目目录"]; 
                let item_belongproj_id          = item["所属项目编号"]; 
                //
                let colored_itemid_str='';let marked_taskid_str=''
                if(colored_itemid==item_id){colored_itemid_str='colored_row';marked_taskid_str="marked_taskid";}
                //
                table2+=`       <tr id='${item_id}' class='${colored_itemid_str}'>
                                    <td onclick="main_input_click2('${item_id}')" style='width:71px;min-width:71px;max-width:71px'>
                                        <input  class='edited_info' style='width:71px;min-width:71px;max-width:71px' onmouseover='this.title=this.value'  value='${item_create_time}' readonly ></td>
                                    <td onclick="main_input_click2('${item_id}')" style='width:147px;min-width:147px;max-width:147px' >
                                        <input  class='edited_info ${marked_taskid_str}'    style='width:147px;min-width:147px;max-width:147px' onmouseover='this.title=this.value'  value='${item_id}' readonly ></td>

                                    <td onclick="main_input_click2('${item_id}')" style='width:150px;min-width:150px;max-width:150px'>
                                        <input  class='edited_info' style='width:150px;min-width:150px;max-width:150px' onmouseover='this.title=this.value'  value='${item_module}' readonly ></td>                                              
                                    <td onclick="main_input_click2('${item_id}')" style='width:150px;min-width:150px;max-width:150px'>
                                        <input  class='edited_info' style='width:150px;min-width:150px;max-width:150px' onmouseover='this.title=this.value'  value='${task_module_name}' readonly ></td>    
                                    <td onclick="main_input_click2('${item_id}')">
                                        <input  class='edited_info' style='min-width:100px;max-width:300px;border-left:solid 1px rgba(51, 102, 153,0.5);;border-right:solid 1px rgba(51, 102, 153,0.5);border-radius:7px;color:#004c4d;' onmouseover='this.title=this.value'  value='${item_note}' onchange="info_change2(this,'${item_id}','备注信息')"></td>
                                    <td onclick="main_input_click2('${item_id}')"  style='width:71px;min-width:71px;max-width:71px'>
                                        <input  class='edited_info' style='width:71px;min-width:71px;max-width:71px' onmouseover='this.title=this.value'  value='${item_update_time}' readonly ></td>                                            
                                    <!--td onclick="main_input_click2('${item_id}')">
                                        <input  class='edited_info' style='width:71px;min-width:71px;max-width:71px' onmouseover='this.title=this.value'  value='${item_state}' readonly ></td-->    
                                        
                                    <td >
                                        <div class='table_set_td_div' >
                                            <div class='table_button_div' onclick="edit_slurm_script('${item_belongproj_dir}','${project_belong_id}','${item_id}')"><img  style='height:15px;width:15px' src='/000_image/svg_button_edit.svg'></div>
                                            <div class='table_button_div' onclick="goto_log_dir('${item_belongproj_dir}','${project_belong_id}','${item_id}')"><img  style='height:15px;width:15px' src='/000_image/svg_button_log.svg'></div>
                                            <div class='table_button_div' onclick="delete_task('delete_one','${item_id}')"><img  style='height:15px;width:15px' src='/000_image/svg_button_garbage2.svg'></div>
                                        </div>
                                        <div  class='edited_info table_dirurl_link2' style=';display:none' id='${item_id}_url' >${item_belongproj_dir}log_${item_belongproj_id}/${item_id}</div>
                                        </td>
                                </tr>`;
                                /*<!--<td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_element}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_template}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_parameter}' ></td>
                                    <td>
                                        <input  class='edited_info' style='max-width:100px' onmouseover='this.title=this.value'  value='${item_project_info}' ></td>-->*/
            });
            let table3=`        <tr>
                                    <td colspan='7' style='font-size:15px;color:grey;font-size:xx-small'>
                                        共<span id='result_num2'></span>个任务(task)。
                                    
                                    
                                        <div class=' task2dir_div' onclick="task2dir('${item_belongproj_dir}','${project_belong_id}')"><img  style='height:15px;width:15px' src='/000_image/svg_button_into_dir.svg'>
                                            <div class='task2dir_div_dropdown'>${item_belongproj_dir}</div>
                                        </div>
                                    </td>
                                </tr>

                            <table>
                            `;
            let table_sum=table1+table2+table3;
            let contentHtml = `${table_sum}`;    
            //改内容
            task_manager_content.innerHTML = contentHtml;   ;

    
        
            //高亮被排序的列
            if(marked_col_id!=''){document.getElementById(marked_col_id).style.backgroundColor = 'rgba(51, 102, 153,0.6)';}
            
            //显示结果数量和page
            document.getElementById('result_num2').innerText=result_num;
  
            //判断是否有log_project/task路径存在
            table_dirurl_link2();
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    
        task_manager_content.innerHTML='';
    }
    function th_click2(th_id,col_name){
        //先确定是排哪列，是升序还是降序
        //console.log('点击了列名，即将排序');
        let current_sortcol = document.getElementById("current_sortcol2_hidden");                     
        let current_sortcol_direction= document.getElementById("current_sortcol_direction2_hidden");  
        let current_sortcol_old=current_sortcol.value;                            let current_sortcol_new=col_name;
        let current_sortcol_direction_old=current_sortcol_direction.value;        let current_sortcol_direction_new='';
        if (current_sortcol_new==current_sortcol_old){
            if(current_sortcol_direction_old=='asc'){current_sortcol_direction_new='desc';          }
            else{                                     current_sortcol_direction_new='asc';          }
        }
        else{
            current_sortcol_direction_new='desc';
        }
        current_sortcol.value              =current_sortcol_new; 
        current_sortcol_direction.value    =current_sortcol_direction_new;
        console.log("需要排序的col和方向：",current_sortcol_new,current_sortcol_direction_new)
        task_manager_content_refresh();
    }
    
    function search_input_click2(){
        let current_searchword = document.getElementById("search_input2").value;
        document.getElementById("current_searchword2_hidden").value=current_searchword;
        console.log("current_searchword2:",current_searchword);
        task_manager_content_refresh();
    }

    function page_click2(page){
        document.getElementById("current_page2_hidden").value=page;
        console.log("page_click2启动:");
        task_manager_content_refresh();
    }    
    function page_click_addminus2(addminus){
        let current_page=parseInt(document.getElementById('current_page2_hidden').value);
        let page_max=parseInt(document.getElementById('current_page_sum2_hidden').value);
        let new_page='';
        if (addminus=="减一"){
            let current_page_minus=current_page-1;
            if(current_page_minus==0){new_page=1;}else{new_page=current_page_minus;}
        }
        if (addminus=="加一"){
            let current_page_add=current_page+1;
            if(current_page_add>page_max){new_page=page_max;}else{new_page=current_page_add;}
        }
        console.log("新页码:",new_page);
        page_click2(new_page);
        file_preview_close_click();
    } 

    function edit_slurm_script(item_belongproj_dir,project_belong_id,item_id){
        console.log(item_belongproj_dir,project_belong_id,item_id);
        let local_path=item_belongproj_dir.slice(5);
        let project_path_show="/home"+local_path;
        document.getElementById("projectdir_mark_div_txt").innerHTML=`<span onclick="dirurl_jumpinto('${local_path}')">${project_path_show}</span>`;
        //showAndFadeOut('success', 2000, 3,'项目目录设置为：'+project_path_show);
        document.getElementById('current_project_dir_state_hidden').value='static';
        //refresh_project_click("初始化aihwgklhasd");
        document.getElementById("projectdir_mark_div_right").style.display="block";
        //
        dirurl_jumpinto(local_path);
        //
        console.log('mark当前行');
        //存一个item_project_dir
        let current_project_itemid_hidden_old=document.getElementById('current_taskid_hidden').value;
        document.getElementById('current_taskid_hidden').value=item_id;
        
        
        //
        console.log('获取其信息，并编辑');
        fetch('function_task_get_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
                'action':'specific_one_task',
                'task_item_id':item_id,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(data);
            if(data.status=='success'){
                // 提取数据
                let {
                    "线程分配": record_thread,
                    "使用模块": record_item,
                    "模板修订": record_template_revise,
                    "参数修订": record_parameter_revise,
                    "变量设置": record_var_list,
                    "作业运行列表": record_node_run_list,
                    "作业依赖": record_node_denpend_list,
                    "作业模板修订": record_node_template_revise_list,
                    "作业参数修订": record_node_parameter_revise_list
                } = raw_result;                   
                let item_array=[record_item];
                //console.log(item_array);
                let container = document.getElementById('project_prepare_list_div');
                let container_content='';
                container_content += `<div id='section2paste_clear' onclick="delete_all_prepare_select()">clear</div><div id='project_prepare_list_div_inner'>`;
                item_array.forEach(one =>{
                    let li_itemid=one;let icon_type='';
                    if (li_itemid.startsWith('script_')) {href_php="function_script"; icon_type='script';  }
                    else if (li_itemid.startsWith('stream_')) {href_php="function_stream";icon_type='stream';  }
                    else if (li_itemid.startsWith('structure_')) {href_php="function_structure";icon_type='structure';  }
                    container_content += `<div class='project_prepare_list_div_inner_one' id='${li_itemid}' onclick="project_prepare_list_one_click('${li_itemid}')" ><div><img style='position:relative;top:0px;height:20px;width:20px' src='/000_image/svg_function_${icon_type}.svg' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')"></div><span id='project_prepare_list_one_click_button' >${li_itemid}</span></div>`;  
                    //<span class='li_itemid collection_marked' onclick="openNewPage('${href_php}.php?searchword=${li_itemid}')">${li_itemid}</span>
                });
                container_content+="</div>";
                container.innerHTML =container_content;
                //
             
                
                //点击第一个元素
                document.getElementById('project_prepare_item_hidden').value='';
                let first_item=item_array[0];
                project_prepare_list_one_click(first_item,function(){
                    if (record_item.startsWith("script")|| record_item.startsWith("stream")){
                        document.getElementById('task_start_thread_sum').value=record_thread;
                        console.log('点击了script/stream，清除D3图片');
                        bottom_FDG_button_click();
                    }
                    document.getElementById('task_start_template_sum').value=record_template_revise;
                    document.getElementById('task_start_parameter_sum').value=record_parameter_revise;
                    
                    //修改输入的变量们
                    //console.log(record_var_list);
                    if (record_var_list) {
                        record_var_list=JSON.parse(record_var_list);
                        Object.entries(record_var_list).forEach(([key, value], index) => {
                            const seq = index + 1;
                            const elements = document.querySelectorAll(`input[id^="variable_${seq}_"]`);
                            //console.log(elements, key, value, index);
                            elements.forEach(element => {
                                const originalValue = element.value; // 
                                const newValue = originalValue.replace(new RegExp(key, 'g'), value);
                                element.value = newValue; // 
                            });
                        });
                    }
                    
                    //修改作业运行列表
                    console.log(record_node_run_list);
                    if (record_item.startsWith("stream") && record_node_run_list) {
                        record_node_run_list=JSON.parse(record_node_run_list);
                        node_start=record_node_run_list[0];
                        node_end= record_node_run_list.slice(-1)[0];
                        //console.log(1111111,node_start);
                        //console.log(1111111,node_end);
                        setTimeout(() => {
                            const startLabel = document.getElementById(node_start + "_startRadio_label");
                            const endLabel = document.getElementById(node_end + "_endRadio_label");
                        
                            startLabel.click();
                            endLabel.click();
                        }, 0); // 1000 毫秒 = 1 秒
                    }
                    else if (record_item.startsWith("structure") && record_node_run_list){
                        let all_good_node_list=good_node_list;
                        record_node_run_list=JSON.parse(record_node_run_list);
                        //
                        const recordSet = new Set(record_node_run_list);
                        const all_bad_node_list = all_good_node_list.filter(node => !recordSet.has(node));

                        all_bad_node_list.forEach(one_node => {
                            const closeLabel = document.getElementById(one_node + "_close_label");
                            closeLabel.click();
                        });
                    }
                     
                    //修改子修订列表
                    if (record_node_template_revise_list) {
                        record_node_template_revise_list=JSON.parse(record_node_template_revise_list);
                        Object.entries(record_node_template_revise_list).forEach(([key, value], index) => {
                            document.getElementById(`${key}_template_revise`).value = value;;
                        });
                    }
                   
                    if (record_node_parameter_revise_list) {
                        record_node_parameter_revise_list=JSON.parse(record_node_parameter_revise_list);
                        Object.entries(record_node_parameter_revise_list).forEach(([key, value], index) => {
                            document.getElementById(`${key}_parameter_revise`).value = value;;
                        });
                    }                    
                    /////////////////////
                    variable_change();
                });
                //
                if(data.status=='success'){
                    showAndFadeOut('success', 2000, 3,'载入历史任务');
                }
                //
                
                task_manager_content_refresh(item_id);

                

            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    
    function goto_log_dir(item_belongproj_dir,project_belong_id,task_id){
        console.log(item_belongproj_dir,project_belong_id,task_id);
        
        let new_dir=item_belongproj_dir.slice(5)+'log_'+project_belong_id+'/'+task_id+'/';
        console.log(new_dir);
        //
        let local_path=item_belongproj_dir.slice(5);
        let project_path_show="/home"+local_path;
        document.getElementById("projectdir_mark_div_txt").innerHTML=`<span onclick="dirurl_jumpinto('${local_path}')">${project_path_show}</span>`;
        //showAndFadeOut('success', 2000, 3,'项目目录设置为：'+project_path_show);
        document.getElementById('current_project_dir_state_hidden').value='static';
        //refresh_project_click("初始化aihwgklhasd");
        document.getElementById("projectdir_mark_div_right").style.display="block";
        //
        dirurl_jumpinto(new_dir);
    }
    
    function delete_task(delete_type,item_id){
        console.log('delete_task开始');
    
        // 弹出确认对话框
        var userConfirmed = confirm("你确定要删除吗？");
        if (!userConfirmed) {return;}// 如果用户没有确认删除，直接返回，不执行删除操作
        
        fetch('function_task_delete_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
                'delete_type':delete_type,
                'item_id':item_id,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                task_manager_content_refresh();
                showAndFadeOut('success', 2000, 3,'删除成功');
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    
    function info_change2(this_object,item_id,col_name){
        let input_value=this_object.value;
        console.log("info_change:",item_id,col_name,input_value);
        fetch('function_task_edit_info.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'item_id':item_id,
                'col_name':col_name,
                'input_value':input_value,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                //this_object.classList.remove('green_background_out');  
                this_object.classList.add('green_background');  
                setTimeout(function() {  
                    this_object.classList.remove('green_background');
                    //this_object.classList.add('green_background_out');  
                }, 3000);  
            }
        })
        .catch(error => {  
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            showAndFadeOut('error', 2000, 3,error);
        });
    }
    
    /*project和task之间用虚线链接，有难度下次再搞*/
    function project2task_Line_refresh() {
    }
    
    /**/
    function task2dir(dir,projectid){
        delete_all_prepare_select();
        let new_dir=dir.slice(5); //从第5个字符开始截取，其实就是去掉/home
        console.log('task2dir:',new_dir,projectid);
        
        dirurl_jumpinto(new_dir,'',function(){
            refresh_project_click('',function(){
                main_input_click(projectid,dir);  
              
            });
        });
    }
    
    function num_per_page_click2(num){
        document.getElementById('current_num_per_page2_hidden').value=num;
        task_manager_content_refresh();
        showAndFadeOut('success', 2000, 3,'每页显示task数量：'+num);
    }
   
    function main_input_click2(){}
</script> 


<script>
    /*生成根据预制的信息表生成一个slurm脚本，改用php去处理*/
    
    
    
    function task_start2(){
        let task_id=document.getElementById('current_taskid_hidden').value;
        //showAndFadeOut('success', 2000, 3,'生成脚本的任务：'+task_id);
        fetch('function_task_prepare2_script.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'task_id':task_id,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            console.log(raw_result);
            if(data.status=='success'){
                showAndFadeOut('success', 2000, 3,'生成了slurm脚本，请检查确认，下一步为提交作业');
            }
            //showAndFadeOut('success', 2000, 5,raw_result);
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
    
    
    
    
</script>
<script>
    /*生成根据预制的信息表生成一个slurm脚本，改用php去处理*/
    function task_start3(){
        
        //先更新
        console.log('get_job_state');
        fetch('function_project_updateJobtmp.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            task_start3b();
            //showAndFadeOut('success', 2000, 5,raw_result);
            //console.log('function_progress_getinfo存入数据库的内容：',raw_result);
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }   
    function task_start3b(){
        let task_id=document.getElementById('current_taskid_hidden').value;
        fetch('function_task_prepare3_sbatch.php', {  
            method: 'POST',  
            headers: {  
                'Content-Type': 'application/json',
            },  
            body: JSON.stringify({
                'task_id':task_id,
                'userid':userid,
            }), 
        })  
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    // 抛出错误以便在 catch 中捕获
                    throw new Error(errorData.error);
                });
            }
            return response.json();
        })
        .then(data => {
            let raw_result=data.result;
            showAndFadeOut('success', 2000, 5,raw_result);
            console.log(data);
        })
        .catch(error => {  
            //console.log("error111111111111111111111111111:",error);
            showAndFadeOut('error', 2000, 5,error);
            console.error('捕获到的错误:', error); // 查看错误的完整对象
            
        });
    }
    
    
    
    
</script>
<?php
   
    
    
    
    
    
?>
    
    
    
    
    
    
    
    
    














