<?php  

    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    //链接数据库
    include 'database_connect.php';
    
    
    $userid = $input['userid'];
    $sql = "SELECT * FROM 执行3_作业列表 WHERE 拥有者=? and (系统备注 IS NULL OR 系统备注 = '' OR 系统备注 = '隐藏' OR 系统备注 <> '删除')";  
    $params =[ ['type' => 's', 'value' => $userid]]; // 's' 表示字符串类型
    $rows = database_query($conn, $sql, $params); 
    

    
    // 成功响应
    echo json_encode([
        'success' => true,
        'result' => $rows
    ]);
   



?>


























