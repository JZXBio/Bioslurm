<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="renderer" content="webkit" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=0,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0"/>  <!--似乎和media获得屏幕宽度有关-->
    <script src="https://kit.fontawesome.com/2bb3091a39.js" crossorigin="anonymous"></script>  
    <style>
        a{cursor:pointer;color:#003366;text-decoration:none}
        a:hover{color:red}
        
        td{padding:0 20px}



      #drop-area {
            border: 2px dashed #ccc;
            width: 100%;
            height: 100px;
            line-height: 100px;
            text-align: center;
            font-size: 20px;
            color: #ccc;
        }
        #file-list {
            margin-top: 20px;
        }
    </style>
</head>    
<body>
    <div id="drop-area">Drag and drop files here</div>
    <div id="file-list"></div>
<?php
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 获取最高class后面的数字// 假设 $_GET 中包含类似 class1, class2, ..., classN 的键值对
$highest_class_Number = 0;
foreach ($_GET as $key => $value) {
    if (preg_match('/class(\d+)/', $key, $matches)) {
        $number = (int)$matches[1];
        $highest_class_Number = max($highest_class_Number, $number);
    }
}
//echo '最高数字是：' . $highest_class_Number . '<br>';


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 检查前面的 class1 到 最高数字 是否都存在
$dict_class_value = array(); 
$dict_class_value["class0"]="data_transfer";
for ($i = 1; $i <= $highest_class_Number; $i++) {
    $key = 'class' . $i;
    if (isset($_GET[$key])) {
        //echo $key . ' 存在，对应的值是： ' . $_GET[$key] . "<br>";
        $dict_class_value[$key]=$_GET[$key];
    } else {
        // 如果当前的 classi 不存在，你可以进行适当的处理
        // 例如，中断循环或执行其他逻辑
        //echo $key . ' 不存在<br>';
        $highest_class_Number =$i-1;
        echo "Error, class$highest_class_Number was specified, but $key not exist, the secondary target is class$highest_class_Number<br><br>";
        
        break;
    }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 检查前面的 class1 到 最高数字 实际的文件夹路径是否存在
$i=0;
$real_hightest_class_num=0;
$class0="data_transfer";
//var_dump($highest_class_Number);
while ($i<=$highest_class_Number){
    $current_class="class".$i;
    $current_value=$dict_class_value[$current_class];
    //echo "<br>进度：".$current_class." current_value:".$current_value."<br>";
    //生成文件夹路径
    if ($i==0){         $folder_path                  =$class0;}
    else{               $folder_path                  =$folder_path."/".$current_value."/";}
    ////判断文件夹路径是否存在
    if (file_exists($folder_path) && is_dir($folder_path) && $current_value) {
        //echo "文件夹路径存在。".$folder_path."<br>";
        $real_hightest_num=$i;
    } 
    else {
        //echo "文件夹路径不存在。";
        //echo "11111111111".$folder_path."<br>";
        $folder_path = dirname($folder_path);   #路径返回上一级 /path/to/your/folder/，我想变成/path/to/your/
        //echo "2222222222".$folder_path."<br>";
        $real_hightest_num=$i-1;
        break;
    }    
    $i++;
}
//echo "实际最大的层级到：class".$real_hightest_num." ";

//开始输出一个页面头部
echo "<div style='font-weight:bold;font-size:20px;color:#336699'>Directory:</div>";

$i=0;
echo "      <div>";
$folder_path="";
$html_get_arr=[];
while ($i<=$real_hightest_num){
    if ($i==0){     
        echo "/ <a href='data_storage.php'>home</a>" ;
        $current_href       ="data_storage.php?";
    }
    else{      
        $one_class          ="class".$i;
        $one_class_value    =$dict_class_value[$one_class];
        $html_get_one       =$one_class."=".$one_class_value;
        array_push($html_get_arr,$html_get_one);
        $current_href       ="data_storage.php?".implode("&",$html_get_arr);
        echo " / <a href='$current_href'>$one_class_value</a>"   ; }    
    //计算一个文件和文件夹数量
    if($i==0){      $folder_path="data_transfer";}
    else{           $folder_path=$folder_path."/".$one_class_value;}
    $files_and_folders      =scandir($folder_path);

    $files_num  = count($files_and_folders)-2;   //去掉.和..
    echo "<span style='color:blue;font-size:10px'> $files_num</span>";
    
    //
    $i++;
}
echo "      </div>";
echo "<br>";
   
//文件夹列表和文件列表,, 分成两个列表
$items = $files_and_folders;
// 初始化文件夹和文件列表
$target_folders = array();
$target_files = array();
// 分别存储文件夹和文件
foreach ($items as $item) {
    // 排除当前目录和父目录
    if ($item != '.' && $item != '..') {
        $item_path = $folder_path . '/' . $item;
        if (is_dir($item_path)) {
            $target_folders[] = $item;
        } elseif (is_file($item_path)) {
            $target_files[] = $item;
        }
    }
}
$target_folders_num     =count($target_folders);
$target_files_num       =count($target_files);
//var_dump($target_folders);var_dump($target_files);

//输出主要内容列表
// 辅助函数：将字节大小格式化为更友好的单位
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
echo "      <div  style='height:1px;width:50%;margin:3px 0px 3px 0px;background: linear-gradient(to right,grey,white)'></div>";

echo "      <div style='margin-left:20px'>
                <table>";

if ($target_folders_num>0){
    $k=0;
    while ($k<$target_folders_num) {
        $one_folder =$target_folders[$k];
        $new_href   =$current_href."&class".($highest_class_Number+1)."=".$one_folder;
        echo "      <tr>
                        <td><i class='fa-regular fa-folder'></i> <a href='$new_href'>$one_folder</a></td>
                    </tr>";        
        $k++;
    }
}
if ($target_files_num>0){
    $j=0;
    while ($j<$target_files_num) {
        $one_file       =$target_files[$j];    
        $one_file_path  =$folder_path."/".$one_file;
        
        if ($target_files_num<100000){
            // 获取文件大小（以字节为单位）
            $filesize = filesize($one_file_path);
            // 将文件大小格式化为更友好的单位（KB、MB、GB等）
            $formatted_size = formatBytes($filesize);  
        }
        else{
            $formatted_size="";
        }
        echo "      <tr>
                        <td><i class='fa-solid fa-file'></i> <a style='color:black' href='$one_file_path' download>$one_file</a></td>
                        <td>$formatted_size</td>
                    </tr>";   
        $j++;
    }    
}
echo "          </table>
            </div>";


    
?>














    <script>
        const dropArea = document.getElementById('drop-area');
        const fileList = document.getElementById('file-list');

        dropArea.addEventListener('dragover', (event) => {
            event.preventDefault();
            dropArea.style.borderColor = 'green';
        });

        dropArea.addEventListener('dragleave', () => {
            dropArea.style.borderColor = '#ccc';
        });

        dropArea.addEventListener('drop', (event) => {
            event.preventDefault();
            dropArea.style.borderColor = '#ccc';

            const files = event.dataTransfer.files;
            const formData = new FormData();

            for (const file of files) {
                formData.append('file[]', file);
            }

            fetch('data_transfer_upload.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateFileList();
                }
            });
        });

        function updateFileList() {
            fetch('transfer.php')
                .then(response => response.json())
                .then(files => {
                    fileList.innerHTML = '';
                    files.forEach(file => {
                        const fileLink = document.createElement('a');
                        fileLink.href = `data_transfer/${file}`;
                        fileLink.textContent = file;
                        fileLink.style.display = 'block';
                        fileList.appendChild(fileLink);
                    });
                });
        }

        updateFileList();
        setInterval(updateFileList, 5000);  // Update the file list every 5 seconds
    </script>
</body>
</html>





