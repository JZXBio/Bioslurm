https://cdn.jsdelivr.net/npm/monaco-editor@0.47.0/，手动下载min下的所有文件


注意层级，网站根目录/plug/monaco_editor/IDY/， 否则自行设置响应文件的目录



sdaf

s 