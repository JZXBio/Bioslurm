<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    

    
    
   
    if (isset($input["task_id"]) && isset($input["userid"]))
    {
        //
        $user_id=$input['userid'];
        $base_path = '/www/wwwroot/bioslurm/user/'.$user_id; 

        
        //链接数据库
        include 'database_connect.php';
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        $task_id                                    =$input["task_id"];  
        
        $current_time           =date("YmdHis");        //rand(0,9).rand(0,9).rand(0,9)
       
        //查找数据
        $sql = "select 所属项目编号,所属项目目录, 线程分配, 使用模块, 模板修订, 参数修订, 变量设置, 作业运行列表, 作业依赖, 作业模板修订, 作业参数修订  from 执行2_任务列表 where 唯一识别码 = ?";  
        $updateStmt = mysqli_prepare($conn, $sql);
        if (!$updateStmt) {  http_response_code(500);  echo json_encode(['error' => '无法完成参数准备']);die();}
        mysqli_stmt_bind_param($updateStmt, 's',$task_id); 
        mysqli_stmt_execute($updateStmt);  
        $result = mysqli_stmt_get_result($updateStmt);  
        if (!$result || mysqli_num_rows($result) === 0) {  http_response_code(500);  echo json_encode(['error' => '任务编号错误，找不到任务']);die();} 
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  $results[] = $row;  }  
        mysqli_stmt_close($updateStmt); 
        
        //唯一结果
        $result_one=$results[0];
        $project_id                             =$result_one['所属项目编号'];
        $project_dir                            =$result_one['所属项目目录'];   $project_dir=substr($project_dir, 5);   //去掉开头的/home字样
        /*$task_sum_threads                       =$result_one['线程分配'];
        $task_module_id                         =$result_one['使用模块'];
        $task_start_template_revise             =$result_one['模板修订'];
        $task_start_parameter_revise            =$result_one['参数修订'];
        $dict_variablename_value                =json_decode($result_one['变量设置']);
        $good_node_list                         =json_decode($result_one['作业运行列表']);//这个$good_node_list顺序可能不太对
        $real_node_relyARR_dict                 =json_decode($result_one['作业依赖']);  
        $dict_node_templaterevise               =json_decode($result_one['作业模板修订']);
        $dict_node_parameterrevise              =json_decode($result_one['作业参数修订']);
        //echo json_encode(['result' => $dict_variablename_value]);die();
        //echo json_encode(['result' => $dict_variablename_value]);die();*/
        /*排序节点，有依赖的节点往后排*/
        /*
        if(strpos($task_module_id, 'structure_') === 0){
            $good_node_list2=topologicalSort($good_node_list,$real_node_relyARR_dict);     //这个$good_node_list2顺序是矫正过的，所有带依赖的都往后排
            if ($good_node_list2 !== false) {} 
            else { http_response_code(500);  echo json_encode(['error' => 'DAG图中存在循环依赖，无法进行拓扑排序(Kahn)']);die();}
        }
       */
        /*project文件夹*/
        $project_absolute_dir=$base_path.$project_dir.'/';
        
        /*project_log文件夹*/
        $project_log_dir=$base_path.$project_dir.'/log_'.$project_id.'/';
       

        /*生成task_log文件夹*/
        $task_log_absolute_dir=$project_log_dir.$task_id.'/';  //似乎在slurm脚本中不需要绝对路径
        $task_log_absolute_dir = preg_replace('/\/+/', '/', $task_log_absolute_dir);    // 替换 // 为 /
        $task_log_absolute_dir = preg_replace('/\/\.\//', '/', $task_log_absolute_dir);// 替换 /./ 为 /
        //$task_log_local_dir='./'.$task_id.'/';
        
        
        if (!file_exists($task_log_absolute_dir)) {  
            if (mkdir($task_log_absolute_dir, 0777, true)) {
                //$result_log_text="文件夹创建成功"; 
            } 
            else {
                http_response_code(400);echo json_encode(['error' => 'task_log_dir文件夹创建失败']);die();  
            }  
        }  
        
        
        
        // 返回 JSON 响应
        echo json_encode(['status' => 'success','result' => $result]);die();
        
        
        die();
    }


?>























