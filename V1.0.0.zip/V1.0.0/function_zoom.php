<?php    
    session_start(); // 开始会话
    
    if (isset($_SESSION["user_uuid"])  &&  isset($_SESSION["user_email"]) &&  isset($_SESSION["user_name"]) &&  isset($_SESSION["user_name_id"]) ) {
        $navi_user_state= "
            <span style='font-size:xx-small;margin-left:50px'>欢迎, </span>{$_SESSION['user_name']}<span style='font-size:xx-small'> [{$_SESSION['user_email']}] </span> 
            <div style='display:inline-block'>
                <form  action='index.php' method='post'>
                    <input type='hidden'  name='action' ID='action' value='logout'></input><button id='logout'>[退出]</button>
                </form>    
            </div> ";
        
    }
    else{
        header("Location: index.php");  
        exit; // 确保重定向后停止脚本执行  
    }    
   
   
    $user_name_id=$_SESSION['user_name_id'];
    $base_path = "/www/wwwroot/bioslurm/user/{$user_name_id}";  
    if (is_dir($base_path)==false)  {  echo "用户未初始化，用户文件夹不存在。";  die();} 
    
?>


<!DOCTYPE  html>
<html  lang="en">
<head>
    <meta  charset="UTF-8">
    <meta  name="viewport"  content="width=device-width,  initial-scale=1.0">
    <title>BioSlurm生信服务器</title>
    <meta name="keywords" content="BioSlurm生信服务器">
    <meta name="description" content="BioSlurm生信服务器" >
    <link rel="icon" href="000_image/favicon.png" type="image/png">
     
    <style>

        * {box-sizing: border-box;margin:0;padding:0;}
        body {font-family: sans-serif;min-width:300px;background-color: rgba(0,0,0,0.06);}/*background-color: rgba(0,0,0,0.03);*/
        #top_navigator {position:fixed;top:0;width: 100%;background-color:#005580;padding:4px;margin:0 0 auto 0;height:30px;color:white;z-index:111111}
        #top_navigator a{color:white; text-decoration:none; margin:0 10px;font-size:17px;}
        #top_navigator a:hover{color:#ffff99}
        #top_navigator_title_name{font-weight:500;text-shadow: 0 0 1px black, 1px 1px 5px black;}
        #top_navigator_current_time{font-size:xx-small}
        #logout{background: none;border:none;padding: 0;font: inherit;cursor: pointer; color: rgb(200,200,200);outline: none;display:inline-block; font-size:xx-small; }
        #logout:hover{color:red}
        
        #main_content{margin:50px 25px 20px 75px;border:solid 0px red;transition:1s;display:flex;display:-webkit-flex;flex-wrap: nowrap;justify-content:left;align-items:top}
        #main_content>div{background-color:white;padding:10px;border-radius:10px;box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.01);border:solid 0px blue;margin:5px;transition:1s}
        #easylink_div{position:fixed;left:0;top:0;height:100%;display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content: flex-start;align-items:center;flex-direction: column;background-color:rgba(0, 0, 0,0.1);padding:70PX 0 20px 0;z-index:1}
        .function_link_div{display:block;width:40px;height:40px;margin:5px 10px;border:solid 0px grey;border-radius:5px;background-color:#e6e6e6;cursor:pointer;
            display:flex;display:-webkit-flex;flex-wrap: wrap;justify-content:center;align-items:center;position: relative; 
        }
        .function_link_div:hover{background-color:white;}
        .function_link_div_dropdown{position: absolute;top:100%;left:1px;font-size:10px;opacity:0;width:100px;color:grey;z-index:100;transition: opacity 1s cubic-bezier(0.68, -0.55, 0.27, 1.55);}
        .function_link_div:hover .function_link_div_dropdown{opacity:1}
        .select_div{background-color:#fafafa;position: relative; }
        .select_div:after{
            content: '';  
            position: absolute;  
            right: -7px;  
            top: 50%;  
            transform: translateY(-50%);  
            border-top: 8px solid transparent;  
            border-bottom: 8px solid transparent;  
            border-left: 8px solid #fafafa; }
        .select_div:hover:after{border-left: 8px solid white}
  
        .message-box {padding: 5px 10px;border: solid 1px grey;border-radius: 10px;position: fixed;left: 50%;transform: translateX(-50%);font-size: small;display: block;opacity: 1; z-index: 9999;background-color: white;transition: opacity ease-in-out; margin-top: 40px; }
    </style>
</head>
<body>
    <div id='all_sum'>
        <div id='top_navigator'>
            <a id='top_navigator_title_name' href='index.php'>Bioslurm</a>
            <span id="top_navigator_current_time"></span>
            <span id="user_state"><?php echo $navi_user_state;?></span>
        </div> 

        <div  id='easylink_div'>
            <a href='index.php' >
                <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_home.svg">
                </div>
            </a>
            
            <a href='function_file.php' >
                <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_file.svg">
                    <div class='function_link_div_dropdown'>文件目录</div>
                </div>
            </a>
            
            <a href='function_script.php' >
                <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_script.svg">
                    <div class='function_link_div_dropdown'>命令脚本</div>
                </div>
            </a>
    
            <a href='function_stream.php' >
                <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_stream.svg">
                    <div class='function_link_div_dropdown'>线性流程</div>
                </div>
            </a>
            
            <a href='function_structure.php' >
                <div class='function_link_div '><img style='width:30px;height:30px' src="000_image/svg_function_structure.svg">
                    <div class='function_link_div_dropdown'>网络结构</div>
                </div>
            </a>
    
            <a href='function_project.php' >
                <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_project.svg">
                    <div class='function_link_div_dropdown'>项目执行</div>
                </div>
            </a>   
            <a href='function_progress.php' >
                <div class='function_link_div'><img style='width:30px;height:30px' src="000_image/svg_function_progress.svg">
                    <div class='function_link_div_dropdown'>作业进度</div>
                </div>
            </a>                
  
            <a href='function_zoom.php' style='margin-top: auto;margin-bottom:50px'>
                <div class='function_link_div select_div'><img style='width:30px;height:30px' src="000_image/svg_function_gear.svg">
                </div>
            </a>              
        </div>    
        
        <div id='main_content'>
            
            <div>
                <table>
                    <tr>
                        <td colspan='2' style='width:140px;font-weight:bold'>文本编辑器</td>
                    <tr>    
                    <tr>
                        <td style='width:85px;'>主题</td>
                        <td>
                            <input type='radio' value="black" name="select_theme" id="theme_vs-dark" onclick="select_click('设置_文本编辑器','vs-dark')"><span style='color:###;margin-right:10px'>黑色背景</span>
                            <input type='radio' value="black" name="select_theme" id="theme_hc-black" onclick="select_click('设置_文本编辑器','hc-black')"><span style='color:###;;margin-right:10px'>黑色高对比背景</span>                            
                            <input type='radio' value="white" name="select_theme" id="theme_vs" onclick="select_click('设置_文本编辑器','vs')"><span style='color:###;;margin-right:10px'>白色背景</span>
                        </td>
                    </tr>
                    <tr>       
                        <td style=''>自动换行</td>
                        <td>
                            <input type='radio' value="black" name="select_wrap" id="select_wrap-yes" onclick="select_click('设置_文本编辑器_自动换行','on')"><span style='color:###;margin-right:10px'>自动换行</span>
                            <input type='radio' value="black" name="select_wrap" id="select_wrap-no" onclick="select_click('设置_文本编辑器_自动换行','off')"><span style='color:###;;margin-right:10px'>不自动换行</span>                            
                        </td>                        
                    </tr>    
                </table>    
                
            </div>
            
            
        </div>        
    </div>    
    
    
    
    
    <script>
        const userid='<?php echo $user_name_id;?>';
        function getinfo(){
            console.log('getinfo',userid);
            fetch('function_zoom_getinfo.php', {  
                method: 'POST',  
                headers: {  
                    'Content-Type': 'application/json',
                },  
                body: JSON.stringify({
                    'userid':userid
                }), 
            })  
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        // 抛出错误以便在 catch 中捕获
                        throw new Error(errorData.error);
                    });
                }
                return response.json();
            })
            .then(data => {
                let raw_result=data.result;
                console.log(raw_result);
                if(data.status=='success'){
                    //
                    let select_theme_old=raw_result['select_theme']; console.log(select_theme_old);
                    if(select_theme_old=='vs-dark'){document.getElementById("theme_vs-dark").checked = true;}
                    else if(select_theme_old=='hc-black'){document.getElementById("theme_hc-black").checked = true;}
                    else if(select_theme_old=='vs'){document.getElementById("theme_vs").checked = true;}
                    //
                    let select_wrap_old=raw_result['select_wrap']; console.log(select_wrap_old);
                    if(select_wrap_old=='on'){document.getElementById("select_wrap-yes").checked = true;}
                    else if(select_wrap_old=='off'){document.getElementById("select_wrap-no").checked = true;}
                    //showAndFadeOut('success', 2000, 3,'生成了slurm脚本，请检查确认，下一步为提交作业');
                }
                //showAndFadeOut('success', 2000, 5,raw_result);
            })
            .catch(error => {  
                //console.log("error111111111111111111111111111:",error);
                showAndFadeOut('error', 2000, 5,error);
                console.error('捕获到的错误:', error); // 查看错误的完整对象
                
            });
        }
        getinfo();
        
        
        function select_click(col_name,input_value){
            console.log('select_click',userid);
            fetch('function_zoom_editinfo.php', {  
                method: 'POST',  
                headers: {  
                    'Content-Type': 'application/json',
                },  
                body: JSON.stringify({
                    'userid':userid,
                    'col_name':col_name,
                    'input_value':input_value
                }), 
            })  
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        // 抛出错误以便在 catch 中捕获
                        throw new Error(errorData.error);
                    });
                }
                return response.json();
            })
            .then(data => {
                let raw_result=data.result;
                console.log(raw_result);
                if(data.status=='success'){
                    showAndFadeOut('success', 2000, 3,'设置成功');
                }
                //showAndFadeOut('success', 2000, 5,raw_result);
            })
            .catch(error => {  
                //console.log("error111111111111111111111111111:",error);
                showAndFadeOut('error', 2000, 5,error);
                console.error('捕获到的错误:', error); // 查看错误的完整对象
                
            });
        }
        
        
        
        
        
        
        
        
        function showAndFadeOut(message_type, delayBeforeFade, fadeDuration, message_text) {
            // 创建新的消息元素
            var div = document.createElement("div");
            div.className = "message-box"; // 应用样式类
        
            let message_text_new = '';
            
            // 根据消息类型设置背景颜色和内容
            if (message_type == "error") {
                div.style.backgroundColor = "rgb(255, 255, 153)";
                message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_error.svg'> " + message_text;
            } else if (message_type == "success") {
                div.style.backgroundColor = "#e5ffe5";
                message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_success.svg'> " + message_text;
            } else if (message_type == "warn") {
                div.style.backgroundColor = "#ffff99";
                message_text_new = "<img style='position:relative;top:3px' src='/000_image/svg_message_warn.svg'> " + message_text;            
            } else {
                div.style.backgroundColor = "gray";
                message_text_new = message_text;
            }
        
            div.innerHTML = message_text_new;
            div.style.transition = `opacity ${fadeDuration}s ease-in-out`; // 动态设置渐隐时长
        
            // 将新的消息元素添加到 body
            document.body.appendChild(div);
        
            // 动态调整所有消息的 vertical 位置，防止重叠
            adjustMessagesPosition();
        
            // 延时后开始渐隐
            setTimeout(function() {
                div.style.opacity = 0; // 开始渐隐
                
                // 渐隐完成后移除元素
                setTimeout(function() {
                    document.body.removeChild(div);
                    adjustMessagesPosition(); // 调整剩余消息的位置
                }, fadeDuration * 1000); // 乘以1000将秒转化为毫秒
            }, delayBeforeFade);
        }
        // 动态调整所有消息的位置，防止重叠
        function adjustMessagesPosition() {
            var messages = document.querySelectorAll('.message-box'); // 选择所有消息元素
            let currentTop = 0; // 从顶部开始，预留一些空间
        
            messages.forEach(message => {
                message.style.top = `${currentTop}px`;
                currentTop += message.offsetHeight + 2; // 累加消息高度和间距
            });
        }
    </script>
</body>      
</html>

<?php
   
    
    
    
    
    
?>
    
    
    
    
    
    
    
    
    














