<?php
// CPU 和内存信息（返回 JSON 格式）
header('Content-Type: application/json');

// CPU 运行时间和负载
$uptime_output = shell_exec("uptime");
preg_match("/(\d{2}:\d{2}:\d{2}) up\s+(.*?),\s+.*?load average: ([0-9\.]+), ([0-9\.]+), ([0-9\.]+)/", $uptime_output, $matches);

// CPU 核心数
$cpu_cores = intval(shell_exec('nproc'));

// 内存信息
$free_output = shell_exec('free -m');
preg_match("/Mem:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/", $free_output, $mem_matches);

// 返回 JSON 数据
echo json_encode([
    'current_time' => $matches[1],
    'uptime' => $matches[2],
    'load_1min' => $matches[3],
    'used_memory' => intval($mem_matches[2] / 1024),
    'total_memory' => intval($mem_matches[1] / 1024),
    'cpu_cores' => $cpu_cores
]);
?>