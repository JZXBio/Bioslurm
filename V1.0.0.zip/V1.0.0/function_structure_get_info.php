<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input["dataregin"]) ){

        //链接数据库
        include 'database_connect.php'; 
        
        $dataregin      =$input["dataregin"];
        
        //echo json_encode(['result' => '执行中-内部-Gene']);die();
        //排序，页码，检索可能同时存在
        if ($dataregin=='content_simple' && 
                isset($input["action"])  && 
                isset($input["page"]) && 
                isset($input["searchword"]) && 
                isset($input["sortcol"]) && 
                isset($input["sortdirection"]) && 
                isset($input["userid"])  ){ 
            $action         =$input["action"];
            if($input["page"]!=""){$page=intval($input["page"]);}else{$page=1;}
                
            $searchword     =$input["searchword"];
            $sortcol        =$input["sortcol"];
            $sortdirection  =$input["sortdirection"];
            $userid         =$input["userid"];   
            
            //echo json_encode(['result' => '执行中-内部-Gene'.$userid]);die();

            
            //确定页码
            $items_per_page = 100;
            $offset = ($page - 1) * $items_per_page;
            
            //确认排序的方向
            if($sortcol=="")        {$sortcol ='分类1';}
            if($sortdirection=="")  {$sortdirection='asc';} 
            $sort_str="$sortcol $sortdirection,分类1 $sortdirection,分类2 $sortdirection,分类3 $sortdirection,名称 $sortdirection,描述1 $sortdirection,描述2 $sortdirection,描述3 $sortdirection ";
            
            if($searchword==""){
                if($action=='get_self'){                $where_str="拥有者 = ? and 共享权限 = '个人' and (系统备注1 IS NULL or 系统备注1<>'删除')";}
                else if($action=='get_selfshare'){      $where_str="拥有者 = ? and 共享权限 = '公开' and (系统备注1 IS NULL or 系统备注1<>'删除')";}  //<>号不能忽略null的问题，<>比较时，null并不满足
                else if($action=='get_public'){         $where_str="拥有者 != ? and 共享权限 = '公开' and (系统备注1 IS NULL or 系统备注1<>'删除')";}                
                $sql = "SELECT 创建时间,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,更新时间,创建者,创建时间,拥有者,共享权限 from 预设3_网络结构 where {$where_str} order by {$sort_str} limit {$items_per_page} offset {$offset}";  
                $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
                mysqli_stmt_bind_param($stmt, 's', $userid); 
                ///单纯计数
                $sql2 = "SELECT COUNT(*) from 预设3_网络结构 where {$where_str}  ";  
                $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
                mysqli_stmt_bind_param($stmt2, 's', $userid); 
            }
            else{
                if($action=='get_self'){                $where_str="拥有者 = ? and (系统备注1 IS NULL or 系统备注1<>'删除')";}
                else if($action=='get_selfshare'){      $where_str="拥有者 = ? and 共享权限 = '公开' and (系统备注1 IS NULL or 系统备注1<>'删除')";}  //<>号不能忽略null的问题，<>比较时，null并不满足
                else if($action=='get_public'){         $where_str="拥有者 != ? and 共享权限 = '公开' and (系统备注1 IS NULL or 系统备注1<>'删除')";}                
                $searchword = "%" . $searchword . "%";
                $where_str2="(创建时间 like ? or 唯一识别码 like ? or 分类1 like ? or 分类2 like ? or 分类3 like ? or 名称 like ? or 描述1 like ? or 描述2 like ? or 描述3 like ? or 更新时间 like ?)";
                $sql = "SELECT 创建时间,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,更新时间,创建者,创建时间,拥有者,共享权限 from 预设3_网络结构 where ({$where_str} and {$where_str2}) order by {$sort_str} limit ? offset ?";  
                $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
                mysqli_stmt_bind_param($stmt, 'sssssssssssii', $userid,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$items_per_page,$offset); 
                ///单纯计数
                $sql2 = "SELECT COUNT(*) from 预设3_网络结构 where ({$where_str} and {$where_str2}) ";  
                $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
                mysqli_stmt_bind_param($stmt2, 'sssssssssss', $userid,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword,$searchword); 
            }
            
            //正式执行sql
            mysqli_stmt_execute($stmt);  
            $result = mysqli_stmt_get_result($stmt);  
            $results = [];  
            while ($row = mysqli_fetch_assoc($result)) {  
                $results[] = $row;  
            }  
            mysqli_stmt_close($stmt); 
            if (empty($results)) {  
                //http_response_code(401);  
                //mysqli_close($conn); 
                //exit;  
                
            } 
            
            //简单计数
            mysqli_stmt_execute($stmt2);  
            mysqli_stmt_bind_result($stmt2, $total_count);
            mysqli_stmt_fetch($stmt2);
            mysqli_stmt_close($stmt2);
    
            $page_count = ceil($total_count / $items_per_page);

    
            // 构建响应
            // 返回 JSON 响应
            echo json_encode([
                'status' => 'success',
                'result' => $results,
                'result_num' =>$total_count,
                'page_num' =>$page_count,
            ]);
            
        }
        elseif ($dataregin=='content_edit'  && isset($input["item_id"])  ) {
            
            $item_id            =$input["item_id"];   
  
            $sql = "SELECT 识别码,唯一识别码,名称,创建者,创建时间,拥有者,共享权限,更新时间,模板预设,参数预设,结果预设,变量预设,备注信息,网络内容 from 预设3_网络结构 where 唯一识别码=?";  
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt, 's',$item_id); 
            
            //正式执行sql
            mysqli_stmt_execute($stmt);  
            $result = mysqli_stmt_get_result($stmt);  
            $results = [];  
            while ($row = mysqli_fetch_assoc($result)) {  
                $results[] = $row;  
            }  
            mysqli_stmt_close($stmt); 
            if (empty($results)) {  
                //http_response_code(401);  
                //mysqli_close($conn); 
                //exit;  
                $total_count=0;
            } 
            else{
                $total_count=1;
            }
    
            // 构建响应
            // 返回 JSON 响应
            echo json_encode([
                'status' => 'success',
                'result' => $results,
                'result_num' =>$total_count,
            ]);
        }
        elseif ($dataregin=='content_simple_one'  && isset($input["item_id"])  ) {
            
            $item_id            =$input["item_id"];   
            
            //$item_id判断字符串以stream_开头还是script_开头
            if (substr($item_id, 0, 7) === "script_") {  
                 $sheet_name='预设1_命令脚本';///更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,
                 $sql = "SELECT 创建时间,识别码,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,命令名称,模板预设,参数预设,结果预设,变量预设,备注信息 from {$sheet_name} where 唯一识别码=?";  
            } 
            elseif (substr($item_id, 0, 7) === "stream_" ) {  
                $sheet_name='预设2_线性流程';//更新时间,
                $sql = "SELECT 创建时间,识别码,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,模板预设,参数预设,结果预设,变量预设,备注信息 from {$sheet_name} where 唯一识别码=?";  
            }
            else {  
                http_response_code(500);  
                echo json_encode(['result' => '数据格式错误']);die();
            }
            
            
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt, 's',$item_id); 
            
            //正式执行sql
            mysqli_stmt_execute($stmt);  
            $result = mysqli_stmt_get_result($stmt);  
            $results = [];  
            while ($row = mysqli_fetch_assoc($result)) {  
                $results[] = $row;  
            }  
            mysqli_stmt_close($stmt); 
            if (empty($results)) {  
                //http_response_code(401);  
                //mysqli_close($conn); 
                //exit;  
                $total_count=0;
            } 
            else{
                $total_count=1;
            }
    
            // 构建响应
            // 返回 JSON 响应
            echo json_encode([
                'status' => 'success',
                'result' => $results,
                'result_num' =>$total_count,
            ]);
        }

        
        
        die();
    }

?>























