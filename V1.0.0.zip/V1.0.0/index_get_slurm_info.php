<?php
// 返回 JSON 格式的 Slurm 数据
header('Content-Type: application/json');
$squeue_output = shell_exec("squeue --noheader -o '%i %j %u %t %D %C %M %R'");



// 检查输出中是否包含错误（仅当输出是字符串时）
if (is_string($squeue_output) && strpos($squeue_output, 'error') !== false) {
    http_response_code(500);
    echo json_encode(['error' => 'slurm: Not configured or no permission']);
    die();
}

if ($squeue_output === null || trim($squeue_output) === '') {echo json_encode([]);}
else{
    $lines = explode("\n", trim($squeue_output));
    $jobs = [];
    foreach ($lines as $line) {
        if (empty($line)) continue;
        $cols = preg_split('/\s+/', $line);
        $jobs[] = [
            'jobid' => $cols[0] ?? '',
            'name' => $cols[1] ?? '',
            'user' => $cols[2] ?? '',
            'status' => $cols[3] ?? '',
            'nodes' => $cols[4] ?? '',
            'cpus' => $cols[5] ?? '',
            'runtime' => $cols[6] ?? '',
            'reason' => $cols[7] ?? ''
        ];
    }
    echo json_encode($jobs);
}

?>