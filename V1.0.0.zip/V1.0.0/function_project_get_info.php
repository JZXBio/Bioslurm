<?php
    //由于你在 fetch 请求中设置了 Content-Type 为 application/json，PHP 并不会自动将 JSON 请求体解析到 $_POST 数组中。你需要手动解析 JSON 请求体。
    //在 PHP 中，你可以通过 file_get_contents('php://input') 来获取原始的请求体数据，然后使用 json_decode() 来解析它
    // 获取 POST 数据
     
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);



    //链接数据库
    include 'database_connect.php';

    
    //echo json_encode(['result' => '执行中-内部-Gene']);die();
    //排序，页码，检索可能同时存在
    if (isset($input["action"]) && isset($input["userid"]) && $input["action"]=="refresh_project"){
        $userid         =$input["userid"]; 
        
        if(isset($input["page"])){$page=intval($input["page"]);}else{$page=1;}
        if(isset($input["projectdir"])){$projectdir=$input["projectdir"];}else{$projectdir='';}
        if(isset($input["searchword"])){$searchword=$input["searchword"];}else{$searchword='';}
        if(isset($input["sortcol"])){$sortcol=$input["sortcol"];}else{$sortcol='';}
        if(isset($input["sortdirection"])){$sortdirection=$input["sortdirection"];}else{$sortdirection='';}
        if(isset($input["num_per_page"])){$num_per_page=intval($input["num_per_page"]);}else{$num_per_page=5;}
        
        //确定页码
        $items_per_page = $num_per_page;
        $offset = ($page - 1) * $items_per_page;
        
        //确认排序的方向
        if($sortcol=="")        {$sortcol ='更新时间';}
        if($sortdirection=="")  {$sortdirection='desc';} 
        $sort_str="$sortcol $sortdirection,名称 $sortdirection,描述 $sortdirection";
        $projectdir= $projectdir."%";
        $where_str="拥有者 = ? and (系统备注1 IS NULL or 系统备注1<>'删除') and 项目目录 like ? ";
        //确认排序的方向
        if($searchword==""){
            $sql = "SELECT 创建时间,唯一识别码,名称,描述,更新时间,项目目录,备注信息 from 执行1_项目列表 where {$where_str} order by {$sort_str} limit {$items_per_page} offset {$offset}";  
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt, 'ss', $userid,$projectdir); 
            ///单纯计数
            $sql2 = "SELECT COUNT(*) from 执行1_项目列表 where {$where_str}  ";  
            $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt2, 'ss', $userid,$projectdir); 
        }
        else{
            $searchword = "%" . $searchword . "%";
            $where_str2="(创建时间 like ? or 唯一识别码 like ? or 名称 like ? or 描述 like ? or 更新时间 like ?)";
            $sql = "SELECT 创建时间,唯一识别码,名称,描述,更新时间,项目目录,备注信息 from 执行1_项目列表 where ({$where_str} and {$where_str2}) order by {$sort_str} limit {$items_per_page} offset {$offset}";  
            $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt, 'sssssss', $userid,$projectdir,$searchword,$searchword,$searchword,$searchword,$searchword); 
            ///单纯计数
            $sql2 = "SELECT COUNT(*) from 执行1_项目列表 where ({$where_str} and {$where_str2}) ";  
            $stmt2 = mysqli_prepare($conn, $sql2);  if (!$stmt2) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
            mysqli_stmt_bind_param($stmt2, 'sssssss', $userid,$projectdir,$searchword,$searchword,$searchword,$searchword,$searchword); 
        }
        
        //正式执行sql
        mysqli_stmt_execute($stmt);  
        $result = mysqli_stmt_get_result($stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($stmt); 
        if (empty($results)) {  
            //http_response_code(401);  
            //mysqli_close($conn); 
            //exit;  
            
        } 
        
        //简单计数
        mysqli_stmt_execute($stmt2);  
        mysqli_stmt_bind_result($stmt2, $total_count);
        mysqli_stmt_fetch($stmt2);
        mysqli_stmt_close($stmt2);

        $page_count = ceil($total_count / $items_per_page);


        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
            'result_num' =>$total_count,
            'page_num' =>$page_count,
        ]);
        
    }
    
    /*if (isset($input["action"]) && isset($input["item_id"]) && $input["action"]=="refresh_project_edit"){
        $item_id=$input["item_id"];
        
        
        $sql = "SELECT 使用模块,模板预设,参数预设,备注信息 from 执行1_项目列表 where 唯一识别码=?";
        $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
        mysqli_stmt_bind_param($stmt, 's', $item_id); 
        //正式执行sql
        mysqli_stmt_execute($stmt);  
        $result = mysqli_stmt_get_result($stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($stmt); 
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
        ]);        
    }*/
    elseif (isset($input["action"])  && isset($input["item_id"]) && $input["action"]=="content_simple_one" ) {
        
        $item_id            =$input["item_id"];   
        
        //$item_id判断字符串以stream_开头还是script_开头
        if (substr($item_id, 0, 7) === "script_" ) {  
             $sheet_name='预设1_命令脚本';///更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,
             $sql = "SELECT 创建时间,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,线程分配,命令名称,模板预设,参数预设,结果预设,变量预设,备注信息 from {$sheet_name} where 唯一识别码=?";  
        } 
        elseif (substr($item_id, 0, 7) === "stream_") {  
            $sheet_name='预设2_线性流程';//更新时间,
            $sql = "SELECT 创建时间,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,线程分配,模板预设,参数预设,结果预设,变量预设,备注信息,流程内容 from {$sheet_name} where 唯一识别码=?";  
        }
        elseif (substr($item_id, 0, 10) === "structure_") {  
            $sheet_name='预设3_网络结构';//更新时间,
            $sql = "SELECT 创建时间,唯一识别码,分类1,分类2,分类3,名称,描述1,描述2,描述3,模板预设,参数预设,结果预设,变量预设,备注信息,网络内容 from {$sheet_name} where 唯一识别码=?";  
        }        
        else {  
            http_response_code(500);  
            echo json_encode(['result' => '数据格式错误']);die();
        }
        
        
        $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
        mysqli_stmt_bind_param($stmt, 's',$item_id); 
        
        //正式执行sql
        mysqli_stmt_execute($stmt);  
        $result = mysqli_stmt_get_result($stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($stmt); 
        if (empty($results)) {  
            //http_response_code(401);  
            //mysqli_close($conn); 
            //exit;  
            $total_count=0;
        } 
        else{
            $total_count=1;
        }

        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
            'result_num' =>$total_count,
        ]);
    }
    elseif (isset($input["action"])  && isset($input["item_id"]) && $input["action"]=="content_simple_one2" ) {
            
        $item_id            =$input["item_id"];   
        
        //$item_id判断字符串以stream_开头还是script_开头
        if (substr($item_id, 0, 7) === "script_"  ) {  
             $sheet_name='预设1_命令脚本';///更新时间,环境类型,环境预备,运行模式,线程分配,命令类型,
             $sql = "SELECT 唯一识别码,名称,命令名称,模板预设,参数预设,结果预设 from {$sheet_name} where 唯一识别码=?";  
        } 
        elseif (substr($item_id, 0, 7) === "stream_") {  
            $sheet_name='预设2_线性流程';//更新时间,
            $sql = "SELECT 唯一识别码,名称,模板预设,参数预设,结果预设 from {$sheet_name} where 唯一识别码=?";  
        }
        elseif (substr($item_id, 0, 10) === "structure_") {  
            $sheet_name='预设3_网络结构';//更新时间,
            $sql = "SELECT 唯一识别码,名称,模板预设,参数预设,结果预设 from {$sheet_name} where 唯一识别码=?";  
        }        
        else {  
            http_response_code(500);  
            echo json_encode(['result' => '数据格式错误']);die();
        }
        
        
        $stmt = mysqli_prepare($conn, $sql);  if (!$stmt) {  http_response_code(500);  mysqli_close($conn);  exit;  }  
        mysqli_stmt_bind_param($stmt, 's',$item_id); 
        
        //正式执行sql
        mysqli_stmt_execute($stmt);  
        $result = mysqli_stmt_get_result($stmt);  
        $results = [];  
        while ($row = mysqli_fetch_assoc($result)) {  
            $results[] = $row;  
        }  
        mysqli_stmt_close($stmt); 
        if (empty($results)) {  
            //http_response_code(401);  
            //mysqli_close($conn); 
            //exit;  
            $total_count=0;
        } 
        else{
            $total_count=1;
        }

        // 构建响应
        // 返回 JSON 响应
        echo json_encode([
            'status' => 'success',
            'result' => $results,
            'result_num' =>$total_count,
        ]);
    }    
    
    die();
    

?>























