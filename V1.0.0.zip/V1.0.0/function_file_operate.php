<?php  
    header('Content-Type: application/json');
    
    // 获取 POST 数据
    $input = json_decode(file_get_contents('php://input'), true);
    $base_path  = $input['base_path'] ?? '';
    $local_path = $input['local_path'] ?? '';
    $operate    = $input['operate'] ?? '';
    $file_type  = $input['file_type'] ?? '';
    $file_name  = $input['file_name'] ?? '';
    $file_name_new  = $input['file_name_new'] ?? '';
    /*我在前端进行了隐藏，这里不需要了
    if ($file_name=='BioSlurm_share'){
        http_response_code(400);
        echo json_encode(['error' => '文件夹BioSlurm不可操作']);//ls: 无法访问/home/ddd: 没有那个文件或目录
        die();
    }*/
    $all_checkbox_value             = $input['all_checkbox_value'] ?? '';
    $all_checkbox_value_localpath   = $input['all_checkbox_value_localpath'] ?? '';
    
    if($base_path=="" || $local_path=="" || $operate=="" ){
        http_response_code(400);
        echo json_encode(['error' => '参数错误']);//ls: 无法访问/home/ddd: 没有那个文件或目录
        die();
    }
    
        
    // 完整路径
    $complete_path = $base_path ."/". $local_path."/";
    $complete_path_item=$complete_path.$file_name;
    // 空格前加转义
    //$complete_path = str_replace(' ', '\ ', $complete_path);
    //$complete_path = str_replace('\\\\', '\\', $complete_path);
    // 执行命令并修改时间格式
    #$cmd = "ls -ll --time-style='+%Y-%m-%d %H:%M' " . escapeshellarg($complete_path);
    $cmd='ls -ll --time-style="+%Y-%m-%d %H:%M" "'.$complete_path.'"';
    $cmd_result = shell_exec($cmd);
    if(strpos("没有那个文件或目录",$cmd_result)!==FALSE){
        http_response_code(400);
        echo json_encode(['error' => '没有那个文件或目录']);//ls: 无法访问/home/ddd: 没有那个文件或目录
        die();
    }

    //
    // 定义递归复制目录的函数  
    function copy_directory($src, $dst) {  
        // 打开源目录  
        $dir = opendir($src);  
        // 创建目标目录  
        @mkdir($dst);  
        // 遍历目录  
        while ($file = readdir($dir)) {  
            // 忽略 . 和 .. 目录  
            if (($file != '.') && ($file != '..')) {  
                // 构建源路径和目标路径  
                $src_path = $src . DIRECTORY_SEPARATOR . $file;  
                $dst_path = $dst . DIRECTORY_SEPARATOR . $file;  
      
                // 如果是目录，递归复制  
                if (is_dir($src_path)) {  
                    copy_directory($src_path, $dst_path);  
                } else {  
                    // 如果是文件，直接复制  
                    if (!copy($src_path, $dst_path)) {  
                        return false; // 复制失败时返回 false  
                    }  
                }  
            }  
        }  
        // 关闭目录  
        closedir($dir);  
        return true; // 复制成功时返回 true  
    }
    
    // 文件夹不为空，需要递归删除  
    function deleteDirectory($dir) {  
        if (!file_exists($dir)) {  return true;  }  
        if (!is_dir($dir)) {  return unlink($dir);  }  
        foreach (scandir($dir) as $item) {  
            if ($item == '.' || $item == '..') {  continue;  }  
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {  return false;  }  
        }  
        return rmdir($dir);  
    }
    
    // 递归函数，将文件夹添加到zip
    function addFolderToZip($zip, $folder, $folder_name) {
        $files = array_diff(scandir($folder), array('.', '..'));
        foreach ($files as $file) {
            $file_path = $folder . '/' . $file;
            if (is_dir($file_path)) {
                // 如果是文件夹，递归处理
                addFolderToZip($zip, $file_path, $folder_name . '/' . $file);
            } else {
                // 如果是文件，添加到zip
                if (!$zip->addFile($file_path, $folder_name . '/' . $file)) {
                    return false;
                }
            }
        }
        return true;
    }

    if($operate=="新建" || $operate=="删除"||$operate=="复制"||$operate=="压缩"||$operate=="解压"||$operate=="重命名"){
        if($file_type=="" || $file_name==""){http_response_code(400);echo json_encode(['error' => '参数错误']);die();}
        //
        if($operate=="新建"){
            if($file_type=="文件"){
                if (!file_exists($complete_path_item)) {  
                    if (touch($complete_path_item)) {$result_log_text="文件创建成功"; } 
                    else {http_response_code(400);echo json_encode(['error' => '文件创建失败']);die();  }  
                } 
                else {  
                    http_response_code(400);echo json_encode(['error' => '文件已经存在']);die();        
                }  
            }
            elseif($file_type=="文件夹"){
                if (!file_exists($complete_path_item)) {  
                    if (mkdir($complete_path_item, 0777, true)) {$result_log_text="文件夹创建成功"; } 
                    else {http_response_code(400);echo json_encode(['error' => '文件夹创建失败']);die();  }  
                } 
                else {  
                    http_response_code(400);echo json_encode(['error' => '文件夹已经存在']);die();        
                }  
            }
            else{http_response_code(400);echo json_encode(['error' => '参数错误']);die();            }
        }
        elseif($operate=="删除"){
            if (file_exists($complete_path_item)) {
                // 如果是软链接，直接删除链接本身（不追踪目标）
                if (is_link($complete_path_item)) {
                    if (unlink($complete_path_item)) {
                        $result_log_text = "软链接删除成功";
                    } else {
                        // 更详细的错误信息
                        $error = error_get_last();
                        http_response_code(400);
                        echo json_encode(['error' => '软链接删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                        die();
                    }
                }
                // 如果是普通文件
                elseif (is_file($complete_path_item)) {
                    if (unlink($complete_path_item)) {
                        $result_log_text = "文件删除成功";
                    } else {
                        $error = error_get_last();
                        http_response_code(400);
                        echo json_encode(['error' => '文件删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                        die();
                    }
                }
                // 如果是目录
                elseif (is_dir($complete_path_item)) {
                    // 检查是否为空目录
                    $files = array_diff(scandir($complete_path_item), array('.', '..'));
                    if (empty($files)) {
                        // 空目录，直接删除
                        if (rmdir($complete_path_item)) {
                            $result_log_text = "文件夹删除成功";
                        } else {
                            $error = error_get_last();
                            http_response_code(400);
                            echo json_encode(['error' => '文件夹删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                            die();
                        }
                    } else {
                        // 非空目录，递归删除内容
                        if (deleteDirectory($complete_path_item)) {
                            $result_log_text = "文件夹及其内容删除成功";
                        } else {
                            $error = error_get_last();
                            http_response_code(400);
                            echo json_encode(['error' => '文件夹及其内容删除失败: ' . ($error ? $error['message'] : '可能是权限问题或文件正在被使用')]);
                            die();
                        }
                    }
                }
                // 未知类型（理论上不会发生）
                else {
                    http_response_code(400);
                    echo json_encode(['error' => '指定路径类型未知']);
                    die();
                }
            } else {
                // 检查是否是悬空软链接（指向不存在的目标）
                if (is_link($complete_path_item)) {
                    // 即使目标不存在，也可以删除软链接本身
                    if (unlink($complete_path_item)) {
                        $result_log_text = "悬空软链接删除成功";
                    } else {
                        $error = error_get_last();
                        http_response_code(400);
                        echo json_encode(['error' => '悬空软链接删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                        die();
                    }
                } else {
                    http_response_code(400);
                    echo json_encode(['error' => '文件、文件夹或软链接不存在']);
                    die();
                }
            }

        }
        elseif($operate=="复制"){
            //生成原名字(.原扩展名).当前时间字符串_copy
            // 检查原文件是否存在  
            if (!file_exists($complete_path_item)) {  http_response_code(400);  echo json_encode(['error' => '要复制的文件不存在']);  die();  }  
          
            // 生成当前时间字符串  
            $current_time_string = date("YmdHis"); // 格式：YYYYMMDDHHMMSS  
            
            // 生成复制文件的完整路径  
            $copy_file_path = $complete_path_item . "_copied".$current_time_string;  
            if($file_type=="文件"){
                // 复制文件  
                if (!copy($complete_path_item, $copy_file_path)) {  
                    http_response_code(400);  
                    echo json_encode(['error' => '文件复制失败']);  
                    die();  
                }  
                $result_log_text = "复制成功，生成文件: " . $file_name."_copied".$current_time_string;  // 复制成功  
            }
            elseif($file_type=="文件夹"){
                if (!copy_directory($complete_path_item, $copy_file_path)) {  
                    http_response_code(400);  
                    echo json_encode(['error' => '文件夹复制失败']);  
                    die();  
                }  
                $result_log_text = "复制成功，生成文件夹: " . basename($complete_path_item) . "_copied" . $current_time_string;  // 复制成功  
            }
        }        
        elseif($operate=="压缩"){
            //生成原名字(.原扩展名).zip
            // 检查文件或文件夹是否存在  
            if(!file_exists($complete_path_item)){  http_response_code(400);  echo json_encode(['error' => '要压缩的文件或文件夹不存在']);  die();  }  
            $compressed_extensions = ['.zip', '.gzip', '.tar.gz', '.tar'];
            foreach ($compressed_extensions as $extension) {
                if (substr($complete_path_item, -strlen($extension)) === $extension) {
                    http_response_code(400);echo json_encode(['error' => '已经是被压缩的格式']);die();
                }
            }
    
            $zip_filename = $complete_path_item . '.zip';  // 确定压缩文件的名称  
            $zip = new ZipArchive();  // 创建ZipArchive对象  
            // 尝试打开zip文件，如果失败则创建  
            if ($zip->open($zip_filename, ZipArchive::CREATE) !== TRUE) {   http_response_code(400);   echo json_encode(['error' => '无法创建压缩文件']);   die();   }  
          
            
            if (is_file($complete_path_item)) {  // 如果是文件，直接添加到压缩包中  
                $zip->addFile($complete_path_item, basename($complete_path_item));  // 添加文件到压缩包，这里使用basename获取文件名  
            } 
            elseif (is_dir($complete_path_item)) {  // 如果是文件夹，需要递归添加文件夹中的内容  
                // 创建一个递归目录迭代器  
                $files = new RecursiveIteratorIterator(  
                    new RecursiveDirectoryIterator($complete_path_item),  
                    RecursiveIteratorIterator::LEAVES_ONLY  
                );  
                foreach ($files as $name => $file) {  // 跳过目录  
                    if (!$file->isDir()) {  
                        // 获取文件路径相对于压缩目录的路径  
                        $filePath = $file->getRealPath();  
                        $relativePath = substr($filePath, strlen($complete_path_item) + 1);  
                        // 添加文件到压缩包  
                        $zip->addFile($filePath, $relativePath);  
                    }  
                }  
            } 
            else {  
                http_response_code(400);  echo json_encode(['error' => '指定路径既不是文件也不是文件夹']);   die();  
            }  
            $zip->close();  // 关闭zip文件  
            $result_log_text = "压缩成功，生成文件: " . $file_name.'zip';     // 压缩成功  
        }
        elseif($operate=="解压"){
            if (!file_exists($complete_path_item)) {  http_response_code(400);  echo json_encode(['error' => '要解压的文件不存在']);  die();  }  
            // 获取文件扩展名和文件名  
            $fileExt = pathinfo($complete_path_item, PATHINFO_EXTENSION);if($fileExt==false){ http_response_code(400);  echo json_encode(['error' => '无法解析文件扩展名']);  die();  }  
            $fileName = pathinfo($complete_path_item, PATHINFO_FILENAME);if($fileName==false){ http_response_code(400);  echo json_encode(['error' => '无法解析文件名']);  die();  }  
            // 检查是否为 tar.gz
            if ($fileExt == 'gz' && substr($fileName, -4) == '.tar') {$fileExt = 'tar.gz';$fileName = substr($fileName, 0, -4); } 
            elseif ($fileExt == 'tar') {$fileExt = 'tar';} 
            elseif ($fileExt == 'gz') {}

            //创建文件夹保存解压内容
            $extractTo=$complete_path.$fileName;
            if (!is_dir($extractTo)) { 
                if (!mkdir($extractTo, 0777, true)) {http_response_code(400);echo json_encode(['error' => '文件夹创建失败：' . $fileName]);die();}
            } 
            else {http_response_code(400);echo json_encode(['error' => '解压目录已存在，请删除该目录']);die();}
            
            //解压
            if ($fileExt=="zip"){
                $zip = new ZipArchive();  
                if ($zip->open($complete_path_item) === TRUE) {  
                    $zip->extractTo($extractTo);  
                    $zip->close();  
                    $result_log_text = "解压成功，解压到：./" . $fileName . '/' ;  
                } 
                else {  http_response_code(400);  echo json_encode(['error' => '无法打开ZIP文件']);  die();  }  
            }
            elseif ($fileExt == "gz") {
                $gz = gzopen($complete_path_item, 'rb');
                if ($gz === false) {http_response_code(400);echo json_encode(['error' => '无法打开GZIP文件']);die(); }
                $outFile = fopen($extractTo . '/' . $fileName, 'wb');
                if ($outFile === false) {http_response_code(400);echo json_encode(['error' => '无法创建解压文件：' . $fileName]);die();}
                while (!gzeof($gz)) {$data = gzread($gz, 4096);fwrite($outFile, $data);}
                gzclose($gz);fclose($outFile);
                $result_log_text = "解压成功，解压到：./" . $fileName . '/';
            } 
            elseif ($fileExt == "tar" || $fileExt == "tar.gz") {
                $phar = new PharData($complete_path_item);
                try { $phar->extractTo($extractTo);$result_log_text = "解压成功，解压到：./" . $fileName . '/';} 
                catch (Exception $e) {http_response_code(400);echo json_encode(['error' => '无法解压文件：' . $e->getMessage()]);die();}
            }
            else{ http_response_code(400);  echo json_encode(['error' => '不支持的扩展名']);  die();  }  
        }
        elseif($operate=="重命名"){
            if (!file_exists($complete_path_item)) {  http_response_code(400);  echo json_encode(['error' => '要复制的文件不存在']);  die();  }  
            //新文件夹为$file_name_new;//$file_name为文件名//$complete_path为路径名
            // 生成新路径：不论是文件还是文件夹，都是新的完整路径
            $new_path = $complete_path . '/' . $file_name_new;
        
            // 检查新文件名或文件夹名是否已经存在
            if (file_exists($new_path)) {http_response_code(400);echo json_encode(['error' => '新名称已存在']);die();}
        
            // 执行重命名操作
            if (rename($complete_path_item, $new_path)) {$result_log_text=$file_type.'重命名成功';;} 
            else {http_response_code(500);echo json_encode(['error' => ($file_type == "文件" ? '文件' : '文件夹') . '重命名失败']);die();}
        }
    }    
    

    if($operate=="批量移动" || $operate=="批量删除" || $operate=="批量压缩"){
        if($all_checkbox_value=="" ){http_response_code(400);echo json_encode(['error' => '参数错误']);die();}
        //
        if($operate=="批量移动"){
            if ($all_checkbox_value_localpath==""){http_response_code(400);echo json_encode(['error' => '参数错误']);die();}
            //////////
            $file_type_arr=explode('_;;;_',$all_checkbox_value);
            foreach ($file_type_arr as $one){
                $one_arr=explode('_||_',$one);
                $one_name=$one_arr[0];
                //$one_type=$one_arr[1];
                $source = $base_path ."/".$all_checkbox_value_localpath.'/'.$one_name;  // 源文件或文件夹路径
                $destination = $complete_path . $one_name;  // 目标路径
                // 检查源文件/文件夹是否存在
                if (file_exists($source)) {
                    // 使用rename函数移动文件或文件夹
                    if (rename($source, $destination)) { $result_log_text='选中文件已移动至新文件夹';} 
                    else { http_response_code(400);echo json_encode(['error' => '剪切失败']);die(); }
                } 
                else {http_response_code(400);echo json_encode(['error' => '源文件不存在']);die();}
            }
        }
        
        if($operate=="批量删除"){
            $file_type_arr=explode('_;;;_',$all_checkbox_value);
                foreach ($file_type_arr as $one) {
                    $one_arr = explode('_||_', $one);
                    $one_name = $one_arr[0];
                    $one_type = $one_arr[1];
                    $complete_path_item = $complete_path . $one_name;
                
                    // 检查源文件/文件夹/软链接是否存在
                    if (!file_exists($complete_path_item) && !is_link($complete_path_item)) {
                        http_response_code(400);
                        echo json_encode(['error' => $one_name . ' 不存在']);
                        die();
                    }
                
                    // 如果是软链接
                    if (is_link($complete_path_item)) {
                        if (unlink($complete_path_item)) {
                            $result_log_text = "软链接删除成功";
                        } else {
                            $error = error_get_last();
                            http_response_code(400);
                            echo json_encode(['error' => '软链接删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                            die();
                        }
                    }
                    // 如果是文件
                    elseif ($one_type == "文件") {
                        if (unlink($complete_path_item)) {
                            $result_log_text = "文件删除成功";
                        } else {
                            $error = error_get_last();
                            http_response_code(400);
                            echo json_encode(['error' => '文件删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                            die();
                        }
                    }
                    // 如果是文件夹
                    elseif ($one_type == "文件夹") {
                        // 检查文件夹是否为空
                        $files = array_diff(scandir($complete_path_item), array('.', '..'));
                        if (empty($files)) {
                            // 文件夹为空，可以直接删除
                            if (rmdir($complete_path_item)) {
                                $result_log_text = "文件夹删除成功";
                            } else {
                                $error = error_get_last();
                                http_response_code(400);
                                echo json_encode(['error' => '文件夹删除失败: ' . ($error ? $error['message'] : '可能是权限问题')]);
                                die();
                            }
                        } else {
                            // 文件夹不为空，递归删除
                            if (deleteDirectory($complete_path_item)) {
                                $result_log_text = "文件夹及其内容删除成功";
                            } else {
                                $error = error_get_last();
                                http_response_code(400);
                                echo json_encode(['error' => '文件夹及其内容删除失败: ' . ($error ? $error['message'] : '可能是权限问题或文件正在被使用')]);
                                die();
                            }
                        }
                    }
                    // 未知类型
                    else {
                        http_response_code(400);
                        echo json_encode(['error' => '未知类型: ' . $one_type]);
                        die();
                    }
                }

        }
        if ($operate == "批量压缩") {
            $file_type_arr = explode('_;;;_', $all_checkbox_value);
            $zip = new ZipArchive();
            $zip_file = $complete_path . 'sum.zip';  // 压缩文件的路径
        
            // 打开zip文件，创建或覆盖
            if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
                http_response_code(500);
                echo json_encode(['error' => '无法创建zip文件']);
                die();
            }
        
            foreach ($file_type_arr as $one) {
                $one_arr = explode('_||_', $one);
                $one_name = $one_arr[0];
                $one_type = $one_arr[1];
                $complete_path_item = $complete_path . $one_name;
        
                // 检查文件或文件夹是否存在
                if (!file_exists($complete_path_item)) {
                    http_response_code(400);
                    echo json_encode(['error' => $one_name . ' 不存在']);
                    die();
                } else {
                    // 如果是文件，添加到zip
                    if ($one_type == "文件") {
                        if (!$zip->addFile($complete_path_item, $one_name)) {
                            http_response_code(400);
                            echo json_encode(['error' => '无法添加文件 ' . $one_name . ' 到zip']);
                            die();
                        }
                    } 
                    // 如果是文件夹，递归添加
                    elseif ($one_type == "文件夹") {
                        // 调用递归函数添加文件夹
                        if (!addFolderToZip($zip, $complete_path_item, $one_name)) {
                            http_response_code(400);
                            echo json_encode(['error' => '无法添加文件夹 ' . $one_name . ' 到zip']);
                            die();
                        }
                    }
                }
            }
        
            // 关闭zip文件
            $zip->close();
            $result_log_text='文件压缩成功，压缩包为 sum.zip';
        }
    }
    // 返回 JSON 响应
    echo json_encode([
        'status' => 'success',
        'result' => $result_log_text,
    ]);
    
    /*'TEST'=>$cmd,
        'complete_path'=>$complete_path,
        'cmd_result'=>$cmd_result,*/
?>



















