<?php

    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    //链接数据库
    include 'database_connect.php';

    $userid = $input['userid'];
    $action= $input['action'];
    $slurmid= $input['slurmid'];


    //本用户的实际运行中的jobid
    $running_jobids=[];
    $squeue  = shell_exec("squeue -h -o '%20i    %60j     %.2t' ");
    $lines = array_filter(explode("\n", trim($squeue)));
    foreach ($lines as $line) {
        // 用正则分割字段（处理多个空格）
        $fields = preg_split('/\s+/', trim($line), 3); // 最多分成 3 部分
        if (count($fields) >= 3) {
            $jobId = $fields[0];    // 第一个字段：作业 ID
            $jobName = $fields[1];  // 第二个字段：作业名称
            $status = $fields[2];   // 第三个字段：状态（可能不需要）
            // 检查作业 ID 是否匹配，且作业名称以 $userid 结尾
            if (str_ends_with($jobName, $userid)) {$running_jobids[]=$jobId;}
        }
    }
    
    if(in_array($slurmid, $running_jobids, true)){
        // 执行操作
        if ($action === 'scancel') {
            $command = "scancel " . escapeshellarg($slurmid);
            $output = shell_exec($command);
            //die标记
            $sql = "UPDATE 执行3_作业列表 SET 状态 ='die' WHERE 拥有者 = ? AND 作业slurm编号 = ?";  
            $params =[ ['type' => 's', 'value' => $userid],['type' => 's', 'value' => $slurmid]]; // 's' 表示字符串类型
            $rows = database_query($conn, $sql, $params); 
        } 
        elseif ($action === 'suspend') {
            $command = "scontrol suspend " . escapeshellarg($slurmid);
            $output = shell_exec($command);
        } 
        elseif ($action === 'resume') {
            $command = "scontrol resume " . escapeshellarg($slurmid);
            $output = shell_exec($command);
        } 
        else{
            http_response_code(500);  echo json_encode(['error' => 'action错误']);die();
        }
    }    
    echo json_encode([
        'success' => true,
        'result' => $slurmid,
        'cmd_out' => $output
    ]);
   


?>